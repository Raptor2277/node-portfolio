import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.util.Vector;

public class GameScreen extends Screen
{
	Board board;
	Screen parentScreen;
	Vector <String>  direction;
	
	int frames;
	int delay;
	
	public GameScreen(Screen parentScreen, int size, int boardSize, int delay)
	{
		this.parentScreen = parentScreen;
		this.board = new Board(size,boardSize,this);
		this.direction = new Vector<String>();
		
		this.frames = 0;
		this.delay = delay;
		
		this.isActive=true;
		this.isDrawn=true;
	}
	
	public void draw(Graphics2D gr)
	{
		board.drawBoard(gr);
	}
	
	//this will call the update every x frames
	//note: there are 60 frames in a second
	public void update()
	{
		if(frames == delay)
		{
			if(direction.size() > 0){
				board.update(direction.firstElement());
				direction.removeElementAt(0);
			}
			else {
				board.update("none");
			}
			frames=0;
		}
		else {
			frames++;
		}
	}
	
	public void handleInput(int keycode)
	{
			if(keycode == KeyEvent.VK_W || keycode == KeyEvent.VK_UP)
				direction.add("up");
			else if(keycode == KeyEvent.VK_S || keycode == KeyEvent.VK_DOWN)
				direction.add("down");
			else if(keycode == KeyEvent.VK_A || keycode == KeyEvent.VK_LEFT)
				direction.add("left");
			else if(keycode == KeyEvent.VK_D || keycode == KeyEvent.VK_RIGHT)
				direction.add("right");
			else if(keycode == KeyEvent.VK_ESCAPE || keycode == KeyEvent.VK_ENTER)
			{
				screenManager.addScreen(new PauseScreen(this));
				pause();
			}
			
			//System.out.println(Integer.toString(direction.size()));
			//int size = direction.size();
			//if(direction.lastElement().equals(direction.elementAt(size-2)));
				//direction.removeElementAt(size-1);
	}
	
	public void pause()
	{
		if(isActive)
		{
			isActive = false;
		}
		else
			isActive = true;
	}
	
	public void init()
	{
		
	}
	
	public void takeInput(String args)
	{
		if(args == "pause")
		{
			this.pause();
		}
		else if (args == "quit")
		{
			parentScreen.takeInput("quit");
			screenManager.removeScreen(this);
		}
		else if (args == "loss")
		{
			screenManager.addScreen(new LoseScreen(this));
			this.pause();
		}
		else if(args == "restart")
		{
			this.pause();
			board.restart();
		}
		else if(args == "win")
		{
			screenManager.addScreen(new WinScreen(this));
			this.pause();
		}
	}
}
