import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.util.Vector;



public class MainMenuScreen extends Screen
{
	int boardSize = 20;
	int snakeDelay = 7;
	
	Vector<MenuButton> buttons;
	int currentMenu;
	
	//fonts
	Font fontHighlight = new Font("Times New Roman", Font.BOLD, 50);
	Font font = new Font("Times New Roman", Font.PLAIN, 30);
	Font hintFont = new Font("Times New Roman", Font.ITALIC, 20);
	Color color = Color.blue;
	Color hintColor = Color.black;
	
	public MainMenuScreen(Dimension appletDimension)
	{
		this.dimension = appletDimension;
		this.appletDimension = appletDimension;
		this.position = new Point(0,0);
		
		this.buttons = new Vector<MenuButton>();
		currentMenu = 1;
		buttons.addElement(new MenuButton("Java Snake", 100,  fontHighlight,color, dimension, position));
		buttons.addElement(new MenuButton("Start", 200,  font, color, dimension, position));
		buttons.addElement(new MenuButton("Board Size: 20", 250,  font, color, dimension, position));
		buttons.elementAt(2).addText("Board Size: 25");
		buttons.elementAt(2).addText("Board Size: 30");
		buttons.addElement(new MenuButton("Snake Speed: Turtle", 300,  font, color, dimension, position));
		buttons.elementAt(3).addText("Snake Speed: Rabbit");
		buttons.elementAt(3).addText("Snake Speed: Cheetah");
		buttons.addElement(new MenuButton("Help", 350,  font, color, dimension, position));
		buttons.addElement(new MenuButton("Quit", 400,  font, color, dimension, position));
		buttons.addElement(new MenuButton("NULL", 500,  hintFont, hintColor,dimension, position)); //using null because i want text index to be aligned with  
		buttons.elementAt(6).addText("Play the game with the current settings");						//current menu, current menu starts at 1
		buttons.elementAt(6).addText("Change how many squares the board is");
		buttons.elementAt(6).addText("Change how fast the snake moves");
		buttons.elementAt(6).addText("Show the help screen");
		buttons.elementAt(6).addText("Quit to desktop");
		buttons.addElement(new MenuButton("Use the arrow keys to move and enter to select!", 590,  font, color, dimension, position));
		
		this.isActive = true;
		this.isDrawn = true;
	}
	
	public void draw(Graphics2D gr)
	{
		for(int i=0; i<buttons.size(); i++)
		{
			buttons.elementAt(i).draw(gr);
		}
	}

	public void update()
	{
		for(int i=0; i<buttons.size(); i++)
		{
			if(i == currentMenu)
				buttons.elementAt(i).isHighlighted = true;
			else
				buttons.elementAt(i).isHighlighted= false;
		}
		
		buttons.elementAt(6).changeTextIndex(currentMenu);
	}
	
	public void handleInput(int keycode)
	{
		if(keycode == KeyEvent.VK_ESCAPE)
		{
			screenManager.removeScreen(this);
			System.exit(0);
		}
		else if(keycode == KeyEvent.VK_UP || keycode == KeyEvent.VK_W)
		{
			if(currentMenu>1)
				currentMenu--;
		}
		else if(keycode == KeyEvent.VK_DOWN || keycode == KeyEvent.VK_S)
		{
			if(currentMenu<5)
				currentMenu++;	
		}
		else if(keycode == KeyEvent.VK_ENTER)
		{
			switch (currentMenu)
			{
				case 1:
					screenManager.addScreen(new GameScreen(this, this.dimension.height, this.boardSize, this.snakeDelay));
					this.isActive = false;
					this.isDrawn = false;
					break;
				case 2:
					buttons.elementAt(currentMenu).nextText();
					boardSize+=5;
					if(boardSize>30)
						boardSize=20;
					break;
					
				case 3:
					buttons.elementAt(currentMenu).nextText();
					snakeDelay-=2;
					if(snakeDelay<3)
						snakeDelay=7;
					break;
					
				case 4:
					screenManager.addScreen(new HelpScreen(this, this.appletDimension));
					this.isActive = false;
					this.isDrawn = false;
					break;

				case 5:
					System.exit(0);
					break;
			}
		}
	}

	public void init()
	{
		
	}

	public void takeInput(String args)
	{
		if(args == "quit")
		{
			this.isActive = true;
			this.isDrawn = true;
		}
	}

}
