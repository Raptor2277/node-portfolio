import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.util.Vector;


public class LoseScreen extends Screen
{
	Point posMiddle;
	Screen parentScreen;
	
	int currentMenu;
	Vector<MenuButton> buttons;
	
	Font fontHighlight = new Font("Times New Roman", Font.BOLD, 40);
	Font font = new Font("Times New Roman", Font.PLAIN, 30);
	Color color = Color.black;
	
	public LoseScreen(Screen parentScreen)
	{
		this.dimension = new Dimension(300,200);
		this.currentMenu = 1;
		this.buttons = new Vector<MenuButton>();
		this.parentScreen = parentScreen;
		this.isActive = true;
		this.isDrawn = true;
	}
	
	public void draw(Graphics2D gr) 
	{
		gr.setColor(Color.white);
		gr.fillRect(position.x, position.y, dimension.width, dimension.height);
		gr.setColor(Color.black);
		gr.drawRect(position.x, position.y, dimension.width, dimension.height);
		
		for(int i=0; i<buttons.size();i++)
		{
			buttons.elementAt(i).draw(gr);
		}
		
	}

	public void update() 
	{
		for(int i=0; i<buttons.size(); i++)
		{
			if(i == currentMenu)
				buttons.elementAt(i).isHighlighted = true;
			else
				buttons.elementAt(i).isHighlighted= false;
		}
	}

	public void handleInput(int keycode) 
	{
			if(keycode == KeyEvent.VK_ESCAPE)
			{
				parentScreen.takeInput("restart");
				screenManager.removeScreen(this);
			}
			else if(keycode == KeyEvent.VK_UP || keycode == KeyEvent.VK_W)
			{
				if(currentMenu>1)
					currentMenu--;
			}
			else if(keycode == KeyEvent.VK_DOWN || keycode == KeyEvent.VK_S)
			{
				if(currentMenu<2)
					currentMenu++;	
			}
			else if(keycode == KeyEvent.VK_ENTER)
			{
				switch (currentMenu)
				{
					case 1:
						parentScreen.takeInput("restart");
						screenManager.removeScreen(this);
						break;
	
					case 2:
						parentScreen.takeInput("quit");
						screenManager.removeScreen(this);
						break;
				}
			}
	}
	
	public void init()
	{
		this.position = new Point(appletDimension.width/2-(dimension.width/2), appletDimension.height/2-(dimension.height/2));
		this.posMiddle = new Point(position.x+dimension.width/2,position.y+dimension.height/2);
		
		//adding buttons
		buttons.addElement(new MenuButton("You Lose!", 50 ,  fontHighlight,color, dimension, position));
		buttons.addElement(new MenuButton("Restart", 100 ,  font, color, dimension, position));
		buttons.addElement(new MenuButton("Quit", 150 ,  font, color, dimension, position));
	}
	
	public void takeInput(String args)
	{
		
	}
	
}
