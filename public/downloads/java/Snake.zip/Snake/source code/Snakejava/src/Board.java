import java.awt.Graphics;
import java.awt.Point;
import java.util.Vector;


public class Board 
{
	Screen parentScreen;
	
	private int screenSize;
	
	//line drawing variables
	private int intervalY;
	private int intervalX;
	
	//other variables
	private int intervalD;
	private int numOfLines;
	private int boardSize;
	private int boardSpaces;
	
	private int offset;
	
	//board ids
	private int ids[][];
	
	Vector <Body> body;
	Point startingPoint;
	Head head;
	String headDirection;
	Food food;
	
	public Board(int screenSize, int boardSize, Screen parentScreen)
	{
		this.screenSize = screenSize;
		this.boardSize = boardSize;
		this.boardSpaces = boardSize*boardSize;
		this.parentScreen = parentScreen;
		this.intervalD = screenSize/boardSize;
		this.numOfLines = screenSize/intervalD;
		this.offset = intervalD/10;
		this.ids = new int[boardSize][boardSize];
		
		//snake parts
		body = new Vector<Body>();
		startingPoint = new Point(atIndex(boardSize/2),0);
		
		head = new Head(startingPoint,this.getSnakeSize(),this.getSpacing(),offset);
		headDirection = "up";
		food = new Food(new Point(this.atIndex(boardSize/2),this.atIndex(boardSize/2)),this.getSnakeSize(),offset);
		
		for(int i=0; i<3; i++)
			body.add(new Body(startingPoint,this.getSnakeSize(), offset, "vertical"));
		
		setIds();
	}
	
	public void drawBoard(Graphics gr)
	{
		//intervals for the lines
		intervalY=0;
		intervalX=0;
		
		//drawing lines
		for(int i=0; i<=numOfLines; i++)
		{
			gr.drawLine(intervalX,0,intervalX,screenSize);
			intervalX+=intervalD;
			
			gr.drawLine(0,intervalY,screenSize,intervalY);
			intervalY+=intervalD;
		}
		
		//snake parts and food drawing
		food.draw(gr);
		head.draw(gr);
		for(int i=0; i<body.size(); i++)
		{
			body.elementAt(i).draw(gr);
		}
		
	}
	
	public void update(String newDirection)
	{
		if(newDirection != "none")
			headDirection = newDirection;
		
		for(int i=body.size()-1; i>=0; i--)
		{
			if(i==0)
				body.elementAt(i).update(head.pos, getBodyType(head.pos, body.elementAt(i).pos, headDirection));
			else
				body.elementAt(i).update(body.elementAt(i-1).pos,body.elementAt(i-1).type);
		}
		

		head.update(headDirection);
		
		//check collision with side to make sure not to update the array out of boudns
		checkCollisionWithSide();
		
		//make sure this is before the collision detection
		setIds();
		
		//printArray();
		
		//collision with food
		if(head.pos.x == food.pos.x && head.pos.y == food.pos.y)
		{
			//have the use a new point because atIndex() takes an integer
			//and if recall food.newPos() it will most likely return a different coordinate
			for(int i =0; i<5; i++)
				body.addElement(new Body(new Point(body.lastElement().pos.x,body.lastElement().pos.y),this.getSnakeSize(),offset, body.lastElement().type));
			if(body.size() > boardSpaces-2) // -2 Because of head and food
			{
				parentScreen.takeInput("win");
			}
			else
			{
				Point newPos = food.newPos(ids);
				food.pos.x = atIndex(newPos.x);
				food.pos.y = atIndex(newPos.y);
			}
		}
		
		//collision with snake body
		if(ids[getIndex(head.pos.x)][getIndex(head.pos.y)] == 1 )
		{
			//System.out.println("collision with body");
			parentScreen.takeInput("loss");
		}
		
	}
	
	public void restart()
	{
		head = null;
		food = null;
		body.clear();
		
		head = new Head(startingPoint,this.getSnakeSize(),this.getSpacing(),offset);
		food = new Food(new Point(this.atIndex(boardSize/2),this.atIndex(boardSize/2)),this.getSnakeSize(),offset);
		
		for(int i=0; i<3; i++)
			body.add(new Body(startingPoint,this.getSnakeSize(), offset, "vertical"));
		
		setIds();
	}
	
	private void setIds()
	{
		resetArray();
		
		//setting head to 3 because of collision checking
		ids[getIndex(head.pos.x)][getIndex(head.pos.y)] = 3;
		ids[getIndex(food.pos.x)][getIndex(food.pos.y)] = 2;
		
		for(int i=0; i<body.size(); i++)
		{
			ids[getIndex(body.elementAt(i).pos.x)][getIndex(body.elementAt(i).pos.y)] = 1;
		}
	}
	
	private void resetArray()
	{
		for(int i=0; i<ids.length; i++)
		{
			for(int n=0; n<ids.length; n++)
			{
				ids[n][i] = 0;
			}
		}
	}
	
	@SuppressWarnings("unused")
	private void printArray()
	{
		for(int i=0; i<ids.length; i++)
		{
			for(int n=0; n<ids[0].length; n++)
			{
				System.out.print(ids[n][i]);
			}
			System.out.println("");
		}
		System.out.println("");
		System.out.println("");
	}
	
	private void checkCollisionWithSide()
	{
		if(getIndex(head.pos.x) > boardSize-1)
		{
			//System.out.println("collision with right side");
			head.pos.x = atIndex(0);
		}
		else if(getIndex(head.pos.x) < 0)
		{
			//System.out.println("collision with left side");
			head.pos.x = atIndex(boardSize-1);
		}
		else if(getIndex(head.pos.y) < 0)
		{
			//System.out.println("collision with top side");
			head.pos.y = atIndex(boardSize-1);
		}
		else if(getIndex(head.pos.y) > boardSize-1)
		{
			//System.out.println("collision with bottom side");
			head.pos.y = atIndex(0);
		}
	}
	
	private int getIndex(int x)
	{
		return (x)/intervalD;
	}
	
	private int getSnakeSize()
	{
		return intervalD-offset*2;
	}
	
	private int getSpacing()
	{
		return intervalD;
	}
	
	private int atIndex(int x)
	{
		return (x)*intervalD;
	}
	
	private String getBodyType(Point headPos, Point bodyPos, String headDirection)
	{
		String type = "vertical";
		
		if(headPos.y == bodyPos.y)
		{
			if(headDirection == "left" || headDirection == "right")
			{
				type = "horizontal";
			}
			else if(headDirection == "up")
			{
				if(headPos.x < bodyPos.x)
					type = "rightUp";
				else if(headPos.x > bodyPos.x)
					type = "leftUp";
			}
			else if(headDirection == "down")
			{
				if(headPos.x < bodyPos.x)
					type = "rightDown";
				else if(headPos.x > bodyPos.x)
					type = "leftDown";
			}
		}
		else if(headPos.x == bodyPos.x)
		{
			if(headDirection == "up" || headDirection == "down")
			{
				type = "vertical";
			}
			else if(headDirection == "right")
			{
				if(headPos.y < bodyPos.y)
					type = "rightDown";  //same as upRight
				else if(headPos.y > bodyPos.y)
					type = "rightUp";  //same as downRight
			}
			else if(headDirection == "left")
			{
				if(headPos.y < bodyPos.y)
					type = "leftDown";  //upLeft
				else if(headPos.y > bodyPos.y)
					type = "leftUp";  //downLeft
			}
		}
		
		return type;
	}
}
