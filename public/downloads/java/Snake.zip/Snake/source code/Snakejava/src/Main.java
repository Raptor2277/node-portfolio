import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class Main extends JPanel implements Runnable, KeyListener
{
	final int screenSize = 600;
	
	//this is about 30 fps, this used to be the snake speed and it would be at about 150
	//however, this delay doesn't effect only the snake update, it effects every screen's update
	//giving the gamescreen its own update logic and lowering this delay removes the other screen's input delay
	final int delay = 16; 
	
	Dimension screen;
	
	ScreenManager screenM ;
	
	Thread t;
	
	public static void main(String [] args)
	{
		JFrame frame = new JFrame("Snake Game");
		//the setsize() method for JFrame includes the borders
		//so we add the JPannel aka Main(), to the content pane and we set its preferred size in the constructor
		frame.getContentPane().add(new Main());
		//pack will then set the size of the frame accordingly so the JPannel fits in
		frame.pack();
		frame.setLocation(100, 100);
		frame.setResizable(false);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public Main()
	{
		screen = new Dimension(screenSize,screenSize);
		super.setPreferredSize(screen);
		
		screenM = new ScreenManager(screen);
		
		//init of classes
		
		t = new Thread(this);
		t.start();
		
		screenM.addScreen(new MainMenuScreen(screen));
		
		addKeyListener(this);
		setFocusable(true);
	}
	
	public void paint(Graphics g)
	{
		Graphics2D gr = (Graphics2D) g;
		//clear
		gr.setColor(Color.WHITE);
		gr.fillRect(0, 0, screen.width+1, screen.height+1);
		gr.setColor(Color.red);
		
		//draw
		screenM.draw(gr);
	}
	
	public void update(Graphics g)
	{
		paint(g);
	}

	@Override
	public void run() 
	{	
		while(true)
		{
			//logic and updates
			screenM.update();
			
			repaint();
			
			//sleep
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void keyPressed(KeyEvent e) 
	{
		screenM.handleInput(e.getKeyCode());
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		
	}
}
