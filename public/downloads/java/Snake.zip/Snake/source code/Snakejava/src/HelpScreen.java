import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.util.Vector;

public class HelpScreen extends Screen
{
	Vector <MenuButton> buttons;
	int currentMenu;
	
	Font font = new Font("Times New Roman", Font.PLAIN, 30);
	Font fontI = new Font("Times New Roman", Font.ITALIC, 25);
	Font bigFont = new Font("Times New Roman", Font.BOLD, 50);
	Color color = Color.black;
	Color bigColor = Color.blue;
	
	public HelpScreen(Screen parentScreen, Dimension appletDimention)
	{
		this.appletDimension = appletDimention;
		this.dimension = appletDimension;
		this.parentScreen = parentScreen;
		this.position = new Point(0,0);
		
		this.isActive = true;
		this.isDrawn = true;
		
		this.buttons = new Vector<MenuButton>();
		this.currentMenu = 1;
		
		buttons.addElement(new MenuButton("Help Menu", 100,  bigFont, bigColor, this.dimension, this.position));
		buttons.addElement(new MenuButton("Return", 500,font,color,this.dimension, this.position));
		buttons.addElement(new MenuButton("Use the arrow keys or WASD to change", 200,  fontI, color, this.dimension, this.position));
		buttons.addElement(new MenuButton("the snake direction.", 230,  fontI, color, this.dimension, this.position));
		buttons.addElement(new MenuButton("Use Enter or Escape to bring up the pause menu", 300,  fontI, color, this.dimension, this.position));
		buttons.addElement(new MenuButton("Use Enter to change values in the main menu", 400,  fontI, color, this.dimension, this.position));
	}
	
	public void draw(Graphics2D gr)
	{
		for(int i=0; i<buttons.size(); i++)
		{
			buttons.elementAt(i).draw(gr);
		}
	}
	
	public void update()
	{
		for(int i=0; i<buttons.size(); i++)
		{
			if(i == currentMenu)
				buttons.elementAt(i).isHighlighted = true;
			else
				buttons.elementAt(i).isHighlighted= false;
		}
	}
	
	public void handleInput(int keycode)
	{
		if(keycode == KeyEvent.VK_ENTER)
		{
			screenManager.removeScreen(this);
			parentScreen.takeInput("quit");
		}
	}

	public void init()
	{
		
	}
	
	public void takeInput(String args)
	{
		
	}

}
