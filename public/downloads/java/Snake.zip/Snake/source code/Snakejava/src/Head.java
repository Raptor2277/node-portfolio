import java.awt.Graphics;
import java.awt.Point;

public class Head 
{
	public Point pos;
	public int size;
	public int spacing;
	public int offset;
	String direction;
	
	public Head(Point pos, int size, int spacing, int offset)
	{
		this.pos = new Point(pos);
		this.size = size;
		this.spacing =spacing;
		this.offset = offset;
		direction = "down";
	}
	
	public void draw(Graphics gr)
	{
		gr.fillRect(pos.x + offset, pos.y+offset, size, size);
	}
	
	public void update(String dir)
	{
		updateDirection(dir);
		
		if(this.direction == "up")
		{
			pos.y-=spacing;
		}
		else if(this.direction == "down")
		{
			pos.y+=spacing;
		}
		else if(this.direction == "left")
		{
			pos.x-=spacing;
		}
		else if(this.direction == "right")
		{
			pos.x+=spacing;
		}
	}
	
	public void updateDirection(String dir)
	{
		if(dir == "up" && this.direction != "down")
		{
			this.direction = dir;
		}
		else if(dir == "down" && this.direction != "up")
		{
			this.direction = dir;
		}
		else if(dir == "left" && this.direction != "right")
		{
			this.direction = dir;
		}
		else if(dir == "right" && this.direction != "left")
		{
			this.direction = dir;
		}
	}
}
