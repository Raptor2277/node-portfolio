import java.awt.Dimension;
import java.awt.Graphics2D;
import java.util.Vector;


public class ScreenManager
{

	Vector <Screen> screens;
	Dimension appletDimension;
	
	ScreenManager(Dimension appletDimension)
	{
		screens = new Vector <Screen>();
		this.appletDimension = appletDimension;
	}
	
	public void draw(Graphics2D gr)
	{
		for(int i=0; i<screens.size(); i++)
		{
			if(screens.elementAt(i).isDrawn)
				screens.elementAt(i).draw(gr);
		}
	}
	
	public void update()
	{
		for(int i=0; i<screens.size(); i++)
		{
			if(screens.elementAt(i).isActive)
				screens.elementAt(i).update();
		}
	}
	
	public void handleInput(int keycode)
	{
		//creating a temp screens int so it does't send handle input immediately after a screen is created
		//for example if screen @ index one creates a new screen, screen.size() will increase and it will
		//continue to loop and send the input to the new screen next loop
		int tempScreens = screens.size();
		
		for(int i=0; i<tempScreens; i++)
		{
			if(screens.elementAt(i).isActive)
				screens.elementAt(i).handleInput(keycode);
		}
	}
	
	public void addScreen(Screen screen)
	{
		screen.screenManager = this;
		screen.appletDimension = this.appletDimension;
		screen.init();
		screens.addElement(screen);
	}

	public void removeScreen(Screen screen)
	{
		screens.removeElement(screen);
	}
}
