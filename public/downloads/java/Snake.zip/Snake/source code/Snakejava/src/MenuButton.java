import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.Vector;

public class MenuButton
{
	//text variables
	FontMetrics fontMetrics;
	Vector<String>text;
	int currentText;
	Rectangle textBox;
	
	//position and size
	Point position;
	int height;
	int width;
	int offset;
	
	//drawing methods
	boolean isHighlighted;
	
	//graphics
	Font font;
	Color color;
	
	//parent Parameters
	Point parentPosition;
	Dimension parentDimension;
	Point parentMiddle;
	
	public MenuButton(String text, int offset, Font font,Color color, Dimension parentDimension, Point parentPosition)
	{
		this.text = new Vector<String>();
		this.text.addElement(text);
		this.currentText = 0;
		
		this.font = font;
		this.color = color;
		
		this.parentPosition = parentPosition;
		this.parentDimension = parentDimension;
		this.parentMiddle = new Point(parentPosition.x+parentDimension.width/2,parentPosition.y+parentDimension.height/2);
		
		this.offset = offset;
		this.height = font.getSize();
		
		this.isHighlighted = false;
		
	}
	
	public void draw(Graphics2D gr)
	{
		gr.setFont(font);
		this.fontMetrics = gr.getFontMetrics();
		getTextMetrics();
		drawStringCentered(gr);
	}
	
	private void drawStringCentered(Graphics gr)
	{
		gr.setColor(color);
		gr.drawString(text.elementAt(currentText), position.x, position.y);
		
		if(isHighlighted)
			gr.drawRect(textBox.x, textBox.y, textBox.width, textBox.height);
	}
	
	public void addText(String str)
	{
		text.addElement(str);
	}
	
	public void nextText()
	{
		currentText++;
		if(currentText>text.size()-1)
			currentText=0;
		getTextMetrics();
	}
	
	public void previousText()
	{
		currentText--;
		if(currentText<0)
			currentText=text.size()-1;
		getTextMetrics();
	}
	
	public void changeTextIndex(int index)
	{
		currentText=index;
	}
	
	private void getTextMetrics()
	{
		this.width = fontMetrics.stringWidth(text.elementAt(currentText));
		this.textBox = new Rectangle(parentMiddle.x-(width/2), parentPosition.y+offset-(this.height)+(height/5), width, height);
		this.position = new Point(parentMiddle.x-(width/2), parentPosition.y+offset);
	}
}
