import java.awt.Graphics;
import java.awt.Point;


public class Body {

	public Point pos;
	public int size;
	public int offset;
	public String type;
	
	public Body(Point pos, int size, int offset, String type)
	{
		this.pos = new Point(pos);
		this.size = size;
		this.offset = offset;
		this.type = type;
	}
	
	public void draw(Graphics gr)
	{
		if(type == "vertical")
			gr.fillRect(pos.x+offset, pos.y, size, size+(offset*2));
		
		else if(type == "horizontal")
			gr.fillRect(pos.x, pos.y+offset, size+(offset*2), size );
		
		else if(type == "rightUp")
		{
			gr.fillRect(pos.x+offset, pos.y, size, size+(offset));
			gr.fillRect(pos.x+offset, pos.y+offset, size+(offset), size);
		}
		
		else if(type == "rightDown")
		{
			gr.fillRect(pos.x+offset, pos.y+offset, size, size+(offset));
			gr.fillRect(pos.x+offset, pos.y+offset, size+(offset), size);
		}
		
		else if(type == "leftUp")
		{
			gr.fillRect(pos.x, pos.y+offset, size+(offset), size );
			gr.fillRect(pos.x+offset, pos.y, size, size+offset);
			
		}
		
		else if(type == "leftDown")
		{
			gr.fillRect(pos.x, pos.y+offset, size+(offset), size );
			gr.fillRect(pos.x+offset, pos.y+offset, size, size+offset);
			
		}
	}
	
	public void update(Point prevPoint, String type)
	{
		//update the type
		this.type = type;
		
		//setting this body's position to the previous body's position
		pos.x=prevPoint.x;
		pos.y=prevPoint.y;
	}
}
