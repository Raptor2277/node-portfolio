import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.util.Random;
import java.util.Vector;


public class Food 
{
	public Point pos;
	public int size;
	public int offset;
	Random rand;
	Vector <Point> availableSpots;
	Color c;
	
	public Food(Point pos, int size, int offset)
	{
		//initializing the variables
		this.pos = new Point(pos);
		this.size = size;
		this.offset = offset;
		this.rand = new Random();
		this.availableSpots = new Vector <Point>();
		this.c = Color.green;
	}
	
	public void draw(Graphics gr)
	{
		//self explanatory
		gr.setColor(c);
		gr.fillRect(pos.x+offset, pos.y+offset, size, size);
		gr.setColor(Color.red);
	}
	
	public Point newPos(int[][] board)
	{
		//clear the vector
		availableSpots.clear();
		
		//loop through the board and add the coordinates of the empty spaces to 
		//the vector
		for(int i=0; i<board.length; i++)
		{
			for(int n=0; n<board[0].length; n++)
			{
				if(board[n][i] == 0)
					availableSpots.add(new Point(n,i));
			}
		}
		
		//nextInt is 0 inclusive and parameter exclusive
		//return a random available spot
		return availableSpots.elementAt(rand.nextInt(availableSpots.size()));
	}
}
