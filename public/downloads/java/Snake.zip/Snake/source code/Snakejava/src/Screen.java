import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Point;



public abstract class Screen
{
	//methods that get set by the screen manager and thus are null when the subsclass initializes
	//if the subclass wants to use one of these, they will use them in the init() method
	ScreenManager screenManager;
	Dimension appletDimension;
	
	Dimension dimension;
	Point position;
	Screen parentScreen;
	
	boolean isActive = false;
	boolean isDrawn = false;
	
	public abstract void draw(Graphics2D gr);
	
	public abstract  void update();
	
	public abstract void handleInput(int keycode);
	
	public abstract void init();
	
	public abstract void takeInput(String args);
}
