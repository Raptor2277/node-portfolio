package gui;

import java.awt.Color;
import java.awt.Graphics2D;

public class Arrow {
	
	public Type direction;

    public enum Type
    {
        downLeft,
        downRight,
        upLeft,
        upRight,
        left,
        right,
        none
    }

    public Arrow(Type dir)
    {
        this.direction = dir;
    }

    public void draw(Graphics2D g)
    {
    	g.setColor(Color.green);
        switch(direction)
        {
            case downRight:
                g.drawLine( 450, 300, 450, 400);
                g.drawLine( 450, 400, 463, 384);
                g.drawLine( 450, 400, 437, 384);
                break;

            case downLeft:
                g.drawLine( 50, 300, 50, 400);
                g.drawLine( 50, 400, 63, 384);
                g.drawLine( 50, 400, 37, 384);
                break;
                
            case upRight:
                g.drawLine( 450, 300, 450, 400);
                g.drawLine( 450, 300, 463, 316);
                g.drawLine( 450, 300, 437, 316);
                break;

            case upLeft:
                g.drawLine( 50, 300, 50, 400);
                g.drawLine( 50, 300, 63, 316);
                g.drawLine( 50, 300, 37, 316);
                break;

            case left:
                g.drawArc(140, 150, 210, 200, 10, 118);
                g.drawLine( 180, 172, 187, 153);
                g.drawLine( 180, 172, 198, 173);
                break;

            case right:
                g.drawArc(140, 150, 210, 200, 12, 120);
                g.drawLine( 348, 230, 355, 216);
                g.drawLine( 348, 230, 335, 220);
                break;
                
            case none:
            	break;
        }
    }
}
