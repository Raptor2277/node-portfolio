package Framework;
import java.util.LinkedList;
import java.util.Queue;

public class BreadthFirstSolver extends Solver {
	
	private Queue<State> queue = new LinkedList<State>();

	protected void addState(State s) {
		if (!queue.contains(s))
			queue.offer(s);
	}
	
	protected boolean hasElements() {
		return !queue.isEmpty();
	}

	protected State nextState() {
		return queue.remove();
	}
	
	protected void clearOpen() {
		queue.clear();
	}

	public String toString(){return "Breadth First Solver";}

}
