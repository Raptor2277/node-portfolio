package main;
import java.util.HashSet;
import java.util.Set;

import Framework.State;

public class WaterJugState extends State{
	
	public int fourGallon = 0;
	public int threeGallon = 0;
	
	public int finalFour;
	public int finalThree;
	
	public WaterJugState(int finalFour, int finalThree){
		this.finalFour = finalFour;
		this.finalThree = finalThree;
	}
	
	public WaterJugState(WaterJugState parent, int four, int three){
		super(parent);
		this.fourGallon = four;
		this.threeGallon = three;
		this.finalFour = parent.finalFour;
		this.finalThree = parent.finalThree;
	}

	public Iterable<State> getPossibleMoves() {
		Set<State> moves = new HashSet<State>();
		
		//empty 4g
		if(fourGallon != 0) moves.add(new WaterJugState(this, 0, this.threeGallon));
		
		//empty 3g
		if(threeGallon != 0) moves.add(new WaterJugState(this, this.fourGallon, 0));
		
		//fill 4g
		if(fourGallon != 4) moves.add(new WaterJugState(this, 4, this.threeGallon));
		
		//fill 3g
		if(threeGallon != 3) moves.add(new WaterJugState(this, this.fourGallon, 3));
		
		//3g --> 4g
		if(threeGallon > 0 && fourGallon < 4){
			int capacity = 4 - this.fourGallon;
			int transferAmmount = this.threeGallon;
			if(transferAmmount > capacity)
				transferAmmount = capacity;
			moves.add(new WaterJugState(this, this.fourGallon + transferAmmount, this.threeGallon - transferAmmount));
		}
		
		//4g --> 3g
		if(fourGallon > 0 && threeGallon < 3){
			int capacity = 3 - this.threeGallon;
			int transferAmmount = this.fourGallon;
			if(transferAmmount > capacity)
				transferAmmount = capacity;
			moves.add(new WaterJugState(this, this.fourGallon - transferAmmount, this.threeGallon + transferAmmount));
		}
		
		return moves;
	}

	public boolean isSolution() {
		return fourGallon == finalFour && threeGallon == finalThree;
	}

	public double getHeuristic() {
		int sum = 0;
		if(fourGallon == 2) sum++;
		if(threeGallon == 0) sum++;
		return sum;
	}
	
	public boolean equals(Object o){
		if (o==null || !(o instanceof WaterJugState))
            return false;
        WaterJugState sender = (WaterJugState)o;
        return fourGallon == sender.fourGallon && threeGallon == sender.threeGallon;
	}
	
	public int hashCode(){
		return 3 * fourGallon + 5 * threeGallon;
	}
	
	public String toString(){
		return ("4 Gal: " + fourGallon + "  3 Gal: " + threeGallon + "  (heuristic: " + getHeuristic() + ")");
	}

}
