package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;

public class WaterJug {
	
	public enum Types
    {
        fourGallon,
        threeGallon,
    }

    private Types type;
    private Point pos;
    private String label;
    private Font font;
    public float water;

    public WaterJug(Point pos, String label, float water, Types type)
    {
        this.pos = pos;
        this.label = label;
        this.water = water;
        this.type = type;
        this.font = new Font("Times New Roman", Font.PLAIN, 24);
    }

    public void draw(Graphics2D gr)
    {	
        if (this.type == Types.fourGallon)
        {
            //jug
        	gr.setColor(Color.RED);
            gr.drawRect(pos.x, pos.y, 100, 200);

            //water
            drawWater(gr);

            //lables
            gr.drawLine(pos.x, pos.y + 50, pos.x + 20, pos.y + 50);
            gr.drawLine(pos.x, pos.y + 100, pos.x + 20, pos.y + 100);
            gr.drawLine(pos.x, pos.y + 150, pos.x + 20, pos.y + 150);

            //label bot
            gr.setFont(font);
            gr.setColor(Color.black);
            gr.drawString(label, pos.x + 20, pos.y + 220);
        }
        else if (this.type == Types.threeGallon)
        {
            //jug
        	gr.setColor(Color.RED);
            gr.drawRect(pos.x, pos.y + 50, 100, 150);

            //water
            drawWater(gr);

            //labes
            gr.drawLine(pos.x, pos.y + 100, pos.x + 20, pos.y + 100);
            gr.drawLine(pos.x, pos.y + 150, pos.x + 20, pos.y + 150);

            //label bot
            gr.setFont(font);
            gr.setColor(Color.black);
            gr.drawString(label, pos.x + 20, pos.y + 220);
        }
       
    }

    public void drawWater(Graphics gr)
    {
        float height = water * 50f;
        gr.setColor(Color.blue);
        gr.fillRect(pos.x+2, pos.y + 200 - (int)height, 97, (int)height);
        gr.setColor(Color.red);
    }
}
