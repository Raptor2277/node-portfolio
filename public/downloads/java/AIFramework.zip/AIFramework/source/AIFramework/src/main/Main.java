package main;

import gui.Arrow;
import gui.DrawPanel;
import gui.StateChanges;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.*;

import Framework.*;


public class Main {
	
	public static JTextArea text;
	public static DrawPanel drawPanel;
	public static JScrollPane scrollPane;
	public static State initialState;
	public static boolean workerRunning = false;
	private static boolean firstTime = true;
	
	public static void main(String[] args) {
		
		text = new JTextArea(10,10);
		text.setFont(new Font("Times New Ronam", Font.PLAIN, 14));
		
		drawPanel = new DrawPanel();
		
		scrollPane = new JScrollPane(text);
		scrollPane.setPreferredSize(new Dimension(120,400));
		
		JComboBox<String> b = new JComboBox<String>();
		b.setPreferredSize(new Dimension(100,5));
		b.setBorder(BorderFactory.createEmptyBorder(2, 0, 0, 2));
		b.addItem("DepthFirstSolver");
		b.addItem("BreadthFirstSolver");
		b.addItem("BestFirstSolver");
		
		JTextField field = new JTextField("2", 2);
		JTextField field2 = new JTextField("0", 2);
		JLabel label = new JLabel("Insert Final State");
		JButton button = new JButton();
		button.setPreferredSize(new Dimension(75,35));
		button.setText("Start");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
			        public Void doInBackground() {
			        	Main.workerRunning = true;
			        	button.setText("Running");
			        	int four = Integer.parseInt(field.getText());
			        	int three = Integer.parseInt(field2.getText());
			        	switch(b.getSelectedIndex())
			        	{
			        	case 0:
			        		Main.trySolver(new WaterJugState(four,three), new DepthFirstSolver());
			        		break;
			        	case 1:
			        		Main.trySolver(new WaterJugState(four,three), new BreadthFirstSolver());
			        		break;
			        	case 2:
			        		Main.trySolver(new WaterJugState(four,three), new BestFirstSolver());
			        		break;
			        	}
			        	
			        	Main.workerRunning = false;
			        	button.setText("Start");
						return null;
			        }

			    };
			    if(!workerRunning)
			    worker.execute();
			}
		});
		
		JPanel inputPanel = new JPanel();
		inputPanel.setLayout(new FlowLayout());
		inputPanel.add(button);
		inputPanel.add(field);
		inputPanel.add(field2);
		inputPanel.add(label);
		
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.add(scrollPane);
		panel.add(b);
		panel.add(inputPanel);
		
		JFrame frame = new JFrame();
		frame.getContentPane().add(drawPanel, BorderLayout.WEST);
		frame.getContentPane().add(panel, BorderLayout.EAST);
		frame.pack();
		frame.setTitle("\nWater Jug AI");
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		writeLine("Water Jug Problem");
		writeLine("----------------------------------------------");
		
	}

	private static void trySolver(State initialState, Solver solver) {
		drawPanel.reset();
		List<State> solutionPath = solver.solve(initialState);  
		
		writeLine("Solving with "+solver);
		writeLine("  States visited: "+solver.getVisitedStateCount());
		writeLine("  Solution Path:");
		
		if (solutionPath == null) {
			writeLine("    None found.");
		} else {
			WaterJugState previousState = null;
			for (State s : solutionPath){
				writeLine("    "+s);
				if(previousState == null && !firstTime){
					drawPanel.animate(new StateChanges(0, 0, Arrow.Type.none, "Starting State"));
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				else if(previousState != null){
					drawPanel.animate(StateChanges.getStateChanges(previousState, (WaterJugState)s));
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				previousState = (WaterJugState)s;
			}
				
			writeLine("Solution path contains "+solutionPath.size()+" states(s)");
			writeLine("----------------------------------------------");
		}
		firstTime = false;
	}
	
	public static void writeLine(String s){
		text.append(s + "\n");
		JScrollBar scroll = scrollPane.getVerticalScrollBar();
		scroll.setValue(scroll.getMaximum());
		try {
			Thread.sleep(50);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
