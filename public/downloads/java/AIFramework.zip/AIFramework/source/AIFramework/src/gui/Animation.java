package gui;

public class Animation extends Thread{

	private DrawPanel panel;
	private StateChanges change;
	
	public Animation(DrawPanel p, StateChanges change){
		this.panel = p;
		this.change = change;
		this.panel.arrow.direction = change.arrowType;
	}
	
	public void run(){
		float rightJugIncrement = change.rightJugWaterChange / 100f;
		float leftJugIncrement = change.leftJugWaterChange / 100f;
		int frames = 0;
        while (frames < 100)
        {
            panel.leftJug.water +=  leftJugIncrement;
            panel.rightJug.water +=  rightJugIncrement;
            try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
            panel.repaint();
            frames++;
        }
	}
}
