package Framework;
import java.util.List;

public interface iSolver {
	
	public List<State> solve(State initialState );
	
}
