package gui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class DrawPanel extends JPanel{

	public WaterJug leftJug;
	public WaterJug rightJug;
	public Arrow arrow;
	public String head = "Starting State";
	public Font font;
	
	public DrawPanel()
	{
		this.setPreferredSize(new Dimension(500,500));
		this.leftJug = new WaterJug(new Point(100,200), "4 Gal", 0f, WaterJug.Types.fourGallon);
		this.rightJug = new WaterJug(new Point(300,200), "3 Gal", 0f, WaterJug.Types.threeGallon);
		this.arrow = new Arrow(Arrow.Type.none);
		
		this.font = new Font("Sans Serif", Font.PLAIN, 26);
	}
	
	public void paint(Graphics g){
		Graphics2D gr = (Graphics2D)g;
		gr.setStroke(new BasicStroke(3));
		gr.setColor(Color.WHITE);
		gr.fillRect(0, 0, 499, 499);
		gr.setColor(Color.BLACK);
		gr.drawRect(0, 0, 499, 499);
		
		gr.setFont(font);
		gr.drawString(head, 100, 100);
		
		leftJug.draw(gr);
		rightJug.draw(gr);
		arrow.draw(gr);
	}

	public void animate(StateChanges stateChange){
		this.head = stateChange.head;
		new Animation(this, stateChange).run();
	}
	
	public void reset(){
		this.leftJug.water = 0;
		this.rightJug.water = 0;
		this.arrow.direction = Arrow.Type.none;
		this.head = "Starting State";
	}
}
