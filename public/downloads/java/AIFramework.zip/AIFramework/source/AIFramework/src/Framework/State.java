package Framework;

public abstract class State implements iState {
	
	private State parent = null;
	private double distance = 0;
	
	public State() {
		
	}
	
	public State(State parent){
		this.parent = parent;
		this.distance = parent.getDistance() + 1;
	}
	
	public State getParent(){
		return parent;
	}
	
	public double getDistance(){
		return distance;
	}
}
