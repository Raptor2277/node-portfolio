package Framework;

import java.lang.Iterable;
import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.util.LinkedList;

/**
 * This class implements Solver and provides functionality for automating state
 * solving using a generic iterable interface.  The explored set is handled
 * implicitly (defined as a HashSet), so states need to define a valid 
 * hashCode() and equals() function for this solver to function correctly.
 *  
 * @author Marcello
 */
public abstract class Solver implements iSolver {
	
	private Set<State> explored = new HashSet<State>();

	public List<State> solve(State initialState) {
		// Reset explored set
		explored.clear();
		clearOpen(); //discovered but not explored
		addState(initialState);
		while (hasElements()) {
			State s = nextState();
			if (s.isSolution())
				return findSolutionPath(s);
			explored.add(s);
			Iterable<State> moves = s.getPossibleMoves();
			for (State move : moves)
				if (!explored.contains(move))
					addState(move);
		}
		return null;
	}

	public int getVisitedStateCount() {
		return explored.size();
	}

	private List<State> findSolutionPath(State finalState) {
		LinkedList<State> path = new LinkedList<State>();
		while (finalState != null) {
			path.addFirst(finalState);
			finalState = finalState.getParent();
		}
		return path;
	}

	protected abstract boolean hasElements();

	protected abstract State nextState();

	protected abstract void addState(State s);
	
	protected abstract void clearOpen();

}