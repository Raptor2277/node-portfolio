package gui;

import gui.Arrow;
import main.WaterJugState;

public class StateChanges {
	
	public int leftJugWaterChange;
	public int rightJugWaterChange;
	public Arrow.Type arrowType;
	public String head;
	
	public StateChanges(int leftJug, int rightJug, Arrow.Type type, String head){
		 this.leftJugWaterChange = leftJug;
		 this.rightJugWaterChange = rightJug;
		 this.arrowType = type;
		 this.head = head;
	}
	
	public static StateChanges getStateChanges(WaterJugState a, WaterJugState b){
		int left = b.fourGallon - a.fourGallon;
		int right = b.threeGallon - a.threeGallon;
		
		Arrow.Type type = Arrow.Type.downRight;
		String head = "";
		
		if(left < 0 && right > 0 )
		{
			head = "Pour left into right";
			type = Arrow.Type.right;
		} 
		else if(left > 0 && right < 0 )
		{
			head = "Pour right into left";
			type = Arrow.Type.left;
		} 
		else if(left == 0 && right > 0)
		{
			head = "Fill right Jug";
			type = Arrow.Type.upRight;
		}
		else if(left > 0 && right == 0)
		{
			head = "Fill left Jug";
			type = Arrow.Type.upLeft;
		}
		else if(left == 0 && right < 0)
		{
			head = "Empty right Jug";
			type = Arrow.Type.downRight;
		}
		else if(left < 0 && right == 0)
		{
			head = "Empty left Jug";
			type = Arrow.Type.downLeft;
		}
		
		return new StateChanges(left, right, type, head);
	}

}
