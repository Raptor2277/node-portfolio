[Instructions]
	The problem is: there are two jugs(four gallon and three gallon) and unlimited
	supply of water. The goal is to end up with 2 gallons in the four gallon jug and 0 in the 3 gallon jug(this goal can be modified). The legal moves are
	to emty or fill the jugs and to transfer from one to the other. YOU CANNOT ESTIMATE, the only
	sure thing is that one jub holds 4 gallons and the other holds 3 gallons.

[Objective]
	Using the AI framework from our textbook, define a state class so that it solves the problem.