[Controls - Game]
	follow the game instructions

[Controls - Level Editor]
	use Q to change block
	use left mouse button to place block - hold and drag method also works
	use right mouse button to remove block - hold and drag works
	use escape to bring up the menu
	[menu]
		options - change level editor options
		pause/upause blocks - moving blocks placed will be paused, use this to unpause
		rest - self explanatory
	
[Blocks]
	red block - actor block that moves around
	blue block - block the actor must get to finish the level
	white block - tile for moving on
	red dash - use this to add movement to blocks, click on an already placed block to draw a path
	spike - add spikes that resets the actor block

[Custom Level]
	not yet implemented
	the level editor can be used to test created levels, use the load level option to load saved level