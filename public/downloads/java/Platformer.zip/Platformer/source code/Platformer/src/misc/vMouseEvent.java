package misc;

public class vMouseEvent 
{

	public final static int MOUSE_DOWN = 0;
	public final static int MOUSE_UP = 1;
	public final static int MOUSE_MOTION = 3;
	
	public final static int MOUSE_BUTTON_LEFT = 1;
	public final static int MOUSE_BUTTON_MIDDLE = 2;
	public final static int MOUSE_BUTTON_RIGHT = 3;
	
	public int button;
	public int type;
	
	public int x;
	public int y;
	
	public vMouseEvent(int button, int type, int x, int y)
	{
		this.button = button;
		this.type = type;
		this.x = x;
		this.y = y;
	}
	
	public vMouseEvent(int type, int x, int y)
	{
		this.type = type;
		this.x = x;
		this.y = y;
	}
}
