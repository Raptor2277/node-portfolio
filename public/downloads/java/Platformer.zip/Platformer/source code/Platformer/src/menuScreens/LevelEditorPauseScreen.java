package menuScreens;

import java.awt.Dimension;
import java.awt.Graphics2D;

import managers.MenuScreen;
import misc.OptionsCarrier;
import bases.Screen;

public class LevelEditorPauseScreen extends MenuScreen
{
	OptionsCarrier options;
	
	public LevelEditorPauseScreen(String title, Dimension srcDimension,int size, Screen parentScreen) {
		super(title, srcDimension, size, parentScreen);
		
	}

	protected void init(Graphics2D gr)
	{
		this.options = parentScreen.getOptions();
		addButton(new String [] {"Continue"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"Options"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"Unpause Blocks", "Pause Blocks"}, this.buttonFont, this.buttonColor);
		if(!options.blocksPaused)
			buttons.elementAt(2).changeTextIndex(1);
		addButton(new String [] {"Clear Level"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"New Level"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"Load Level"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"Save Level"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"Save and Quit"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"Quit"}, this.buttonFont, this.buttonColor);
	}
	
	protected void buttonClick(int buttonIndex)
	{
		switch (buttonIndex) {
		case 0:
			screenManager.remove(this);
			parentScreen.pause();
			break;
		case 1:
			screenManager.remove(this);
			parentScreen.takeInput("options");
			break;
		case 2:
			screenManager.remove(this);
			parentScreen.takeInput("pause blocks");
			break;
		case 3:
			screenManager.remove(this);
			parentScreen.takeInput("clear");
			break;
		case 4:
			screenManager.remove(this);
			parentScreen.takeInput("new");
			break;
		case 5:
			screenManager.remove(this);
			parentScreen.takeInput("load");
			break;
		case 6:
			screenManager.remove(this);;
			parentScreen.takeInput("save");
			break;
		case 7:
			screenManager.remove(this);
			parentScreen.takeInput("save and quit");
			break;
		case 8:
			screenManager.remove(this);
			parentScreen.takeInput("quit");
			break;
		}
	}
}
