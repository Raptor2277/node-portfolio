package misc;

public class OptionsCarrier 
{
	public boolean showGrid;
	public boolean lockToGrid;
	public boolean blocksPaused;
	
	public OptionsCarrier(boolean showGrid, boolean lockToGrid, boolean blocksPaused)
	{
		this.showGrid = showGrid;
		this.lockToGrid = lockToGrid;
		this.blocksPaused = blocksPaused;
	}
	
}
