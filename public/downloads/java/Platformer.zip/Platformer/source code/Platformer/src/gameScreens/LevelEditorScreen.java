package gameScreens;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;
import javax.swing.JOptionPane;
import main.Main;
import main.Player;
import managers.ContentManager;
import menuScreens.LevelEditorOptionsScreen;
import menuScreens.LevelEditorPauseScreen;
import misc.Collision;
import misc.OptionsCarrier;
import misc.vKeyEvent;
import misc.vMouseEvent;
import bases.Actor;
import bases.Block;
import bases.Screen;
import blocks.ExitTile;
import blocks.MovingTile;
import blocks.Spike;
import blocks.Tile;
import blocks.GuideBlock;

public class LevelEditorScreen extends Screen
{
	public Scanner read;
	public String level;
	
	public ContentManager content;
	
	public boolean showGrid;
	public boolean lockToGrid;
	
	public String tip;
	public Font font;
	public Color color;
	public int x;
	public int offset;
	public boolean init;
	
	public int tile = 0;
	public int numberOfTiles = 5;
	
	public GuideBlock guide;
	
	public Block selectedBlock;
	public Point startGuide;
	public Point endGuide;
	public boolean drawGuide;
	public boolean blocksPaused;
	
	public LevelEditorScreen(Screen parentScreen)
	{
		this.parentScreen = parentScreen;
		this.position = new Point(0,0);
		
		this.content = new ContentManager();
		
		this.level = null;
		
		this.isActive = true;
		this.isDrawn = true;
		this.showGrid = true;
		this.lockToGrid = true;
		this.keys = new boolean[256];
		this.buttons = new boolean[5];
		this.buttons = Main.getButtons();
		
		this.tip = "";
		this.font = new Font("times new roma", Font.ITALIC, 40);
		this.color = Color.BLACK;
		this.x = 0;
		this.offset = 0;
		this.init = false;
		
		this.guide = new GuideBlock(Main.getMouseX(), Main.getMouseY());
		
		this.selectedBlock = null;
		this.startGuide = new Point(0,0);
		this.endGuide = new Point(0,0);
		this.drawGuide = false;
		this.blocksPaused = true;
	}

	@Override
	public void init() 
	{
		this.dimension = appDimension;
	}

	@Override
	public void draw(Graphics2D gr) 
	{
		if(init)
		{
			getTextMetrics(gr);
			init = false;
		}
		
		if(showGrid)
			drawGrid(gr);
		gr.setColor(color);
		gr.setFont(font);
		gr.drawString(tip, this.x, offset + font.getSize());
		
		guide.draw(gr);
		
		if(drawGuide)
			gr.drawLine(startGuide.x, startGuide.y, endGuide.x, endGuide.y);
		
		content.draw(gr);
	}

	@Override
	public void update() 
	{
		if(buttons[vMouseEvent.MOUSE_BUTTON_LEFT] && tile != 0 && tile !=3)
			handleMouseInput(new vMouseEvent(vMouseEvent.MOUSE_BUTTON_LEFT, vMouseEvent.MOUSE_DOWN, Main.getMouseX(), Main.getMouseY()));
		else if(buttons[vMouseEvent.MOUSE_BUTTON_RIGHT])
			handleMouseInput(new vMouseEvent(vMouseEvent.MOUSE_BUTTON_RIGHT, vMouseEvent.MOUSE_DOWN, Main.getMouseX(), Main.getMouseY()));

		content.update();
	}

	@Override
	public void pause() 
	{
		if(isActive)
		{
			isActive=false;
		}
		else 
		{
			isActive=true;
		}
	}

	@Override
	public void handleKeyBoardInput(vKeyEvent e) 
	{
		if(e.type == vKeyEvent.KEY_DOWN)
		{
			if(e.key == KeyEvent.VK_ESCAPE)
			{
				screenManager.add(new LevelEditorPauseScreen("Paused", this.dimension, 40, this));
				pause();
			}
			
			if(e.key == KeyEvent.VK_Q)
			{
				tile++;
				if(tile> numberOfTiles-1)
					tile=0;
				guide.toggleUp();
			}
			
		}
		content.handleKeyBoardInput(e);
	}

	@Override
	public void handleMouseInput(vMouseEvent e) 
	{
		int x;
		int y;
		
		if(lockToGrid)
		{
			x = e.x-(e.x%32);
			y = e.y-(e.y%32);
		}
		else {
			x = e.x;
			y = e.y;
		}
		
		if(e.type == vMouseEvent.MOUSE_MOTION)
		{
			guide.x = x;
			guide.y = y;
			if(drawGuide)
				this.endGuide = new Point(x+16,y+16);
		}
		
		if(e.type == vMouseEvent.MOUSE_DOWN)
		{
			switch (e.button) {
			case vMouseEvent.MOUSE_BUTTON_LEFT:
				if(drawGuide)
				{
					MovingTile tile = new MovingTile(this, selectedBlock.positionBox.x, selectedBlock.positionBox.y, startGuide.x-16, startGuide.y-16, endGuide.x-16, endGuide.y-16);
					if(blocksPaused)
						tile.isActive = false;
					tile.drawPath = true;
					content.add(tile);
					content.remove(this.selectedBlock);
					drawGuide = false;
				}
				
				boolean collisiton = false;
				for(int i=content.getBlocks().size()-1; i>=0; i--)
				{
					if(Collision.checkMouseCollisionWithCorner(x, y, content.getBlocks().elementAt(i).positionBox.x, content.getBlocks().elementAt(i).positionBox.y))
						collisiton = true;
				}
				if(!(collisiton) || tile==3)
				{
					switch (tile) 
					{
					case 0:
						content.add(new Player(this, this.content, x, y));
						break;

					case 1:
						content.add(new Tile(this.parentScreen, x, y));
						break;
						
					case 2:
						content.add(new ExitTile(this.parentScreen, x, y));
						break;
					case 3:
						Vector <Block> blocks = content.getImmobileBlocks();
						boolean blockSelected = false;
						
						for(int i=0; i<blocks.size(); i++)
						{
							if(Collision.checkMouseCollision(e.x, e.y, blocks.elementAt(i).positionBox))
							{
								this.selectedBlock = blocks.elementAt(i);
								blockSelected = true;
							}
						}
						
						if(blockSelected)
						{
							this.startGuide = new Point(x+16, y+16);
							this.drawGuide = true;
						}
						//content.add(new MovingTile(this, x, y, x-102, x+102, y-102, y+102));
						break;
					
					case 4:
						content.add(new Spike(this, x, y));
						break;
					}
						
				}
				break;

			case vMouseEvent.MOUSE_BUTTON_RIGHT:
				for(int i=content.getBlocks().size()-1; i>=0; i--)
				{
					if(Collision.checkMouseCollision(e.x, e.y, content.getBlocks().elementAt(i).positionBox))
					{
						content.remove(content.getBlocks().elementAt(i));
						break;
					}
				}
				for(int i=content.getActors().size()-1; i>=0; i--)
				{
					if(Collision.checkMouseCollision(e.x, e.y, content.getActors().elementAt(i).positionBox))
					{
						content.remove(content.getActors().elementAt(i));
						break;
					}
				}
				break;
			}
		}
		content.handleMouseInput(e);
	}

	@Override
	public void takeInput(String args) 
	{
		if(args == "quit")
		{
			screenManager.remove(this);
			parentScreen.pause();
		}
		else if(args == "save")
		{
			this.saveLevel();
			this.pause();
		}
		else if(args == "save and quit")
		{
			this.saveLevel();
			screenManager.remove(this);
			parentScreen.pause();
		}
		else if(args == "load")
		{
			this.buttons[vMouseEvent.MOUSE_BUTTON_LEFT] = false;
			level = JOptionPane.showInputDialog(pannel, "Load a level");
			loadLevel(level);
			this.pause();
		}
		else if(args == "new")
		{
			this.buttons[vMouseEvent.MOUSE_BUTTON_LEFT] = false;
			level = JOptionPane.showInputDialog(pannel, "Create a level");
			newLevel();
			this.pause();
		}
		else if(args == "clear")
		{
			this.clearLeve();
			this.pause();
		}
		else if(args == "pause blocks")
		{
			this.pauseBlocks();
			this.pause();
		}
		else if(args == "options")
		{
			screenManager.add(new LevelEditorOptionsScreen("Options", this.dimension, 40, this));
		}
		else if(args == "showGrid")
			toggleShowGrid();
		else if(args == "lockToGrid")
			toggleLockToGrid();
		else if(args == "tip")
		{
			this.buttons[vMouseEvent.MOUSE_BUTTON_LEFT] = false;
			String input = JOptionPane.showInputDialog(pannel, "Format: string, Yoffset\n Ex: Welcome, 100\nUse none or leave blank to remove tip	");
			if(!input.equals("none") && input.length() > 0)
			{
				int delim = input.indexOf(',');
				if(delim == -1)
				{
					this.tip = input;
					this.offset = 100;
				}
				else 
				{
					this.tip = input.substring(0, delim);
					this.offset = Integer.parseInt(input.substring(delim+2, input.length()));
				}
				this.init = true;
			}
			else {
				tip = "";
			}
			
			this.pause();
		}
	}
	
	private void clearLeve()
	{
		content.clear();
	}

	public void saveLevel()
	{
		if(level != null)
		{
			try {
				File file = new File("levels/"+level + ".txt");
				file.createNewFile();
				FileWriter writer = new FileWriter(file);
				
				Vector<Block> blocks = content.getBlocks();
				Vector<Actor> actors = content.getActors();
				
				if(!tip.equals(""))
				{
					writer.write(tip + "\r\n");
					writer.write(offset + "\r\n");
				}
				else {
					writer.write("none\r\n");
				}
				
				for(int i=0; i<actors.size(); i++)
				{
					writer.write(actors.elementAt(i).id + " " + actors.elementAt(i).positionBox.x + " " + actors.elementAt(i).positionBox.y + "\r\n");
				}
				
				for(int i=0; i<blocks.size(); i++)
				{
					switch (blocks.elementAt(i).id) 
					{
						case 1:
							writer.write(blocks.elementAt(i).id + " " + blocks.elementAt(i).positionBox.x + " " + blocks.elementAt(i).positionBox.y + "\r\n");
							break;
						case 2:
							writer.write(blocks.elementAt(i).id + " " + blocks.elementAt(i).positionBox.x + " " + blocks.elementAt(i).positionBox.y + "\r\n");
							break;
						case 3:
							MovingTile m = (MovingTile)blocks.elementAt(i);
							writer.write(m.id + " " + m.initialX + " " + m.initialY + " " + m.firstBoundX + " " + m.firstBoundY + " " + m.secondBoundX + " " + m.secondBoundY + "\r\n");
							break;
						case 4:
							writer.write(blocks.elementAt(i).id + " " + blocks.elementAt(i).positionBox.x + " " + blocks.elementAt(i).positionBox.y + "\r\n");
							break;
					}
				}
				writer.flush();
				writer.close();
			} catch (IOException e) {System.out.println("Could not save file");}
		}
		else {
			this.buttons[vMouseEvent.MOUSE_BUTTON_LEFT] = false;
			JOptionPane.showMessageDialog(pannel, "Could not save: no level loaded/created");
		}
	}
	
	public void newLevel()
	{
		if(level != null)
		{
				File file = new File("levels/"+level + ".txt");
				if(file.exists() && file.isDirectory())
				{
					this.buttons[vMouseEvent.MOUSE_BUTTON_LEFT] = false;
					JOptionPane.showMessageDialog(pannel, "File Already Exists");
				}
		}
		else 
		{
			this.buttons[vMouseEvent.MOUSE_BUTTON_LEFT] = false;
			JOptionPane.showMessageDialog(pannel, "error");
		}
	}
	
	public void loadLevel(String level)
	{
		try
		{
			this.init = true;
			read = new Scanner(new File("levels/" + level + ".txt"));
			content.clear();
			
			if(read.hasNext())
			{
			this.tip = read.nextLine();
			
			if(tip.equals("none"))
				tip ="";
			else
				this.offset = read.nextInt();
			}
			
			while(read.hasNext())
			{
				switch(read.nextInt())
				{
				case 0:
					content.add(new Player(this,this.content,read.nextInt(), read.nextInt()));
					break;
				case 1:
					content.add(new Tile(this, read.nextInt(),  read.nextInt()));
					break;
				case 2:
					content.add(new ExitTile(this, read.nextInt(),  read.nextInt()));
					break;
				case 3:
					MovingTile m = new MovingTile(this, read.nextInt(), read.nextInt(), read.nextInt(), read.nextInt(),read.nextInt(), read.nextInt());
					m.drawPath = true;
					m.isActive = false;
					content.add(m);
					break;
				case 4:
					content.add(new Spike(this, read.nextInt(),  read.nextInt()));
					break;
				}
			}
		}
		catch (FileNotFoundException e) 
		{
			System.out.println("Could not read file");
			this.buttons[vMouseEvent.MOUSE_BUTTON_LEFT] = false;
			JOptionPane.showMessageDialog(pannel, "Could not load: level does not Exist");
		}
	}
	
	private void drawGrid(Graphics2D gr) 
	{
		gr.setColor(new Color(0, 0, 0, 40));
		int hLines = this.appDimension.width / 32;
		int vLines = this.appDimension.height /32;
		
		int counter = 32;
		for(int i=0; i<hLines-1; i++)
		{
			gr.drawLine(counter,0,counter,appDimension.height);
			counter+=32;
		}
		
		counter = 32;
		for(int i=0; i<vLines-1; i++)
		{
			gr.drawLine(0,counter,appDimension.width,counter);
			counter+=32;
		}
	}
	
	public void toggleShowGrid()
	{
		if(showGrid)
			showGrid=false;
		else
			showGrid=true;
	}
	
	public void toggleLockToGrid()
	{
		if(lockToGrid)
			lockToGrid=false;
		else
			lockToGrid=true;
	}

	@Override
	public OptionsCarrier getOptions() 
	{
		return new OptionsCarrier(this.showGrid, this.lockToGrid, this.blocksPaused);
	}

	private void getTextMetrics(Graphics2D gr)
	{
		gr.setFont(font);
		FontMetrics fontMetrics = gr.getFontMetrics();
		int width = fontMetrics.stringWidth(tip);
		this.x = (dimension.width/2 - width /2);
	}
	
	private void pauseBlocks()
	{
		if(blocksPaused){
			for(int i=0; i<content.getMobileBlocks().size(); i++)
			{
				content.getMobileBlocks().elementAt(i).isActive = true;
			}
			blocksPaused = false;
		}
		else{
			for(int i=0; i<content.getMobileBlocks().size(); i++)
			{
				MovingTile b = (MovingTile)content.getMobileBlocks().elementAt(i);
				b.isActive = false;
				b.positionBox.x = b.initialX;
				b.positionBox.y = b.initialY;
			}
			blocksPaused = true;
		}
	}
	
	public ContentManager getContent()
	{
		return content;
	}
}
