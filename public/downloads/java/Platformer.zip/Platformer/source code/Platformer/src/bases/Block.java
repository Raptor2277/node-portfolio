package bases;
import java.awt.Graphics2D;
import java.awt.Rectangle;


public abstract class Block 
{
	public static int immobile = 0;
	public static int mobile = 1;
	
	protected Screen parentScreen;
	
	public Rectangle positionBox;
	public Rectangle collisionBox;
	
	public int id;
	public int type;
	
	public boolean isDrawn = false;
	public boolean isActive = false;
	
	public abstract void draw(Graphics2D gr);
	
	public abstract void update();
	
	public abstract void updateX();
	
	public abstract void updateY();
	
}
