package main;
import gameScreens.MainMenuScreen;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import managers.ScreenManager;
import misc.vKeyEvent;
import misc.vMouseEvent;

@SuppressWarnings({ "serial", "unused"})
public class Main extends JPanel implements Runnable, KeyListener, MouseListener , MouseMotionListener
{	
	private final int SCREEN_HEIGHT = 640;
	private final int SCREEN_WIDTH = SCREEN_HEIGHT * 3/2;
	
	Dimension appDimension;
	ScreenManager screenManager;
	Thread t;
	
	static boolean keys[] = new boolean[256];
	static boolean buttons[] = new boolean[5];
	static int x = 0;
	static int y = 0;
	
	public static void main(String [] args)
	{
		JFrame frame = new JFrame("Platformer");
		frame.add(new Main());
		//packs the frame around the JPannel with a 10 px margin on the left and bottom
		frame.pack();
		//removes the 10px margin
		frame.setSize(frame.getWidth()-10, frame.getHeight()-10);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setLocation(100, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public Main()
	{
		this.appDimension = new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT);
		this.setPreferredSize(appDimension);
		
		this.screenManager = new ScreenManager(this.appDimension,this);
		MainMenuScreen mainMenu = new MainMenuScreen("Main Menu", this.appDimension, 100, null);
		mainMenu.setBorder(false);
		screenManager.add(mainMenu);
		
		this.t = new Thread(this);
		t.start();
		
		this.setFocusable(true);
		this.addKeyListener(this);
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
	}
	
	public void paint(Graphics g)
	{
		Graphics2D gr = (Graphics2D) g;
		gr.setColor(Color.white);
		gr.fillRect(0, 0, appDimension.width, appDimension.height);
		
		screenManager.draw(gr);
	}
	
	public void run()
	{
		long collisionTimer = System.nanoTime();
		
		long lastTimeTicks = System.nanoTime();
		long lastTimeFrames = System.nanoTime();
		final double amountOfTicks = 60.0;
		final double amountOfFrames = 60.0;
		double nanoSecondsPerTick = 1000000000 / amountOfTicks;
		double nanoSecondsperFrame = 1000000000/ amountOfFrames;
		double deltaTicks = 0;
		double deltaFrames = 0;
		while(true)
		{
			long nowTicks = System.nanoTime();
			deltaTicks += (nowTicks - lastTimeTicks) / nanoSecondsPerTick;
			lastTimeTicks = nowTicks;
			if(deltaTicks >= 1)
			{
				screenManager.update();
				deltaTicks--;
			}
			
			long nowFrames = System.nanoTime();
			deltaFrames += (nowFrames - lastTimeFrames) / nanoSecondsperFrame;
			lastTimeFrames = nowFrames;
			if(deltaFrames >= 1)
			{
				repaint();
				deltaFrames--;
			}
			
			/*if(System.nanoTime() - collisionTimer > 1000000000)
			{
				collisionTimer = System.nanoTime();
				Collision.printCollisionStatistics();
				System.out.println("player updates:   " + Player.updates);
				System.out.println("");
			}*/
			
		}
	}

	public void keyPressed(KeyEvent e)
	{
		if(keys[e.getKeyCode()] == false)
		{
			keys[e.getKeyCode()] = true;
			screenManager.handleKeyBoardInput(new vKeyEvent(e.getKeyCode(), vKeyEvent.KEY_DOWN));
		}
	}

	public void keyReleased(KeyEvent e) 
	{
		if(keys[e.getKeyCode()] == true)
		{
			keys[e.getKeyCode()] = false;
			screenManager.handleKeyBoardInput(new vKeyEvent(e.getKeyCode(), vKeyEvent.KEY_UP));
		}
	}
	
	public void mouseMoved(MouseEvent e) 
	{
		Main.x = e.getX();
		Main.y = e.getY();
		screenManager.handleMouseInput(new vMouseEvent(vMouseEvent.MOUSE_MOTION, e.getX(), e.getY()));
	}
	
	@Override
	public void mouseDragged(MouseEvent e) {
		Main.x = e.getX();
		Main.y = e.getY();
	}
	
	public void mousePressed(MouseEvent e) 
	{
		buttons[e.getButton()] = true;
		screenManager.handleMouseInput(new vMouseEvent(e.getButton(), vMouseEvent.MOUSE_DOWN, e.getX(), e.getY()));
	}

	public void mouseReleased(MouseEvent e) 
	{
		buttons[e.getButton()] = false;
		screenManager.handleMouseInput(new vMouseEvent(e.getButton(), vMouseEvent.MOUSE_UP, e.getX(), e.getY()));
	}
	
	public static boolean[] getKeys() {
		return keys;
	}
	
	public static boolean[] getButtons() {
		return buttons;
	}
	
	public static int getMouseX()
	{
		return x;
	}
	
	public static int getMouseY()
	{
		return y;
	}
	
	//----------------------------------NOT USED------------------------------
	@Override
	public void keyTyped(KeyEvent e) {
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {

	}
	
	@Override
	public void mouseEntered(MouseEvent e) {
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		
	}
	
}
