package blocks;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import bases.Block;
import bases.Screen;

public class Tile extends Block 
{
	Color color = Color.RED;
	
	public Tile(Screen parentScreen, int x, int y)
	{
		this.parentScreen = parentScreen;
		this.positionBox = new Rectangle(x,y,32,32);
		this.collisionBox = new Rectangle(x,y,32,32);
		
		this.isActive = true;
		this.isDrawn = true;
		
		this.id = 1;
		this.type = immobile;
	}

	public void draw(Graphics2D gr) 
	{
		gr.setColor(color);
		gr.drawRect(positionBox.x, positionBox.y, positionBox.width,positionBox.height);
	}

	public void update() 
	{
		
	}

	@Override
	public void updateX() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateY() {
		// TODO Auto-generated method stub
		
	}

}
