package blocks;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import bases.Block;
import bases.Screen;

public class Spike extends Block
{
	public final static int up = 0;
	public final static int down = 1;
	public final static int left = 2;
	public final static int right = 3;
	
	Color color = Color.black;
	public int rotation = Spike.up;
	
	public Spike(Screen parentScreen, int x, int y)
	{
		this.parentScreen = parentScreen;
		this.positionBox = new Rectangle(x,y,32,32);
		this.collisionBox = new Rectangle(x+5,y+5,22,22);
		
		this.isActive = true;
		this.isDrawn = true;
		
		this.id = 4;
		this.type = immobile;
	}
	
	public void draw(Graphics2D gr)
	{
		gr.setColor(color);
		
		gr.drawLine(positionBox.x, positionBox.y+32, positionBox.x+10, positionBox.y);
		gr.drawLine(positionBox.x+22, positionBox.y,positionBox.x+32, positionBox.y+32);
		
		gr.drawLine(positionBox.x+10, positionBox.y, positionBox.x+16, positionBox.y+24);
		gr.drawLine(positionBox.x+22, positionBox.y, positionBox.x+16, positionBox.y+24);
		
		gr.drawLine(positionBox.x, positionBox.y+32, positionBox.x+32,positionBox.y+32);
		
	}
		
	
	public void update()
	{
		
	}

	public static void drawGuide(Graphics2D gr, int rotation, int x, int y)
	{
		switch (rotation) {
		case Spike.up:
			
			/*gr.drawLine(positionBox.x, positionBox.y+32, positionBox.x+10, positionBox.y);
			gr.drawLine(positionBox.x+22, positionBox.y,positionBox.x+32, positionBox.y+32);
			
			gr.drawLine(positionBox.x+10, positionBox.y, positionBox.x+16, positionBox.y+24);
			gr.drawLine(positionBox.x+22, positionBox.y, positionBox.x+16, positionBox.y+24);
			
			gr.drawLine(positionBox.x, positionBox.y+32, positionBox.x+32,positionBox.y+32);
			*/
			break;
		
		case Spike.down:
			
			break;
			
		case Spike.left:
	
			break;
			
		case Spike.right:
	
			break;
		}
	}

	@Override
	public void updateX() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateY() {
		// TODO Auto-generated method stub
		
	}
	
}