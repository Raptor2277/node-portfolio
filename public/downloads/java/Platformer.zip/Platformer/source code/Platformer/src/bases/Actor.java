package bases;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import managers.ContentManager;
import misc.vKeyEvent;
import misc.vMouseEvent;


public abstract class Actor 
{
	//cannot be used in the ctor must be used in the init
	protected Screen parentScreen;
	
	public Rectangle positionBox;
	public ContentManager content;
	
	public boolean isDrawn;
	public boolean isActive;
	public boolean isOnTop;
	public boolean hitItsHead;
	public boolean imovable;
	
	public double velocity;
	public double xVelocity;
	public double yVelocity;
	
	public int lastX;
	public int lastY;
	
	public int id;
	
	public abstract void draw(Graphics2D gr);
	
	public abstract void update();
	
	public abstract void handleKeyBoardInput(vKeyEvent e);
	
	public abstract void handleMouseInput(vMouseEvent e);

	public abstract void updateX();

	public abstract void updateY();
	
	public abstract void pushX(int x);
	
	public abstract void pushY(int y);
	
	public abstract void updateCollisionX();

	public abstract void updateCollisionY();
	
	public abstract void takeInput(String input, int value);

}
