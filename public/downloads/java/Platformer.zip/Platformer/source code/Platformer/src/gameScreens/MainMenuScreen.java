package gameScreens;

import java.awt.Dimension;
import java.awt.Graphics2D;

import managers.MenuScreen;
import bases.Screen;

public class MainMenuScreen extends MenuScreen
{

	public MainMenuScreen(String title, Dimension srcDimension, int size,Screen parentScreen) {
		super(title, srcDimension, size, parentScreen);
	}
	
	protected void init(Graphics2D gr)
	{
		addButton(new String [] {"Play"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"Custom Level"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"Level Editor"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"Help"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"Quit"}, this.buttonFont, this.buttonColor);
	}
	
	protected void buttonClick(int buttonIndex)
	{
		switch (buttonIndex) 
		{
		case 0:
			screenManager.add(new LevelPickScreen(this));
			this.pause();
			break;

		case 1:
			
			break;
			
		case 2:
			screenManager.add(new LevelEditorScreen(this));
			this.pause();
			break;
			
		case 3:
			screenManager.add(new HelpScreen(this));
			this.pause();
			break;
	
		case 4:
			screenManager.remove(this);
			System.exit(0);
			break;
		}
	}

}
