package managers;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.util.Vector;

import javax.swing.JPanel;

import misc.vKeyEvent;
import misc.vMouseEvent;
import bases.Screen;


public class ScreenManager
{

	private Vector <Screen> screens;
	public Dimension appDimension;
	public JPanel panel;
	
	public ScreenManager(Dimension appDimension, JPanel panel)
	{
		screens = new Vector <Screen>();
		this.appDimension = appDimension;
		this.panel = panel;
	}
	
	public void draw(Graphics2D gr)
	{
		for(int i=0; i<screens.size(); i++)
		{
			if(screens.elementAt(i).isDrawn)
				screens.elementAt(i).draw(gr);
		}
	}
	
	public void update()
	{
		for(int i=0; i<screens.size(); i++)
		{
			if(screens.elementAt(i).isActive)
				screens.elementAt(i).update();
		}
	}
	
	public void handleKeyBoardInput(vKeyEvent e)
	{
		int tempScreens = screens.size();
		
		for(int i=0; i<tempScreens; i++)
		{
			if(screens.elementAt(i).isActive)
				screens.elementAt(i).handleKeyBoardInput(e);
		}
	}
	
	public void handleMouseInput(vMouseEvent e)
	{
		int tempScreens = screens.size();
		
		for(int i=0; i<tempScreens; i++)
		{
			if(screens.elementAt(i).isActive)
				screens.elementAt(i).handleMouseInput(e);
		}
	}
	
	public void add(Screen screen)
	{
		screen.screenManager = this;
		screen.appDimension = this.appDimension;
		screen.pannel=this.panel;
		screen.init();
		screens.addElement(screen);
	}

	public void remove(Screen screen)
	{
		screens.removeElement(screen);
	}
}
