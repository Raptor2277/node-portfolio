package misc;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.util.Vector;

import sun.print.resources.serviceui;
import bases.Actor;

@SuppressWarnings("unused")
public class Collision
{
	public static int colsRect = 0;
	public static int colsScreen = 0;
	public static int colsMouse = 0;
	public static int colsIsTop = 0;
	
	public static boolean checkCollision(Rectangle rect1, Rectangle rect2)
	{
		colsRect++;
		if(rect1.x + rect1.width <= rect2.x)
			return false;
		if(rect1.x >= rect2.x + rect2.width)
			return false;
		if(rect1.y + rect1.height <= rect2.y)
			return false;
		if(rect1.y >= rect2.y + rect2.height)
			return false;
		return true;
	}		
	
	public static boolean checkCollisionScreen(Rectangle rect, Dimension screen)
	{
		colsScreen++;
		if(rect.x + rect.width > screen.width)
			return true;
		if(rect.x < 0)
			return true;
		if(rect.y + rect.height > screen.height)
			return true;
		if(rect.y < 0)
			return true;
		return false;
	}
	
	public static boolean checkMouseCollision(int x, int y, Rectangle rect)
	{
		colsMouse++;
		if(x>rect.x && x<rect.x + rect.width)
		{
			if(y>rect.y && y<rect.y + rect.height )
				return true;
		}
		return false;
	}
	
	public static boolean checkMouseCollisionWithCorner(int x, int y, int a, int b)
	{
		if(x == a && y == b)
		{
			return true;
		}
		return false;
	}
	
	public static boolean isOnTop(Actor a, Vector<Actor> actors)
	{
		for(int i=0; i<actors.size(); i++)
		{
			colsIsTop++;
			if(!actors.elementAt(i).equals(a))
			{
				if(a.positionBox.y + a.positionBox.height == actors.elementAt(i).positionBox.y && 
						(a.positionBox.x > actors.elementAt(i).positionBox.x - a.positionBox.width && a.positionBox.x < actors.elementAt(i).positionBox.x + a.positionBox.width))
				{
					return true;
					
				}
			}
		}
		return false;
	}
	
	public static boolean hasBlockOnTop(Rectangle actor, Rectangle block)
	{
		if((actor.x > block.x - actor.width && actor.x < block.x + block.width) && (actor.y + actor.width == block.y))
			return true;
		return false;
			
	}
	
	public static void printCollisionStatistics()
	{
		System.out.println("Rectangle Collisions:   " + colsRect);
		System.out.println("Screen Collisions:      " + colsScreen);
		System.out.println("Mouse Collisions:       " + colsMouse);
		System.out.println("IsOnTop Collisions:     " + colsIsTop);
	}

}
