package misc;

public class vKeyEvent 
{
	public final static int KEY_DOWN = 0;
	public final static int KEY_UP = 1;
	
	public int key;
	public int type;
	
	public vKeyEvent(int key, int type)
	{
		this.key = key;
		this.type = type;
	}

}
