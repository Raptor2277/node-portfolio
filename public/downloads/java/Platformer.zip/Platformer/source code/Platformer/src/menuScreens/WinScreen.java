package menuScreens;

import java.awt.Dimension;
import java.awt.Graphics2D;

import managers.MenuScreen;
import bases.Screen;

public class WinScreen extends MenuScreen
{

	public WinScreen(String title, Dimension srcDimension, int size,Screen parentScreen) {
		super(title, srcDimension, size, parentScreen);
	}
	
	protected void init(Graphics2D g)
	{
		addButton(new String [] {"Next Level"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"Restart"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"Quit"}, this.buttonFont, this.buttonColor);
	}
	
	protected void buttonClick(int buttonIndex)
	{
		switch (buttonIndex) 
		{
		case 0:
			screenManager.remove(this);
			parentScreen.takeInput("nextLevel");
			break;
			
		case 1:
			screenManager.remove(this);
			parentScreen.pause();
			parentScreen.takeInput("reload");
			break;

		case 2:
			screenManager.remove(this);
			parentScreen.takeInput("quit");
			break;
		}
	}

}
