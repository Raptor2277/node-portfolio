package misc;

public  class LevelHandler 
{
	public static String getNextLevel(String currentLevel)
	{
		int levelNumber = Integer.parseInt(currentLevel.replaceAll("[^0-9]", ""));
		return "level" + (levelNumber+1);
	}

}
