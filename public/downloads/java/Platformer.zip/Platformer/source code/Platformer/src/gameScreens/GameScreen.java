package gameScreens;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JOptionPane;

import sun.font.FontScaler;
import main.Player;
import managers.ContentManager;
import menuScreens.PauseScreen;
import menuScreens.WinScreen;
import misc.LevelHandler;
import misc.OptionsCarrier;
import misc.vKeyEvent;
import misc.vMouseEvent;
import bases.Block;
import bases.Screen;
import blocks.ExitTile;
import blocks.MovingTile;
import blocks.Spike;
import blocks.Tile;

@SuppressWarnings("unused")
public class GameScreen extends Screen
{
	String tip;
	Font font;
	int x;
	int offset;
	boolean init;
	
	Scanner read;
	String level;
	
	ContentManager content;
	
	public GameScreen(Screen parentScreen , String level) 
	{
		this.tip = "";
		this. x = 0;
		this.offset = 100;
		this.init = false;
		this.font = new Font("times new roman",Font.ITALIC, 40);
		this.parentScreen = parentScreen;
		this.position = new Point(0,0);
		
		this.content = new ContentManager();
		
		this.level = level;
		
		loadLevel();
		
		this.isActive = true;
		this.isDrawn = true;
		this.init = true;
		this.keys = new boolean[256];
	}
	
	@Override
	public void init() 
	{
		this.dimension = appDimension;
	}
	
	@Override
	public void draw(Graphics2D gr) 
	{
		if(init)
		{
			getTextMetrics(gr);
			init = false;
		}
		
		gr.setColor(Color.BLACK);
		gr.setFont(font);
		gr.drawString(this.tip,x,offset+ font.getSize());
		content.draw(gr);
	}

	@Override
	public void update() 
	{
		content.update();
	}
	
	@Override
	public void handleKeyBoardInput(vKeyEvent e) 
	{	
		if(e.type == vKeyEvent.KEY_DOWN)
		{
			if(e.key == KeyEvent.VK_ESCAPE)
			{
				screenManager.add(new PauseScreen("Paused", this.dimension, 40, this));
				pause();
			}
		}
		content.handleKeyBoardInput(e);
	}
	
	public void handleMouseInput(vMouseEvent e) 
	{
		
	}

	@Override
	public void takeInput(String args)
	{
		if(args == "quit")
		{
			screenManager.remove(this);
			parentScreen.pause();
		}
		else if(args == "reload")
		{
			this.loadLevel();
		}
		else if(args == "levelWon")
		{
			screenManager.add(new WinScreen("Level Complete!", this.dimension, 40, this));
			this.pause();
		}
		else if(args == "nextLevel")
		{
			this.level = LevelHandler.getNextLevel(this.level);
			this.loadLevel();
			this.pause();
		}
	}

	@Override
	public void pause()
	{
		if(isActive)
		{
			isActive=false;
		}
		else 
		{
			isActive=true;
		}
	}
	
	public void loadLevel()
	{
		try
		{
			read = new Scanner(new File("levels/" + level + ".txt"));
			content.clear();
			this.tip = read.nextLine();
			
			if(tip.equals("none"))
				tip ="";
			else
				this.offset = read.nextInt();
			
			while(read.hasNext())
			{
				switch(read.nextInt())
				{
				case 0:
					content.add(new Player(this,this.content,read.nextInt(), read.nextInt()));
					break;
				case 1:
					content.add(new Tile(this, read.nextInt(),  read.nextInt()));
					break;
				case 2:
					content.add(new ExitTile(this, read.nextInt(),  read.nextInt()));
					break;
				case 3:
					content.add(new MovingTile(this, read.nextInt(), read.nextInt(), read.nextInt(), read.nextInt(),read.nextInt(), read.nextInt()));
					break;
				case 4:
					content.add(new Spike(this, read.nextInt(),  read.nextInt()));
					break;
				}
			}
		}
		catch (FileNotFoundException e) 
		{
			System.out.println("Could not read file");
			JOptionPane.showMessageDialog(pannel, "Could not load: level does not Exist");
		}
	}

	@Override
	public OptionsCarrier getOptions()
	{
		return null;
		
	}
	
	private void getTextMetrics(Graphics2D gr)
	{
		gr.setFont(font);
		FontMetrics fontMetrics = gr.getFontMetrics();
		int width = fontMetrics.stringWidth(tip);
		this.x = (dimension.width/2 - width /2);
	}

	@Override
	public ContentManager getContent() {
		return content;
	}
	
}