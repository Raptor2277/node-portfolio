package gameScreens;

import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.Vector;

import javax.swing.JButton;

import com.sun.glass.events.KeyEvent;

import managers.ContentManager;
import misc.Collision;
import misc.LevelPickButton;
import misc.MenuButton;
import misc.OptionsCarrier;
import misc.vKeyEvent;
import misc.vMouseEvent;
import bases.Screen;

@SuppressWarnings("unused")
public class LevelPickScreen extends Screen
{
	Color color = Color.BLUE;
	Font font = new Font("Times New Roman", Font.BOLD, 20);
	
	Color headColor = Color.RED;
	Font headFont = new Font("Times New Roman", Font.BOLD, 40);
	
	Vector<LevelPickButton> buttons;
	int currentMenu = -1;
	
	public LevelPickScreen(Screen parentScreen)
	{
		this.position = new Point(0,0);
		this.parentScreen = parentScreen;
		this.buttons = new Vector<LevelPickButton>();
		
		this.isActive = true;
		this.isDrawn = true;
		
		int x = 250;
		int y = 130;
		for(int i=0; i<50; i++)
		{
			buttons.addElement(new LevelPickButton("Level- " + (i+1), "level"+(i+1),this.font, this.color));
			buttons.elementAt(i).setPosition(x,y);
			x+=100;
			if(x>650)
			{
				x=250;
				y+=50;
			}
		}
		
	}

	@Override
	public void init() 
	{
		this.dimension = appDimension;
	}

	@Override
	public void draw(Graphics2D gr) 
	{
		gr.setColor(headColor);
		gr.setFont(headFont);
		gr.drawString("CHAPTER ONE: COLLISION", appDimension.width/2-270, 100);
		
		for(int i=0; i<buttons.size(); i++)
		{
			buttons.elementAt(i).draw(gr);
		}
	}

	@Override
	public void update()
	{
		
	}

	@Override
	public void pause() 
	{
		
	}

	@Override
	public void handleKeyBoardInput(vKeyEvent e) 
	{
		if(e.type == vKeyEvent.KEY_DOWN && e.key == KeyEvent.VK_ESCAPE)
		{
			screenManager.remove(this);
			parentScreen.pause();
		}
	}

	@Override
	public void handleMouseInput(vMouseEvent e) 
	{
		if(e.type == vMouseEvent.MOUSE_MOTION)
		{
			boolean collision = false;
			for(int i=0; i<buttons.size(); i++)
			{
				if(Collision.checkMouseCollision(e.x, e.y, buttons.elementAt(i).textBox))
				{
					buttons.elementAt(i).isHighlighted = true;
					currentMenu = i;
					collision = true;
				}
				else 
				{
					buttons.elementAt(i).isHighlighted = false;
				}
				if(!collision)
					currentMenu=-1;
			}
		}
		else if(e.type == vMouseEvent.MOUSE_DOWN && e.button == vMouseEvent.MOUSE_BUTTON_LEFT)
		{
			if(currentMenu != -1)
			{
				screenManager.add(new GameScreen(this.parentScreen, buttons.elementAt(currentMenu).getLevel()));
				screenManager.remove(this);
			}
		}
	}

	@Override
	public void takeInput(String args)
	{
		
	}

	@Override
	public OptionsCarrier getOptions() 
	{
		return null;
	}

	@Override
	public ContentManager getContent() {
		// TODO Auto-generated method stub
		return null;
	}

}
