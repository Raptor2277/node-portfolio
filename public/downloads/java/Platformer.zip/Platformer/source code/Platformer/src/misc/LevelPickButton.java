package misc;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;

public class LevelPickButton
{
	//text variables
	public FontMetrics fontMetrics;
	public String text;
	public String levelString;
	public int currentText;
	public Rectangle textBox;
	
	//position and size
	public Point position;
	public int height;
	public int width;
	public int offset;
	
	//drawing methods
	public boolean isHighlighted;
	public boolean isActive;
	public boolean init;
	
	//graphics
	public Font font;
	public Color color;
	
	public LevelPickButton(String text,String levelString, Font font,Color color)
	{
		this.text =text;
		this.levelString = levelString;
		
		this.currentText = 0;
		this.font = font;
		this.color = color;
		
		this.height = font.getSize();
		
		this.isHighlighted = false;
		this.isActive = true;
		this.init = true;
		
	}
	
	public void draw(Graphics2D gr)
	{
		if(init)
		{
			getTextMetrics(gr);
			init = false;
		}
		
		drawStringCentered(gr);
	}
	
	private void drawStringCentered(Graphics gr)
	{
		gr.setColor(color);
		gr.setFont(font);
		gr.drawString(text, position.x, position.y - (height/5));
		
		if(isHighlighted)
			gr.drawRect(textBox.x, textBox.y, textBox.width, textBox.height);
	}
	
	public void setPosition(int x, int y)
	{
		this.textBox = new Rectangle(x, y, width, height+30); //+30 offset of box
		this.position = new Point(x, y+height+15);  //adjusting text to be in the middle
	}
	
	private void getTextMetrics(Graphics2D gr)
	{
		gr.setFont(font);
		this.fontMetrics = gr.getFontMetrics();
		this.width = fontMetrics.stringWidth(text);
		this.textBox.width = this.width;
	}
	
	public String getLevel()
	{
		return levelString;
	}
}
