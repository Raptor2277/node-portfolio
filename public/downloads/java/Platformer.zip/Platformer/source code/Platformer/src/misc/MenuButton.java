package misc;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.Vector;

public class MenuButton
{
	//text variables
	public FontMetrics fontMetrics;
	public Vector<String>text;
	public int currentText;
	public Rectangle textBox;
	
	//position and size
	public Point position;
	public int height;
	public int width;
	public int offset;
	
	//drawing methods
	public boolean isHighlighted;
	public boolean isActive;
	public boolean init;
	
	//graphics
	public Font font;
	public Color color;
	
	//parent
	private Point parentMiddle;
	
	public MenuButton(String text[], Font font,Color color)
	{
		this.text = new Vector<String>();
		for(int i=0; i<text.length; i++)
		{
			this.text.addElement(" " + text[i] + " ");
		}
		
		this.currentText = 0;
		this.font = font;
		this.color = color;
		
		this.height = font.getSize();
		
		this.isHighlighted = false;
		this.init = true;
		
	}
	
	public void draw(Graphics2D gr)
	{
		if(init)
		{
			getTextMetrics(gr);
			init = false;
		}
		
		drawStringCentered(gr);
	}
	
	private void drawStringCentered(Graphics gr)
	{
		gr.setColor(color);
		gr.setFont(font);
		gr.drawString(text.elementAt(currentText), position.x, position.y - (height/5));
		
		if(isHighlighted)
			gr.drawRect(textBox.x, textBox.y, textBox.width, textBox.height);
	}
	
	public void addText(String str)
	{
		text.addElement(str);
	}
	
	public void nextText()
	{
		currentText++;
		if(currentText>text.size()-1)
			currentText=0;
		init = true;
	}
	
	public void previousText()
	{
		currentText--;
		if(currentText<0)
			currentText=text.size()-1;
		init = true;
	}
	
	public void changeTextIndex(int index)
	{
		currentText=index;
		init = true;
	}
	
	public void setPosition(Point parentPosition, Dimension parentDimension, int offset)
	{
		this.parentMiddle = new Point(parentPosition.x + parentDimension.width/2, parentPosition.y + parentDimension.height/2);
		this.offset = offset;
		this.textBox = new Rectangle(parentMiddle.x-(width/2), offset, width, height);
		this.position = new Point(parentMiddle.x-(width/2), offset+height);
	}
	
	private void getTextMetrics(Graphics2D gr)
	{
		gr.setFont(font);
		this.fontMetrics = gr.getFontMetrics();
		this.width = fontMetrics.stringWidth(text.elementAt(currentText));
		this.textBox = new Rectangle(parentMiddle.x-(width/2), offset, width, height);
		this.position = new Point(parentMiddle.x-(width/2), offset+height);
	}
}
