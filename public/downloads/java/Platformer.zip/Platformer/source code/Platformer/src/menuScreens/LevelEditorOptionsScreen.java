package menuScreens;

import java.awt.Dimension;
import java.awt.Graphics2D;

import managers.MenuScreen;
import misc.OptionsCarrier;
import bases.Screen;

public class LevelEditorOptionsScreen extends MenuScreen
{
	OptionsCarrier options;
	
	public LevelEditorOptionsScreen(String title, Dimension srcDimension,int size, Screen parentScreen) {
		super(title, srcDimension, size, parentScreen);
	}
	
	protected void init(Graphics2D gr)
	{
		this.options = parentScreen.getOptions();
		addButton(new String [] {"Show Grid: ON", "Show Grid: OFF"},this.buttonFont, this.buttonColor);
		if(!options.showGrid)
			buttons.elementAt(0).changeTextIndex(1);
		addButton(new String [] {"Lock to Grid: ON", "Lock to Grid: OFF"},this.buttonFont, this.buttonColor);
		if(!options.lockToGrid)
			buttons.elementAt(1).changeTextIndex(1);
		addButton(new String [] {"Add/Change Tip"},this.buttonFont, this.buttonColor);
		addButton(new String [] {"Continue"},this.buttonFont, this.buttonColor);
	}
	
	protected  void buttonClick(int buttonIndex) 
	{
		switch (buttonIndex) 
		{
		case 0:
			buttons.elementAt(buttonIndex).nextText();
			parentScreen.takeInput("showGrid");
			break;
			
		case 1:
			buttons.elementAt(buttonIndex).nextText();
			parentScreen.takeInput("lockToGrid");
			break;
			
		case 2:
			screenManager.remove(this);
			parentScreen.takeInput("tip");
			break;
			
		case 3:
			screenManager.remove(this);
			parentScreen.pause();
			break;
		}
	}
}
