package managers;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.util.Vector;

import bases.Screen;
import misc.Collision;
import misc.MenuButton;
import misc.OptionsCarrier;
import misc.vKeyEvent;
import misc.vMouseEvent;

public class MenuScreen extends Screen
{
	protected Vector<MenuButton> buttons;
	protected Vector<String> infos;
	
	private Dimension srcDimension;
	
	public Point position;
	public Dimension dimension;
	public String title;
	public Rectangle titleBox;
	public int titleSize;
	public int buttonSize;
	public int infoSize;
	public int borderOffset;
	public int buttonOffset;
	public FontMetrics fontMetrics;
	
	public Color titleColor;
	public Color buttonColor;
	public Color intoColor;
	public Font titleFont;
	public Font buttonFont;
	public Font infoFont;
	
	//public boolean isDrawn;
	//public boolean isActive;
	public boolean init;
	protected boolean border;
	protected boolean centered;
	protected int x;
	protected int y;
	public int currentMenu;
	
	public MenuScreen(String title, Dimension srcDimension, int size, Screen parentScreen)
	{
		this.buttonColor = Color.black;
		this.titleColor = Color.red;
		this.intoColor = Color.black;
		
		this.titleSize = size;
		this.buttonSize = size/3*2;
		this.infoSize = buttonSize;
		this.borderOffset = 10;
		this.buttonOffset = 10;
				
		this.titleFont = new Font("Times new Roman", Font.BOLD, titleSize);
		this.buttonFont = new Font("Times New Roman", Font.PLAIN, buttonSize);
		this.title = title;
		this.srcDimension = srcDimension;
		this.parentScreen = parentScreen;
		this.position = new Point(0,0);
		this.dimension = new Dimension(0,0);
		this.titleBox = new Rectangle(0,0,0,0);
		
		
		this.buttons = new Vector<MenuButton>();
		
		this.isDrawn = true;
		this.isActive = true;
		this.init = true;
		this.border = true;
		this.centered = true;
		this.currentMenu = 0;
	}

	public void draw(Graphics2D gr) 
	{
		if(init)
		{
			init(gr);
			getTextMetrics(gr);
			if(centered)
				setCenter(gr);
			else
				setPosition(gr, x, y);
			init = false;
		}
		
		gr.setColor(Color.white);
		gr.fillRect(position.x, position.y, dimension.width, dimension.height);
		
		gr.setColor(titleColor);
		gr.setFont(titleFont);
		gr.drawString(title, titleBox.x, titleBox.y + titleSize-(titleSize/5));
		for(int i = 0; i<buttons.size(); i++)
			buttons.elementAt(i).draw(gr);
		if(border)
			gr.drawRect(position.x, position.y, dimension.width, dimension.height);
	}

	public void update() 
	{
		for(int i=0; i<buttons.size(); i++)
		{
			if(i == currentMenu)
				buttons.elementAt(i).isHighlighted = true;
			else
				buttons.elementAt(i).isHighlighted = false;
		}
	}

	public void handleKeyBoardInput(vKeyEvent e) 
	{
		if(buttons.size() > 0)
		{
			if(e.type == vKeyEvent.KEY_DOWN)
			{
				if(e.key == KeyEvent.VK_DOWN)
					currentMenu++;
				else if(e.key == KeyEvent.VK_UP)
					currentMenu--;
				else if(e.key == KeyEvent.VK_ENTER)
					buttonClick(currentMenu);
				else if(e.key == KeyEvent.VK_ESCAPE)
				{
					if(parentScreen != null)
					{
						screenManager.remove(this);
						parentScreen.pause();
					}
				}
					
			}
			
			if(currentMenu > buttons.size() -1)
				currentMenu = 0;
			else if(currentMenu < 0)
				currentMenu =buttons.size() - 1;
		}
	}

	public void handleMouseInput(vMouseEvent e) 
	{
		for(int i=0; i<buttons.size(); i++)
		if(Collision.checkMouseCollision(e.x, e.y, buttons.elementAt(i).textBox))
			currentMenu=i;
		if(e.type == vMouseEvent.MOUSE_DOWN && e.button == vMouseEvent.MOUSE_BUTTON_LEFT)
			buttonClick(currentMenu);
	}
	
	private void getTextMetrics(Graphics2D gr) 
	{
		gr.setFont(titleFont);
		fontMetrics = gr.getFontMetrics();
		titleBox.width = fontMetrics.stringWidth(title);
		titleBox.height = titleSize;	
	}
	
	protected void setCenter(Graphics2D gr)
	{
		//set the width according to the biggest string
		dimension.width = titleBox.width+(borderOffset*2);
		
		gr.setFont(buttonFont);
		fontMetrics = gr.getFontMetrics();
		for(int i=0; i<buttons.size();i++)
		{
			for(int n=0; n<buttons.elementAt(i).text.size(); n++)
			{
				if(fontMetrics.stringWidth(buttons.elementAt(i).text.elementAt(n)) > dimension.width)
					dimension.width = fontMetrics.stringWidth(buttons.elementAt(i).text.elementAt(n)) + (borderOffset*2);	
			}
		}
		dimension.height = titleBox.height + (buttons.size() * (buttonSize + buttonOffset)) + borderOffset*2;
		
		position.x = srcDimension.width/2-(this.dimension.width/2);
		position.y = srcDimension.height/2-(this.dimension.height/2);
		
		titleBox.x = (position.x + dimension.width/2 - titleBox.width/2 );
		titleBox.y = position.y + borderOffset;
		
		for(int i=0; i<buttons.size(); i++)
			buttons.elementAt(i).setPosition(this.position, this.dimension, getButtonOffSet(i));
	}
	
	protected void setPosition(Graphics2D gr, int x, int y)
	{
		this.x=x;
		this.y=y;
		this.centered= false;
		//set the width according to the biggest string
		dimension.width = titleBox.width+(borderOffset*2);
		
		gr.setFont(buttonFont);
		fontMetrics = gr.getFontMetrics();
		for(int i=0; i<buttons.size();i++)
		{
			for(int n=0; n<buttons.elementAt(i).text.size(); n++)
			{
				if(fontMetrics.stringWidth(buttons.elementAt(i).text.elementAt(n)) > dimension.width)
					dimension.width = fontMetrics.stringWidth(buttons.elementAt(i).text.elementAt(n)) + (borderOffset*2);	
			}
		}
		dimension.height = titleBox.height + (buttons.size() * (buttonSize + buttonOffset)) + borderOffset*2;
		
		position.x = x;
		position.y = y;
		
		titleBox.x = (position.x + dimension.width/2 - titleBox.width/2 );
		titleBox.y = position.y + borderOffset;
		
		for(int i=0; i<buttons.size(); i++)
			buttons.elementAt(i).setPosition(this.position, this.dimension, getButtonOffSet(i));
	}
	
	//override this when extending this class
	//this should be the only function in the extended class
	protected void init(Graphics2D gr)
	{
		buttons.addElement(new MenuButton(new String [] {" Button 0 - 0 ", " Button 0 - 1 ", " Button 0 - 2 "}, this.buttonFont, this.buttonColor));
		buttons.addElement(new MenuButton(new String [] {" Quit "}, this.buttonFont, this.buttonColor));
	}
	
	//override this when  extending this class
	protected void buttonClick(int buttonIndex)
	{
		System.out.println("button " + buttonIndex);
		buttons.elementAt(buttonIndex).nextText();
		if(currentMenu == 1)
		{	
			screenManager.remove(this);
			parentScreen.pause();
		}
	}
	
	protected int getButtonOffSet(int buttonIndex)
	{
		if(buttonIndex == 0)
			return titleBox.y + titleSize + buttonOffset;
		else
			return buttons.elementAt(buttonIndex-1).position.y + buttonOffset;
	}
	
	protected void addButtonInfo(String info, int buttonIndex)
	{
		infos.add(buttonIndex, info);
	}
	
	protected void addButton(String[] text, Font buttonFont, Color buttonColor) 
	{
		buttons.addElement(new MenuButton(text, buttonFont, buttonColor));
	}
	
	public void setBorder(boolean bool)
	{
		border = bool;
	}

	@Override
	public void init() 
	{
		
	}

	@Override
	public void takeInput(String args) 
	{
		
	}

	@Override
	public void pause() 
	{
		if(isActive)
		{
			isActive= false;
			isDrawn = false;
		}
		else 
		{
			isActive = true;
			isDrawn = true;
		}
	}

	@Override
	public OptionsCarrier getOptions() 
	{
		return null;
		
	}

	@Override
	public ContentManager getContent() {
		// TODO Auto-generated method stub
		return null;
	}
}


