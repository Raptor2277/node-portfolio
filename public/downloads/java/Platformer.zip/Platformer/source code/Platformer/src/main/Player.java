package main;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.util.Vector;
import managers.ContentManager;
import misc.Collision;
import misc.vKeyEvent;
import misc.vMouseEvent;
import bases.Actor;
import bases.Block;
import bases.Screen;


public class Player extends Actor
{
	private final int STANDING = 0;
	private final int FALLING = 1;

	private int spawnX;
	private int spawnY;

	boolean jumpedOnce = false;


	private Color color = Color.red;
	private int state = STANDING;

	boolean keys [];

	public static int updates = 0;

	public Player(Screen parentScreen, ContentManager content, int x, int y)
	{
		this.parentScreen = parentScreen;
		this.content = content;
		this.positionBox = new Rectangle(x,y,32,32);

		this.spawnX = x;
		this.spawnY = y;

		this.velocity = 4;
		this.id = 0;

		this.isDrawn = true;
		this.isActive = true;
		this.isOnTop = false;
		this.hitItsHead = false;
		this.imovable = false;
		this.keys = new boolean [256];
		keys = Main.getKeys().clone();

	}

	public void draw(Graphics2D gr)
	{
		gr.setColor(color);
		gr.fillRect(positionBox.x, positionBox.y, positionBox.width, positionBox.height);
	}

	public void update()
	{
		updates++;
		this.imovable = false;
		this.hitItsHead = false;

		//if is on top of another block
		this.isOnTop = false;
		if(Collision.isOnTop(this, content.getActors()))
		{
			this.isOnTop = true;
			jumpedOnce = false;
		}
	}

	public void updateX()
	{
		Vector <Block> blocks = content.getBlocks();

		//store position
		lastX = positionBox.x;

		//x update
		if(keys[KeyEvent.VK_A])
			positionBox.x -= velocity;
		if(keys[KeyEvent.VK_D])
			positionBox.x += velocity;

		//update by xVelocity which may be affected by outside sources
		positionBox.x+=xVelocity;

		//collision update with screen
		if(Collision.checkCollisionScreen(this.positionBox, this.parentScreen.dimension))
		{
			if(positionBox.x - lastX > 0)
				positionBox.x = parentScreen.dimension.width - positionBox.width;
			else
				positionBox.x = 0;
			this.imovable = true;
		}

		//with other blocks
		for(int i=0; i<blocks.size(); i++)
		{
			//System.out.println("this");
			if(Collision.checkCollision(this.positionBox, blocks.elementAt(i).collisionBox))
			{
				if(positionBox.x <= blocks.elementAt(i).collisionBox.x) //used to be positionBox.x - lastX > 0
					positionBox.x = blocks.elementAt(i).positionBox.x - this.positionBox.width;
				else
					positionBox.x = blocks.elementAt(i).positionBox.x + blocks.elementAt(i).positionBox.width;
				this.imovable = true;

				blockAction(blocks.elementAt(i).id);
			}
		}
	}

	public void updateCollisionX()
	{
		Vector <Actor> actors = content.getActors();

		for(int i=0; i<actors.size(); i++)
		{
			if(!actors.elementAt(i).equals(this) && Collision.checkCollision(this.positionBox, actors.elementAt(i).positionBox))
			{

				if(this.imovable)
				{
					if(this.positionBox.x > actors.elementAt(i).positionBox.x)
						actors.elementAt(i).pushX(this.positionBox.x - this.positionBox.width);
					else
						actors.elementAt(i).pushX(this.positionBox.x + this.positionBox.width);
				}
				else
				{
					this.imovable = true;
					if(this.positionBox.x > actors.elementAt(i).positionBox.x)
						this.positionBox.x = actors.elementAt(i).positionBox.x + actors.elementAt(i).positionBox.width;
					else
					{
						this.positionBox.x = actors.elementAt(i).positionBox.x - actors.elementAt(i).positionBox.width;
						this.hitItsHead = true;
					}
					this.updateCollisionX();
				}
			}
		}
	}



	public void updateY()
	{
		Vector <Block> blocks = content.getBlocks();

		//update last position
		lastY = positionBox.y;

		//gravity update
		yVelocity += 1;
		if(yVelocity > 15)
			yVelocity = 15;

		//update by yVelocity
		positionBox.y+=yVelocity;

		boolean collision = false;
		if(Collision.checkCollisionScreen(this.positionBox, this.parentScreen.dimension))
		{
			if(positionBox.y - lastY > 0)
				positionBox.y = parentScreen.dimension.height - positionBox.height;
			else
			{
				positionBox.y = 0;
				this.hitItsHead = true;
			}
			collision = true;
		}

		for(int i=0; i<blocks.size(); i++)
		{
			if(Collision.checkCollision(this.positionBox, blocks.elementAt(i).collisionBox))
			{
				if(positionBox.y <= blocks.elementAt(i).collisionBox.y) //used to be positionBox.y - lastY > 0
				{
					positionBox.y = blocks.elementAt(i).positionBox.y - this.positionBox.height;
					jumpedOnce = false;
				}
				else
				{
					this.hitItsHead = true;
					positionBox.y = blocks.elementAt(i).positionBox.y + blocks.elementAt(i).positionBox.height;
				}
				collision = true;
				blockAction(blocks.elementAt(i).id);
			}
		}

		if(collision){
			state=STANDING;
			yVelocity = 0;
		}else {
			state=FALLING;
		}
	}

	public void updateCollisionY()
	{
		Vector <Actor> actors = content.getActors();
		Vector <Block> blocks = content.getBlocks();

		if(Collision.checkCollisionScreen(this.positionBox, this.parentScreen.dimension))
		{
			if(positionBox.y - lastY > 0)
				positionBox.y = parentScreen.dimension.height - positionBox.height;
			else
			{
				positionBox.y = 0;
				this.hitItsHead = true;
			}
		}

		for(int i=0; i<blocks.size(); i++)
		{
			if(Collision.checkCollision(this.positionBox, blocks.elementAt(i).collisionBox))
			{
				if(positionBox.y - lastY > 0)
				{
					positionBox.y = blocks.elementAt(i).positionBox.y - this.positionBox.height;
					jumpedOnce = false;
				}
				else
				{
					this.hitItsHead = true;
					positionBox.y = blocks.elementAt(i).positionBox.y + blocks.elementAt(i).positionBox.height;
				}
			}
		}

		for(int i=0; i<actors.size(); i++)
		{
			if(!actors.elementAt(i).equals(this) && Collision.checkCollision(this.positionBox, actors.elementAt(i).positionBox))
			{

				if(positionBox.y > actors.elementAt(i).positionBox.y)
				{
					if(!actors.elementAt(i).hitItsHead)
						actors.elementAt(i).pushY(this.positionBox.y - this.positionBox.height);
					else
					{
						this.hitItsHead = true;
						this.yVelocity = 0;
						this.positionBox.y = actors.elementAt(i).positionBox.y + actors.elementAt(i).positionBox.width;
						this.updateCollisionY();
					}
				}
				else
				{
					if(this.hitItsHead)
					{
						actors.elementAt(i).pushY(this.positionBox.y + this.positionBox.height);
						actors.elementAt(i).hitItsHead = true;
						actors.elementAt(i).yVelocity = 0;
					}
					else
					{
						this.positionBox.y = actors.elementAt(i).positionBox.y - actors.elementAt(i).positionBox.height;
						this.updateCollisionY();
					}
				}
			}
		}
	}

	public void handleKeyBoardInput(vKeyEvent e)
	{
		if(e.type == vKeyEvent.KEY_DOWN)
		{
			switch(e.key)
			{
				case KeyEvent.VK_W:
				if(state == STANDING || !jumpedOnce)
					{
						yVelocity =- 15;
						jumpedOnce = true;
					}
				break;

				case KeyEvent.VK_SPACE:
					if(state == STANDING || !jumpedOnce)
						{
							yVelocity =- 15;
							jumpedOnce = true;
						}
				break;
			}
		}

		this.keys = Main.getKeys().clone();
	}

	public void handleMouseInput(vMouseEvent e)
	{

	}

	@Override
	public void pushX(int x)
	{
		this.positionBox.x = x;
		this.imovable = true;
		this.updateCollisionX();
	}

	@Override
	public void pushY(int y)
	{
		this.positionBox.y = y;
		this.imovable = true;
		this.updateCollisionY();
	}

	private void blockAction(int id)
	{
		switch (id) {
		case 2:
			parentScreen.takeInput("levelWon");
			break;

		case 4:
			this.respawn();
			break;
		}
	}

	private void respawn()
	{
		this.positionBox.x = spawnX;
		this.positionBox.y = spawnY;
	}

	public void takeInput(String input, int value) {

		if(input.equals("checkOnTop"))
			checkOnTop(value);


	}

	public void checkOnTop(int value)
	{
		Vector <Actor> actors = this.parentScreen.getContent().getActors();

		for(int i=0; i<actors.size(); i++)
		{
			if(Collision.hasBlockOnTop(actors.elementAt(i).positionBox, this.positionBox))
			{
				actors.elementAt(i).pushX(actors.elementAt(i).positionBox.x + value);
				actors.elementAt(i).takeInput("checkOnTop", value);
			}
		}
	}
}
