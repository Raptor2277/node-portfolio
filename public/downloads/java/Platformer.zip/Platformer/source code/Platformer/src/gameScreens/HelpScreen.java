package gameScreens;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

import managers.ContentManager;
import misc.OptionsCarrier;
import misc.vKeyEvent;
import misc.vMouseEvent;
import bases.Screen;

public class HelpScreen extends Screen{

	Font font;
	Color color;
	
	public HelpScreen(Screen parent) {
		this.parentScreen = parent;
		this.font = new Font("times new roman",Font.ITALIC, 40);
		this.color = Color.black;
		this.isActive = true;
		this.isDrawn = true;
	}
	
	@Override
	public void init() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void draw(Graphics2D gr) {
		gr.setColor(this.color);
		gr.setFont(this.font);
		gr.drawString("Controls", 400, 100);
		gr.drawString("Please read the readMe.txt for Instructions", 150, 200);
		gr.drawString("Press Escape to exit", 320, 500);
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handleKeyBoardInput(vKeyEvent e) {
		if(e.type == vKeyEvent.KEY_DOWN && e.key == KeyEvent.VK_ESCAPE){
			screenManager.remove(this);
			parentScreen.pause();
		}
		
	}

	@Override
	public void handleMouseInput(vMouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void takeInput(String args) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public OptionsCarrier getOptions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ContentManager getContent() {
		// TODO Auto-generated method stub
		return null;
	}

}
