package managers;
import java.awt.Graphics2D;
import java.util.Vector;
import misc.vKeyEvent;
import misc.vMouseEvent;
import bases.Actor;
import bases.Block;


public class ContentManager 
{
	private Vector<Actor> actors;
	private Vector<Block> blocks;
	
	public ContentManager()
	{
		blocks = new Vector<Block>();
		actors = new Vector<Actor>();
		//menus = new Vector<Menu>();
	}
	
	public void draw(Graphics2D gr)
	{
		for(int i=0; i<blocks.size(); i++)
		{
			if(blocks.elementAt(i).isDrawn)
				blocks.elementAt(i).draw(gr);
		}
		
		for(int i=0; i<actors.size(); i++)
		{
			if(actors.elementAt(i).isDrawn)
				actors.elementAt(i).draw(gr);
		}
		
	}
	
	public void update()
	{
		int numOfActors = actors.size();
		
		//block update X
		for(int i=0; i<blocks.size(); i++)
		{
			if(blocks.elementAt(i).type == Block.mobile && blocks.elementAt(i).isActive)
				blocks.elementAt(i).updateX();
		}
		
		//actor update in this order x, collisionx, y, collisiony, upate
		for(int i=0; i<numOfActors; i++)
		{
			if(actors.elementAt(i).isActive)
				actors.elementAt(i).updateX();
		}
		
		for(int i=0; i<numOfActors; i++)
		{
			if(actors.elementAt(i).isActive)
				actors.elementAt(i).updateCollisionX();
		}
		//--------------------------------------------Y updates--------------------
		//block update Y
		for(int i=0; i<blocks.size(); i++)
		{
			if(blocks.elementAt(i).type == Block.mobile && blocks.elementAt(i).isActive)
				blocks.elementAt(i).updateY();
		}
		
		
		for(int i=0; i<numOfActors; i++)
		{
			if(actors.elementAt(i).isActive)
				actors.elementAt(i).updateY();
		}
		
		
		for(int i=0; i<numOfActors; i++)
		{
			if(actors.elementAt(i).isActive)
				actors.elementAt(i).updateCollisionY();
		}
		
		//---------------------------------static updates----------------------------
		for(int i=0; i<numOfActors; i++)
		{
			if(actors.elementAt(i).isActive)
				actors.elementAt(i).update();
		}
		
	}

	public void handleKeyBoardInput(vKeyEvent e)
	{
		int tempactors = actors.size();

		for(int i=0; i<tempactors; i++)
		{
			if(actors.elementAt(i).isActive)
				actors.elementAt(i).handleKeyBoardInput(e);
		}
		
	}
	
	public void handleMouseInput(vMouseEvent e)
	{
		int tempactors = actors.size();
		
		for(int i=0; i<tempactors; i++)
		{
			if(actors.elementAt(i).isActive)
				actors.elementAt(i).handleMouseInput(e);
		}
		
	}
	
	public void add(Actor obj)
	{
		actors.add(obj);
	}
	
	public void add(Block obj)
	{
		blocks.add(obj);
	}
	
	public void remove(Actor obj)
	{
		actors.remove(obj);
	}
	
	public void remove(Block obj)
	{
		blocks.remove(obj);
	}
	
	public Vector<Block> getBlocks()
	{
		return blocks;
	}
	
	public Vector<Block> getImmobileBlocks()
	{
		Vector <Block> iblocks = new Vector<Block>();
		for(int i=0; i<this.blocks.size(); i++)
		{
			if(this.blocks.elementAt(i).type == Block.immobile)
				iblocks.add(this.blocks.elementAt(i));
		}
		return iblocks;
	}
	
	public Vector<Block> getMobileBlocks()
	{
		Vector <Block> mblocks = new Vector<Block>();
		for(int i=0; i<this.blocks.size(); i++)
		{
			if(this.blocks.elementAt(i).type == Block.mobile)
				mblocks.add(this.blocks.elementAt(i));
		}
		return mblocks;
	}
	
	public Vector<Actor> getActors()
	{
		return actors;
	}

	public void clear() 
	{
		actors.clear();
		blocks.clear();
	}

}
