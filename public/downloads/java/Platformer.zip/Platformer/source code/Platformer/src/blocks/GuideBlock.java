package blocks;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

import bases.Block;

@SuppressWarnings("unused")
public class GuideBlock extends Block
{
	Color actorColor = new Color(255,0,0,100);
	Color tileColor = new Color(255,0,0,100);
	Color exitTileColor = new Color(0,0,255,100);
	Color moveTileColor = new Color(255,0,0,100);
	Color spikeColor = new Color(0,0,0,100);
	
	int numOfTiles =5;
	
	public int x = 0;
	public int y = 0;
	
	int guideTile = 0;
	
	public GuideBlock(int x, int y)
	{
		this.x = x;
		this.y = y;
		this.type = immobile;
	}

	@Override
	public void draw(Graphics2D gr) 
	{
		switch(guideTile)
		{
		case 0:
			gr.setColor(actorColor);
			gr.fillRect(x, y, 32, 32);
			break;
		case 1:
			gr.setColor(tileColor);
			gr.drawRect(x, y,32, 32);
			break;
		case 2:
			gr.setColor(exitTileColor);
			gr.fillRect(x, y, 32, 32);
			break;
		case 3: 
			gr.setColor(moveTileColor);
			gr.drawLine(x, y, x+32, y+32);
			break;
		case 4:
			gr.setColor(spikeColor);
			gr.drawLine(x, y+32, x+16, y);
			gr.drawLine(x+16, y,x+32, y+32);
			break;
		}
	}

	@Override
	public void update() 
	{
		
	}
	
	public void toggleUp()
	{
		guideTile++;
		if(guideTile > numOfTiles - 1)
			guideTile = 0;
	}
	
	public void toggleDown()
	{
		guideTile++;
		if(guideTile < 0)
			guideTile = numOfTiles -1;
	}

	@Override
	public void updateX() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateY() {
		// TODO Auto-generated method stub
		
	}
}
