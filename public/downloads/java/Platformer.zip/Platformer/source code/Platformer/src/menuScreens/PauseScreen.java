package menuScreens;

import java.awt.Dimension;
import java.awt.Graphics2D;

import main.Main;
import managers.MenuScreen;
import bases.Screen;

public class PauseScreen extends MenuScreen
{

	public PauseScreen(String title, Dimension srcDimension, int size,Screen parentScreen)
	{
		super(title, srcDimension, size, parentScreen);
	}
	
	protected void init(Graphics2D gr)
	{
		addButton(new String [] {"Continue"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"Restart"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"Chicken Out"}, this.buttonFont, this.buttonColor);
		addButton(new String [] {"Quit"}, this.buttonFont, this.buttonColor);
	}
	
	protected void buttonClick(int buttonIndex)
	{
		switch (buttonIndex) 
		{
		case 0:
			screenManager.remove(this);
			parentScreen.pause();
			break;
			
		case 1:
			screenManager.remove(this);
			parentScreen.pause();
			parentScreen.takeInput("reload");
			break;
		case 2:
			screenManager.remove(this);
			parentScreen.pause();
			parentScreen.takeInput("levelWon");
			break;
		case 3:
			screenManager.remove(this);
			parentScreen.takeInput("quit");
			break;
		}
	}
}
