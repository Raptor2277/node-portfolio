package misc;

public class Container 
{
	/*double newVelocity = (Math.abs(yVelocity) + Math.abs(xVelocity))/2;
	double yCoefficient = Math.abs(yVelocity) / Math.abs(xVelocity);
	double xCoefficient = Math.abs(xVelocity) / Math.abs(yVelocity);
	
	if(xVelocity != 0 && yVelocity != 0)
	{
		xVelocity = Math.sqrt(Math.pow(newVelocity, 2)/(Math.pow(xCoefficient, 2)+1));
		if(orginallXVelocity < 0)
			xVelocity*=-1;
		
		yVelocity = Math.sqrt(Math.pow(newVelocity, 2)/(Math.pow(yCoefficient, 2)+1));
		if(originalYVelocity < 0)
			yVelocity*=-1;
	}
	
	if(xVelocity != 0 && yVelocity != 0)
	{
		xVelocity = Math.sqrt(Math.pow(velocity, 2)/2);
		if(orginallXVelocity < 0)
			xVelocity*=-1;
		
		yVelocity = Math.sqrt(Math.pow(velocity, 2)/2);
		if(originalYVelocity < 0)
			yVelocity*=-1;
	}*/
	
}
