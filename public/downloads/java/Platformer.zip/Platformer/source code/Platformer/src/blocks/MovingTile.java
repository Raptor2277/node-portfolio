package blocks;

import java.awt.Graphics2D;
import java.util.Vector;
import misc.Collision;
import bases.Actor;
import bases.Screen;

public class MovingTile extends Tile 
{
	public int initialX;
	public int initialY;
	public int firstBoundX;
	public int secondBoundX;
	public int firstBoundY;
	public int secondBoundY;
	
	public final int velocity = 1;
	
	public double velocityX;
	public double velocityY;
	
	public double storedVelocityX;
	public double storedVelocityY;
	
	public boolean vertical;
	public boolean horizontal;
	
	public boolean drawPath;
	
	public MovingTile(Screen parentScreen, int x, int y, int firstBoundX, int firstBoundY,  int secondBoundX, int secondBoundY) 
	{
		super(parentScreen, x, y);
		
		this.parentScreen = parentScreen;
		
		this.initialX =x;
		this.initialY =y;
		
		this.firstBoundX = firstBoundX;
		this.firstBoundY = firstBoundY;
		this.secondBoundX = secondBoundX;
		this.secondBoundY = secondBoundY;
		
		this.drawPath = false;
		this.type = mobile;
		this.id = 3;
		
		this.vertical = true;
		this.horizontal = true;
		
		if(firstBoundX==secondBoundX)
			horizontal = false;
		if(firstBoundY==secondBoundY)
			vertical = false;
		
		calculateVelocities();
	}
	
	public void draw(Graphics2D gr) 
	{
		gr.setColor(color);
		gr.drawRect(positionBox.x, positionBox.y, positionBox.width,positionBox.height);
		if(drawPath)
			gr.drawLine(firstBoundX+16, firstBoundY+16, secondBoundX+16, secondBoundY+16);
	}
	
	public void updateX()
	{
		if(horizontal){
			this.storedVelocityX += velocityX;
			if(Math.abs(storedVelocityX) >= 1){
				
				int velocity = (int)storedVelocityX;
				this.storedVelocityX -= velocity;
				
				this.positionBox.x += velocity;
				this.collisionBox.x = this.positionBox.x;
						
				Vector <Actor> actors = this.parentScreen.getContent().getActors();
				
				for(int i=0; i<actors.size(); i++)
				{
					if(Collision.hasBlockOnTop(actors.elementAt(i).positionBox, this.collisionBox))
					{
						if(!actors.elementAt(i).imovable){
							actors.elementAt(i).pushX(actors.elementAt(i).positionBox.x + velocity);
							actors.elementAt(i).takeInput("checkOnTop", velocity);
						}
					}
				}
				
				if(firstBoundX > secondBoundX){
					if(this.collisionBox.x + storedVelocityX > firstBoundX){
						this.positionBox.x = firstBoundX;
						this.storedVelocityX = 0;
						this.velocityX*=-1;
					}
					
					if(this.collisionBox.x + storedVelocityX < secondBoundX){
						this.positionBox.x = secondBoundX;
						this.storedVelocityX = 0;
						this.velocityX*=-1;
					}
				}
				else{
					if(this.collisionBox.x + storedVelocityX < firstBoundX){
						this.positionBox.x = firstBoundX;
						this.storedVelocityX = 0;
						this.velocityX*=-1;
					}
					
					if(this.collisionBox.x + storedVelocityX  > secondBoundX){
						this.positionBox.x = secondBoundX;
						this.storedVelocityX = 0;
						this.velocityX*=-1;
					}
				}
			}	
		}
	}
		
	public void updateY()
	{
		if(vertical){
			this.storedVelocityY += velocityY;
			if(Math.abs(storedVelocityY) >= 1){
				
				int velocity = (int)storedVelocityY;
				this.storedVelocityY -= velocity;
				
				this.positionBox.y += velocity;
				this.collisionBox.y = this.positionBox.y;
				
				if(firstBoundY > secondBoundY){
					if(this.collisionBox.y + storedVelocityY > firstBoundY){
						this.positionBox.y = firstBoundY;
						this.storedVelocityY = 0;
						this.velocityY*=-1;
					}
					
					if(this.collisionBox.y + storedVelocityY < secondBoundY){
						this.positionBox.y =secondBoundY;
						this.storedVelocityY = 0;
						this.velocityY*=-1;
					}
					
				}else{
					if(this.collisionBox.y + storedVelocityY < firstBoundY){
						this.positionBox.y = firstBoundY;
						this.storedVelocityY = 0;
						this.velocityY*=-1;
					}
					
					if (this.collisionBox.y + storedVelocityY> secondBoundY){
						this.positionBox.y = secondBoundY;
						this.storedVelocityY = 0;
						this.velocityY*=-1;
					}
				}
			
				//not updating the collisionBox WILL lead to interesting bugs
				this.collisionBox.y = this.positionBox.y;
				
				Vector <Actor> actors = this.parentScreen.getContent().getActors();
				
				for(int i=0; i<actors.size(); i++)
				{
					if(Collision.checkCollision(this.collisionBox, actors.elementAt(i).positionBox))
					{
						if(actors.elementAt(i).positionBox.y < this.collisionBox.y)
						{
							actors.elementAt(i).pushY(this.positionBox.y - actors.elementAt(i).positionBox.height);
						}
						else
						{
							actors.elementAt(i).pushY(this.positionBox.y + this.collisionBox.height);
						}
					}
				}
			}
		}
		
	}
	
	private void calculateVelocities()
	{
		double yDiff = 0;
		double xDiff = 0;
		
		yDiff = Math.abs(firstBoundY-secondBoundY);
		xDiff = Math.abs(firstBoundX-secondBoundX);
		
		/*if(yDiff > xDiff)    this is the old method, this lets the higher distance stay at 1 velocity and trims the lower one by the ratio of the distances
			velocityX=velocityX*xDiff/yDiff;
		else if(yDiff < xDiff)
			velocityY=velocityY*yDiff/xDiff;*/
		
		
		//new method, uses the pathageron theorem to change the velocities so that their diagonal velocity is one
		velocityX = Math.sqrt(Math.pow(velocity, 2) / (1 + Math.pow((yDiff/xDiff),2)));
		velocityY = Math.sqrt(Math.pow(velocity, 2) / (1 + Math.pow((xDiff/yDiff),2)));
		
		if(firstBoundX > secondBoundX)
			this.velocityX *= -1;
		
		if(firstBoundY > secondBoundY)
			this.velocityY *= -1;
		
		System.out.printf("x: %f y: %f\n", velocityX, velocityY);
		
	}
	
}
