package bases;

import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Point;

import javax.swing.JPanel;

import managers.ContentManager;
import managers.ScreenManager;
import misc.OptionsCarrier;
import misc.vKeyEvent;
import misc.vMouseEvent;

public abstract class Screen
{
	//methods that get set by the screen manager and thus are null when the subsclass initializes
	//if the subclass wants to use one of these, they will use them in the init() method
	public ScreenManager screenManager;
	public Dimension appDimension;
	public JPanel pannel;
	
	public Dimension dimension;
	public Point position;
	public Screen parentScreen;
	public boolean [] keys;
	public boolean [] buttons;
	
	public boolean isActive = false;
	public boolean isDrawn = false;
	
	public abstract void init();
	
	public abstract void draw(Graphics2D gr);
	
	public abstract void update();
	
	public abstract void pause();
	
	public abstract void handleKeyBoardInput(vKeyEvent e);
	
	public abstract void handleMouseInput(vMouseEvent e);
	
	public abstract void takeInput(String args);
	
	public abstract OptionsCarrier getOptions();
	
	public abstract ContentManager getContent();

}
