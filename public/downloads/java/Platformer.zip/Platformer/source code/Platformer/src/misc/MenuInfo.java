package misc;

public class MenuInfo 
{
	
}
