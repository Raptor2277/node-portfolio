[controls]
	WASD 		- movement
	E 		- shoot projectile
	mouseButton 	- place blocks
	Q(hold)		- select blocks
	R		- remove blocks
	B		- remove last placed block

[executable]
	./source/SDL_RPG.exe