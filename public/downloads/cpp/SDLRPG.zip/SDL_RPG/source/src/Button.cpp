#include "Button.h"

Button::Button(int id,int x,int y, int w, int h)
{
    xPos=x;
    yPos=y;
    width=w;
    height=h;
    ID=id;
    buttonDown=false;
    
    setSprite();
}

void Button::handleEvent( SDL_Event *e , int *id)
{
    int x, y;
    bool inside = true;
    
    SDL_GetMouseState( &x, &y);

    if(x < xPos)
        inside=false;
    else if (x > xPos + width)
        inside=false;
    else if (y > yPos + height)
        inside=false;
    else if (y < yPos)
        inside=false;

    if(!inside)
    {
        
    }
    else
    {
        switch( e->type )
        {

            case SDL_MOUSEBUTTONDOWN:
                buttonDown=true;
                break;

            case SDL_MOUSEBUTTONUP:
                if(buttonDown)
                {
                    switch(ID)
                    {
                        case 01:
                            cout<<"hey"<<endl;
                        break;

                        case 02:

                            break;

                        case 03:

                            break;

                        case 04:

                            break;

                        case 05:

                            break;
                    }
                    *id=ID;
                    buttonDown=false;
                }
                break;
        }
    }
}

Button::~Button()
{
    //dtor
}

void Button::setSprite()
{
    switch(ID)
    {
        case 1:
            sprites[0].x=0;
            sprites[0].y=0;
            sprites[0].h=64;
            sprites[0].w=64;
            
        break;
        
        case 2:
            sprites[0].x=64;
            sprites[0].y=0;
            sprites[0].h=64;
            sprites[0].w=64;
            
        break;
        
        case 3:
            sprites[0].x=128;
            sprites[0].y=0;
            sprites[0].h=64;
            sprites[0].w=64;
            
        break;
        
        case 4:
            sprites[0].x=0;
            sprites[0].y=64;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 5:
            sprites[0].x=64;
            sprites[0].y=64;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 6:
            sprites[0].x=128;
            sprites[0].y=64;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 7:
            sprites[0].x=0;
            sprites[0].y=128;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 8:
            sprites[0].x=64;
            sprites[0].y=128;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 9:
            sprites[0].x=128;
            sprites[0].y=128;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 10:
            sprites[0].x=192;
            sprites[0].y=0;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 11:
            sprites[0].x=192;
            sprites[0].y=64;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 12:
            sprites[0].x=192;
            sprites[0].y=128;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 13:
            sprites[0].x=192;
            sprites[0].y=192;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
    }
}

void Button::render()
{
    gButtonTexture.renderSimple(xPos, yPos, &sprites[0]);
}
