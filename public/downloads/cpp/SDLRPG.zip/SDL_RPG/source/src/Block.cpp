#include "Block.h"

Block::Block()
{
    xPos=0;
    yPos=0;
    width=0;
    height=0;
    ID=0;
    currentSprite=0;
    setSprite();
}

Block::Block(int tileType, int x, int y, int w, int h)
{
    xPos=x;
    yPos=y;
    width=w;
    height=h;
    ID=tileType;
    currentSprite=0;
    setSprite();
    setColBox();
}

void Block::setSprite()
{
    
    switch(ID)
    {
        case 1:
            sprites[0].x=0;
            sprites[0].y=0;
            sprites[0].h=64;
            sprites[0].w=64;
            
        break;
        
        case 2:
            sprites[0].x=64;
            sprites[0].y=0;
            sprites[0].h=64;
            sprites[0].w=64;
            
        break;
        
        case 3:
            sprites[0].x=128;
            sprites[0].y=0;
            sprites[0].h=64;
            sprites[0].w=64;
            
        break;
        
        case 4:
            sprites[0].x=0;
            sprites[0].y=64;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 5:
            sprites[0].x=64;
            sprites[0].y=64;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 6:
            sprites[0].x=128;
            sprites[0].y=64;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 7:
            sprites[0].x=0;
            sprites[0].y=128;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 8:
            sprites[0].x=64;
            sprites[0].y=128;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 9:
            sprites[0].x=128;
            sprites[0].y=128;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 10:
            sprites[0].x=192;
            sprites[0].y=0;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 11:
            sprites[0].x=192;
            sprites[0].y=64;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 12:
            sprites[0].x=192;
            sprites[0].y=128;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
        
        case 13:
            sprites[0].x=192;
            sprites[0].y=192;
            sprites[0].h=64;
            sprites[0].w=64;
        break;
    }
    
}

void Block::setColBox()
{
    colBox.x=xPos;
    colBox.y=yPos;
    colBox.w=width;
    colBox.h=height;
    
    switch(ID)
    {
        case 1:
            colBox.y+=5;
            colBox.h-=5;
        break;
        
        case 2:
            colBox.y+=5;
            colBox.h-=5;
        break;
        
        case 3:
            colBox.y+=5;
            colBox.h-=5;
        break;
        
    }
}

void Block::render()
{
    gBlockTexture.renderSimple(xPos - camera.x, yPos - camera.y, &sprites[0]);
}

Block::~Block()
{
    
}
