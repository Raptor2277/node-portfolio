#include "Projectile.h"

Projectile::Projectile(int x, int y, float w, float h, float vel, float xVel, float yVel)
{
    xPos=x;
    yPos=y;
    width=w;
    height=h;
    velocity=vel;
    colBox.x=x;
    colBox.y=y;
    colBox.w=w;
    colBox.h=h;
    currentSprite=0;
    destroy=false;
    flip=SDL_FLIP_NONE;

    Projectile::yVel=yVel;
    Projectile::xVel=xVel;


    setSprite();
}

Projectile::~Projectile()
{

}

void Projectile::move(vector <Block> tiles , float timeStep)
{

    //wichtile for the y check
    int whichTile=0;
    int whichMonster=0;

    xPos+=xVel*timeStep;
    colBox.x=xPos;

    if(xPos < 0 || xPos + width > LEVEL_WIDTH || touchesWall(colBox, tiles, whichTile))
    {
        if(xVel>0)
            xPos=LEVEL_WIDTH-width;
        else if(xVel<0)
            xPos=0;
        xVel*=-1;
        destroy=true;
    }

    yPos+=yVel*timeStep;
    colBox.y=yPos;

    if(yPos < 0 || yPos + height > LEVEL_HEIGHT || touchesWall(colBox, tiles, whichTile))
    {
        if(yVel>0)
            yPos=LEVEL_HEIGHT-height;
        else if(yVel<0)
            yPos=0;
        yVel*=-1;
        destroy=true;
    }
}

void Projectile::setSprite()
{
    sprites[0].x=0;
    sprites[0].y=0;
    sprites[0].h=20;
    sprites[0].w=20;
}

void Projectile::render()
{
    projectileTexture.render(xPos - camera.x, yPos - camera.y, &sprites[currentSprite],0,NULL, flip);
}
