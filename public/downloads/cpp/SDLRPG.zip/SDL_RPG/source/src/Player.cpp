#include "Player.h"

Player::Player(int x, int y, int w, int h)
{
    xPos=x;
    yPos=y;
    width=w;
    height=h;
    colBox.x=x;
    colBox.y=y;
    colBox.w=w;
    colBox.h=h;;
    currentSprite=0;
    flip=SDL_FLIP_NONE;
    angle=0;

    yVel=0;
    xVel=0;

    state=FALLING;

    setSprite();
}

void Player::handleEvent(SDL_Event &e)
{

    if(e.type == SDL_KEYDOWN && e.key.repeat == 0)
    {
        switch(e.key.keysym.sym)
        {
            case SDLK_w:
                yVel = -750;
                break;
            case SDLK_a:
                xVel-=velocity;
                flip = SDL_FLIP_NONE;
                break;
            case SDLK_d:
                xVel+=velocity;
                flip = SDL_FLIP_HORIZONTAL;
                break;
        }
    }
    else if (e.type==SDL_KEYUP && e.key.repeat == 0)
    {
        switch(e.key.keysym.sym)
        {
            case SDLK_a:
                xVel+=velocity;
                break;
            case SDLK_d:
                xVel-=velocity;
                break;
        }
    }
}

void Player::move(vector <Block> tiles, float timeStep)
{
    //wichtile for the y check
    int whichTile=0;

    //change the x pos
    xPos+=xVel*timeStep;
    colBox.x=xPos;

    //if colided---------------------------x-----------------------
    if(xPos < 0 || xPos + width > LEVEL_WIDTH || touchesWall(colBox, tiles, whichTile))
    {
        if(xPos < 0 || xPos + width > LEVEL_WIDTH) //if colies with level
        {
            if(xVel<0) //if coliedes with left
            {
                xPos=0;
            }
            else if(xVel>0) //if colieds with right
            {
                xPos=LEVEL_WIDTH-width;
            }

            colBox.x=xPos; //update colbox
        }
        else //if coleds with block
        {
            if(xVel<0) //if coliedes with right side of block
            {
                xPos=tiles[whichTile].colBox.x+tiles[whichTile].colBox.w; //get col box y + height and set its to its y
            }
            else if(xVel>0) //if colieds with left side of block
            {
                xPos=tiles[whichTile].colBox.x-width; //get col box y of box and set it to it - height

            }
            colBox.x=xPos;
        }
    }

    //-----------------------------y vel-------------
    yVel += GRAVITY * timeStep;
    if(yVel > 1000)
        yVel = 1000;
    yPos+= yVel * timeStep;
    colBox.y=yPos;

    if(yPos < 0 || yPos + height > LEVEL_HEIGHT || touchesWall(colBox, tiles, whichTile))
    {
        if(yPos < 0 || yPos + height > LEVEL_HEIGHT) //if colies with level
        {
            if(yVel<0) //if coliedes with top
            {
                yPos=0;
            }
            else if(yVel>0) //if colieds with bottom
            {
                yPos=LEVEL_HEIGHT-height;
            }

            colBox.y=yPos; //update colbox
        }
        else //if coleds with block
        {
            if(yVel<0) //if coliedes with top
            {
                yPos=tiles[whichTile].colBox.y+tiles[whichTile].colBox.h; //get col box y + height and set its to its y
            }
            else if(yVel>0) //if colieds with bottom
            {
                yPos=tiles[whichTile].colBox.y-height; //get col box y of box and set it to it - height
            }
            colBox.y=yPos;
        }
        yVel = 0;
    }
}

Player::~Player()
{
    delete[] sprites;
}

void Player::setSprite()
{
    sprites[0].x=0;
    sprites[0].y=0;
    sprites[0].h=75;
    sprites[0].w=41;
}

void Player::render()
{
    playerTexture.render(xPos - camera.x, yPos - camera.y, &sprites[currentSprite],angle,NULL,flip);
}
