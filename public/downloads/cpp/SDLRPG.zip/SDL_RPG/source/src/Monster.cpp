#include "Monster.h"

Monster::Monster(int x, int y, float w, float h, float vel, float xVel, float yVel)
{
    xPos=x;
    yPos=y;
    width=w;
    height=h;
    velocity=vel;
    colBox.x=x;
    colBox.y=y;
    colBox.w=w;
    colBox.h=h;
    currentSprite=0;
    flip=SDL_FLIP_HORIZONTAL;
    destroy=false;

    Monster::yVel=yVel;
    Monster::xVel=xVel;

    state=FALLING;

    setSprite();
}

Monster::~Monster()
{

}

void Monster::move(vector <Block> tiles , float timeStep)
{

    //wichtile for the y check
    int whichTile=0;

    xPos+=xVel*timeStep;
    colBox.x=xPos;

    if(xPos < 0 || xPos + width > LEVEL_WIDTH || touchesWall(colBox, tiles, whichTile))
    {
        if(xVel>0)
            xPos=LEVEL_WIDTH-width;
        else if(xVel<0)
            xPos=0;
        xVel*=-1;
        destroy=true;
    }

    yPos+=yVel*timeStep;
    colBox.y=yPos;

    if(yPos < 0 || yPos + height > LEVEL_HEIGHT || touchesWall(colBox, tiles, whichTile))
    {
        if(yVel>0)
            yPos=LEVEL_HEIGHT-height;
        else if(yVel<0)
            yPos=0;
        yVel*=-1;
        destroy=true;
    }
}

void Monster::setSprite()
{
    sprites[0].x=0;
    sprites[0].y=0;
    sprites[0].h=102;
    sprites[0].w=92;
}

void Monster::render()
{
    monsterTexture.render(xPos - camera.x, yPos - camera.y, &sprites[currentSprite],0,NULL,flip);
}

void Monster::action(Player player1)
{
    //xvel
    if(player1.getxPos() > xPos+width)
    {
        xVel=250;
        flip=SDL_FLIP_HORIZONTAL;
    }
    else if (player1.getxPos()+player1.getWidth()< xPos)
    {
        xVel=-250;
        flip=SDL_FLIP_NONE;
    }
    else
    {
        xVel=0;
    }

    //ywel
    if(player1.getyPos() > yPos+height)
    {
        yVel=250;
    }
    else if(player1.getyPos() < yPos)
    {
        yVel=-250;
    }
    else
    {
        yVel=0;
    }
}

