#include "Texture.h"
#include <iostream>
using namespace std;

Texture::Texture()
{
    texture = NULL;
    width = 0;
    height = 0;
}

Texture::~Texture()
{
    free();
}

bool Texture::loadFromFile( string path )
{
    bool success=true;
    free();

    SDL_Texture* newTexture = NULL;
    SDL_Surface* loadedSurface = IMG_Load( path.c_str());
    if(loadedSurface == NULL)
    {
        cout<<IMG_GetError()<<endl;
        success=false;
    }
    else
    {
        //set color key
        SDL_SetColorKey( loadedSurface, SDL_TRUE, SDL_MapRGB( loadedSurface->format, 0, 255,255));
        newTexture = SDL_CreateTextureFromSurface( gRenderer, loadedSurface);
        if(newTexture == NULL)
        {
            cout<<SDL_GetError()<<endl;
            success=false;
        }
        else
        {
            width = loadedSurface->w;
            height = loadedSurface->h;
        }
        SDL_FreeSurface( loadedSurface );
    }

    texture = newTexture;
    return success;
}

void Texture::free()
{
    if (texture != NULL)
    {
        SDL_DestroyTexture( texture );
        texture = NULL;
        width=0;
        height=0;
    }
}

void Texture::setColor( Uint8 red, Uint8 green, Uint8 blue )
{
	SDL_SetTextureColorMod( texture, red, green, blue );
}

void Texture::setBlendMode( SDL_BlendMode blending )
{
	SDL_SetTextureBlendMode( texture, blending );
}

void Texture::setAlpha( Uint8 alpha )
{
	SDL_SetTextureAlphaMod( texture, alpha );
}

void Texture::render( int x, int y, SDL_Rect* clip, double angle, SDL_Point* center, SDL_RendererFlip flip )
{
	SDL_Rect renderQuad = { x, y, width, height }; //render quad FROM PICTURE, witdth and heiht is defaul to the picture size

	if( clip != NULL )
	{
		renderQuad.w = clip->w; //if clip is entered, then it is that height, 
		renderQuad.h = clip->h;
	}

	SDL_RenderCopyEx( gRenderer, texture, clip, &renderQuad, angle, center, flip );
}

void Texture::renderSimple(int x, int y, SDL_Rect* clip)
{
    SDL_Rect renderQuad = {x, y, width, height };

    if(clip != NULL)
    {
        renderQuad.h=clip->h;
        renderQuad.w=clip->w;
    }

    SDL_RenderCopy( gRenderer, texture, clip, &renderQuad);
}
