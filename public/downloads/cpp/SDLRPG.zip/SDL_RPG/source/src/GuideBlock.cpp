#include "GuideBlock.h"

GuideBlock::GuideBlock(int tileType, int x, int y, int w, int h)
{
    xPos=x;
    yPos=y;
    width=w;
    height=h;
    ID=tileType;
    currentSprite=0;
    setSprite();
    setColBox();
    gGuideBlockTexture.setAlpha(125);
}

GuideBlock::~GuideBlock()
{
    //dtor
}

void GuideBlock::render()
{
    gGuideBlockTexture.renderSimple(xPos-camera.x, yPos-camera.y, &sprites[currentSprite]);
}
