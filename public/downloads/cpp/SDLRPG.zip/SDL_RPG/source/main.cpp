#include "API.h"
#include "Texture.h"
#include "Player.h"
#include "Block.h"
#include "GuideBlock.h"
#include "Button.h"
#include "Timer.h"
#include "Projectile.h"

using namespace std;

//camera
SDL_Rect camera = {0,0, SCREEN_WIDTH, SCREEN_HEIGHT};

//window and surface
SDL_Window* gWindow = NULL;
SDL_Renderer* gRenderer = NULL;

//textures, sounds, etc
Texture playerTexture;
Texture gBlockTexture;
Texture gGuideBlockTexture;
Texture gButtonTexture;
Texture projectileTexture;

vector <Block> dirt;
vector <Button> buttons;
vector <Projectile> projectiles;

int main(int arc, char* argv[])
{
    srand(time(NULL));
    bool quit = false;
    if(!init())
    {
        cout<<"Could not initialize"<<endl;
        quit=true;
    }else if(!loadMedia())
    {
        cout<<"Could not load media"<<endl;
        quit=true;
    }else if(!setTiles(dirt))
    {
        cout<<"Could not load tiles"<<endl;
        quit=true;
    }

    int x=0;
    int y=0;

    int id=1;
    SDL_Event e;

    bool showButtonMenu=false;

    Player player1(100,500,41,75);
    GuideBlock guide(01,0,0,64,64);

    //buttons
    for (int i=1; i<14; i++)
    {
        static int x = 6;
        static int y = 6;
        buttons.push_back(Button(i,x,y,64,64));
        x+=70;
        if(i%3==0)
        {
            y+=70;
            x=6;
        }

    }

    Timer frameCap;
    Timer stepTimer;
    //---------------main loop-------------------
    while(!quit)
    {
        frameCap.start();

        while(SDL_PollEvent( &e ) != 0)
        {
            if(e.type == SDL_QUIT)
            {
                quit = true;
            }

            //for blocks
            SDL_GetMouseState(&x,&y);
            x+=camera.x;
            y+=camera.y;
            int offsetx=x%64;
            int offsety=y%64;
            x-=offsetx;
            y-=offsety;
            //cout<<x<<endl<<y<<endl;
            //cout<<"camerax: "<<camera.x<<"\ncameray: "<<camera.y<<endl;
            guide.setPos(x,y);
            guide.setColBox();

            if(e.type == SDL_KEYDOWN)
            {
                switch(e.key.keysym.sym)
                {
                    case SDLK_q:
                        showButtonMenu=true;
                        break;

                    case SDLK_ESCAPE:
                        quit=true;
                        break;

                    case SDLK_r:
                        for (vector<Block>::size_type i=0; i<dirt.size(); i++)
                        {
                            if(dirt[i].getxPos() == x && dirt[i].getyPos() == y)
                            {
                                dirt.erase(dirt.begin() + i); //delete the one that the mouse is on
                            }
                        }
                        break;

                    case SDLK_b:
                        if(dirt.size() > 0)
                        {
                            dirt.erase(dirt.begin()+dirt.size()); //delete previous
                        }
                        break;

                    case SDLK_e:
                        SDL_GetMouseState(&x, &y);
                        float xVel= (player1.getxPos()-camera.x+25-12)-x;
                        float yVel= (player1.getyPos()-camera.y+25-12)-y;
                        cout<<"xvel= "<<xVel<<endl<<"yvel= "<<yVel<<endl<<endl;

                        projectiles.push_back(Projectile(player1.getxPos()+25-12,player1.getyPos()+25-12,20,20,1,-xVel,-yVel));
                        break;
                }
            }
            else if (e.type == SDL_KEYUP)
            {
                switch(e.key.keysym.sym)
                {
                    case SDLK_q:
                        showButtonMenu=false;
                }
            }

            if(e.type == SDL_MOUSEBUTTONDOWN)
            {
                if(!showButtonMenu)
                {
                    bool isEmpty=true;

                    //go through all the boxes
                    for (vector<Block>::size_type i=0; i<dirt.size(); i++) //totaltiles-1 to not check the one following the mouse
                    {   //make sure its empty
                        if(dirt[i].getxPos() == x && dirt[i].getyPos() == y)
                        {
                            isEmpty=false;
                        }
                    }
                    if(isEmpty && !checkCollision(player1.getColBox(), guide.getColBox())) //make sure it doesnt collide with player
                    {
                        dirt.push_back(Block(id, x, y, 64,64));//new box on the next array index
                        cout<<endl<<dirt.size();
                    }
                }
            }

            player1.handleEvent( e );

            if(showButtonMenu)
            {
                for ( vector <Button>::size_type i=0; i<buttons.size(); i++)
                {
                    buttons[i].handleEvent( &e , &id);
                }
                guide.setID(id);
            }

        }
        //----------------------------out of event loop-------------------

        float timeStep = stepTimer.getTicks() / 1000.f;
        player1.move( dirt, timeStep);

        for(vector<Projectile>::size_type i=0; i<projectiles.size(); i++)
        {
            timeStep = stepTimer.getTicks() / 1000.f;
            projectiles[i].move( dirt, timeStep );
            if(projectiles[i].destroy)
            {
                projectiles.erase(projectiles.begin() + i);
            }
        }

        stepTimer.start();
        //------------------------------------render----------------------------
        //position camera
        setCamera(( player1.getxPos() + player1.getWidth() / 2 ) - (SCREEN_WIDTH / 2),
                  ( player1.getyPos() + player1.getHeight() / 2 ) - (SCREEN_HEIGHT / 2));

        //clear
        SDL_RenderClear(gRenderer);

        player1.render();

        for(vector<Block>::size_type i = 0; i<dirt.size(); i++)
        {
            dirt[i].render();
        }

         for(vector<Projectile>::size_type i = 0; i<projectiles.size(); i++)
        {
            projectiles[i].render();
        }

        if(showButtonMenu)
        {
            for(vector<Button>::size_type i=0; i<buttons.size(); i++)
            {
                buttons[i].render();
            }
        }
        else
        {
            guide.render();
        }

        SDL_RenderPresent(gRenderer);

        //frame capping
        float frameTime = frameCap.getTicks();
        if(frameTime < FRAME_DELAY)
        {
            SDL_Delay(FRAME_DELAY-frameTime);
        }
    }

    saveTiles(dirt);
    close();
    return 0;
}

bool loadMedia()
{
    bool success=true;
    if (!playerTexture.loadFromFile("data/man.png"))
        success=false;
    if(!gBlockTexture.loadFromFile("data/blockSheet.png"))
        success=false;
    if(!gGuideBlockTexture.loadFromFile("data/blockSheet.png"))
        success=false;
    if(!gButtonTexture.loadFromFile("data/blockSheet.png"))
        success=false;
    if(!projectileTexture.loadFromFile("data/dot.png"))
        success=false;

    return success;
}

void close()
{
    playerTexture.free();
    gBlockTexture.free();

    dirt.clear();

    SDL_DestroyWindow( gWindow);
    gWindow = NULL;

    SDL_Quit();
    IMG_Quit();
}

bool checkCollision(SDL_Rect a, SDL_Rect b)
{
    bool colided=true;

    if(a.y + a.h <= b.y)
        colided=false;
    if(a.y >= b.y+b.h)
        colided=false;
    if(a.x + a.w <= b.x)
        colided=false;
    if(a.x >= b.x+b.w)
        colided=false;

    return colided;
}

bool touchesWall(SDL_Rect box,vector <Block> tiles, int &wichTile)
{
    for(vector<Block>::size_type i =0; i<tiles.size(); i++)
    {
        if(tiles[i].getxPos() > camera.x-tiles[i].getWidth() && tiles[i].getxPos() < camera.x + camera.w )
        {
            if(checkCollision(box, tiles[i].getColBox()))
            {
                wichTile=i;
                return true;
            }
        }

    }
    return false;
}

bool setTiles( vector <Block> tiles )
{

	bool tilesLoaded = true;

    int x,y;
    int tileType;

    fstream data;
    data.open("data/map.txt");

    if( data == NULL )
    {
		cout<<"Unable to load map"<<endl;
		tilesLoaded = false;
    }
	else
	{

		while(data>>tileType && data>>x && data>>y)
		{

            if(tileType > 0)
            {
                dirt.push_back(Block(tileType, x,y,64,64));
            }

		}
	}
    //Close the file
    data.close();

    //If the map was loaded fine
    return tilesLoaded;
}

bool init()
{
    bool success = true;
    if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0)
    {
        cout<<SDL_GetError()<<endl;
        success=false;
    }

    gWindow = SDL_CreateWindow("My first SDL", 20, 30 , SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
    if(gWindow == NULL)
    {
        cout<<SDL_GetError()<<endl;
        success=false;
    }


    if(!SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1"))
    {
        cout<<"Liner texture filetering not enabled"<<endl;
        success-false;
    }

    gRenderer= SDL_CreateRenderer(gWindow, -1, SDL_RENDERER_ACCELERATED );
    //gRenderer= SDL_CreateRenderer(gWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC );
    SDL_SetRenderDrawColor(gRenderer, 100,100,100,255);
    if(gRenderer== NULL)
    {
        cout<<SDL_GetError()<<endl;
        success-false;
    }

    int imgFlags = IMG_INIT_PNG;
    if( !( IMG_Init( imgFlags ) & imgFlags ) )
    {
        cout<<IMG_GetError()<<endl;
        success-false;
    }

    return success;
}

int getTotalTiles()
{
    fstream data;
    data.open("data/map.txt");

    if(!data.is_open())
        cout<<"Could not getTotalTiles();"<<endl;

    int x, y, z;
    int num=0;

    while(data>>x && data>>y && data>>z)
    {
        num++;
    }

    data.close();

    return num;
}

void saveTiles(vector <Block> tiles)
{
    ofstream data("data/map.txt");

    if(data.is_open())
    {
        for (vector<Block>::size_type i=0; i<tiles.size(); i++)
        {
            data<<tiles[i].getID()<<" ";
            data<<tiles[i].getxPos()<<" ";
            data<<tiles[i].getyPos()<<" ";
            data<<"\n";
        }
    }
}

void setCamera(int x, int y)
{
    camera.x = x;
    camera.y = y;

    if(camera.x < 0)
    {
        camera.x=0;
    }
    if(camera.y < 0)
    {
        camera.y=0;
    }
    if(camera.x > LEVEL_WIDTH - SCREEN_WIDTH)
    {
        camera.x=LEVEL_WIDTH - SCREEN_WIDTH;
    }
    if(camera.y > LEVEL_HEIGHT - SCREEN_HEIGHT)
    {
        camera.y=LEVEL_HEIGHT - SCREEN_HEIGHT;
    }
}
