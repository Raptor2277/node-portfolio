#ifndef TEXTURE_H
#define TEXTURE_H

#include "API.h"

using namespace std;

class Texture
{
    public:

        Texture();

        ~Texture();

        bool loadFromFile (string path);

        void free();
        
        void setColor( Uint8 red, Uint8 green, Uint8 blue );
        
        void render( int x, int y, SDL_Rect* clip = NULL, double angle = 0.0, SDL_Point* center = NULL, SDL_RendererFlip flip = SDL_FLIP_NONE );
        
        void setBlendMode( SDL_BlendMode blending );
        
		void setAlpha( Uint8 alpha );
        
        void renderSimple(int x, int y, SDL_Rect* clip = NULL);
        
        int getWidth() {return width;}
        int getHeight() {return height;}

    private:
        SDL_Texture* texture;

        int width;
        int height;
};

#endif // TEXTURE_H
