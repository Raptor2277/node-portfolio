#ifndef API_H_INCLUDED
#define API_H_INCLUDED

#include <iostream>
#include <string>
#include <cmath>
#include <fstream>
#include <vector>
#include <windows.h>
#include <ctime>
#include <cstdlib>
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_mixer.h>

class Block;
class Monster;

using namespace std;

//screen constants
const int SCREEN_WIDTH = 1280;
const int SCREEN_HEIGHT = 768;
const int MAX_FRAMES = 120;
const int FRAME_DELAY = 1000/MAX_FRAMES;

const int LEVEL_WIDTH =30*64;
const int LEVEL_HEIGHT =12*64;

const int GRAVITY = 2000;

//sdl stuff
extern SDL_Window* gWindow;
extern SDL_Renderer* gRenderer;
extern SDL_Rect camera;

enum state{
    STANDING,
    FALLING,
    MOVING,
    RUNNING,
    JUMPING,
};

//sdl funtions
bool init();
bool loadMedia();
void close();
bool checkCollision(SDL_Rect a, SDL_Rect b);
bool touchesWall(SDL_Rect box, vector <Block> tiles, int &wichTile);
bool touchesMonster(SDL_Rect box,vector <Monster> monsters, int &whichMonster);
bool setTiles(vector <Block> tiles);
int getTotalTiles();
void saveTiles(vector <Block> tiles);
void setCamera(int x, int y);


#endif // API_H_INCLUDED
