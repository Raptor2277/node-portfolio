#ifndef MONSTER_H
#define MONSTER_H
#include "API.h"
#include "Block.h"
#include "Texture.h"
#include "Player.h"

extern Texture monsterTexture;
extern Texture projectileTexture;
class Monster
{
    public:
        Monster(int x, int y, float w, float h, float vel, float xVel, float yVel);
        ~Monster();
        //void handleEvent(SDL_Event &e);
        void action(Player player1);
        void move(vector <Block> tiles , float timeStep);
        void render();

        void setSprite();

        SDL_Rect getColBox() {return colBox;}
        int getxPos() {return xPos;}
        int getyPos() {return yPos;}
        int getWidth() {return width;}
        int getHeight() {return height;}
        bool destroy;

    protected:
        int width;
        int height;
        float xPos;
        float yPos;
        float velocity;
        float xVel;
        float yVel;
        int currentSprite;
        int state;
        bool jumpedOnce;
        SDL_Rect colBox;

        SDL_RendererFlip flip;
        SDL_Rect sprites[3];

    private:
};

#endif // MONSTER_H
