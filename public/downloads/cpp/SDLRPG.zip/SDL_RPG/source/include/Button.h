#ifndef BUTTON_H
#define BUTTON_H

#include "Texture.h"
#include "API.h"

extern Texture gButtonTexture;

class Button
{
    public:
        Button(int id, int x, int y ,int w, int h);
        virtual ~Button();
        
        void setSprite();
        void handleEvent( SDL_Event *e , int *id);
        void render();
    protected:
        int xPos;
        int yPos;
        int width;
        int height;
        int ID;
        
        bool buttonDown;
        
        SDL_Rect sprites[3];
    private:
};

#endif // BUTTON_H
