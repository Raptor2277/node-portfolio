#ifndef PROJECTILE_H
#define PROJECTILE_H

#include "API.h"
#include "Block.h"
#include "Texture.h"
#include "Player.h"
#include "Monster.h"

extern Texture projectileTexture;

class Projectile
{
    public:

        Projectile(int x, int y, float w, float h, float vel, float xVel, float yVel);
        ~Projectile();
        //void handleEvent(SDL_Event &e);

        void move(vector <Block> tiles, float timeStep);
        void render();

        void setSprite();

        SDL_Rect getColBox() {return colBox;}
        int getxPos() {return xPos;}
        int getyPos() {return yPos;}
        int getWidth() {return width;}
        int getHeight() {return height;}
        bool destroy;

    protected:
        int width;
        int height;
        float xPos;
        float yPos;
        float velocity;
        float xVel;
        float yVel;
        int currentSprite;
        SDL_Rect colBox;
        SDL_RendererFlip flip;

        SDL_Rect sprites[3];

    private:
};

#endif // PROJECTILE_H
