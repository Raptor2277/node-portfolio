#ifndef TIMER_H
#define TIMER_H

#include "API.h"

class Timer
{
    public:
        Timer();
        
        void start();
        void stop();
        void pause();
        void unpause();
        
        Uint32 getTicks();
        
        bool isPaused() {return started && paused;}
        bool isStarted() {return started;}
    private:
        
        Uint32 startTicks;
        Uint32 pausedTicks;
        
        bool paused;
        bool started;
};

#endif // TIMER_H
