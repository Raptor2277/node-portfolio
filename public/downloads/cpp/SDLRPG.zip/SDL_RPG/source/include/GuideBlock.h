#ifndef GUIDEBLOCK_H
#define GUIDEBLOCK_H

#include <Block.h>

extern Texture gGuideBlockTexture;

class GuideBlock : public Block
{
    public:
        GuideBlock(int tileType, int x, int y, int w, int h);
        ~GuideBlock();
        
        void render();
    protected:
    private:
};

#endif // GUIDEBLOCK_H
