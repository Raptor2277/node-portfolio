#ifndef PLAYER_H
#define PLAYER_H
#include "API.h"
#include "Texture.h"
#include "Block.h"

extern Texture playerTexture;

class Player
{
    public:

        static const float velocity = 180;

        Player(int x, int y, int w, int h);
        ~Player();
        void handleEvent(SDL_Event &e);
        void move(vector <Block> tiles, float timeStep);
        void render();
        void setSprite();
        SDL_Rect getColBox() {return colBox;}

        int getxPos() {return xPos;}
        int getyPos() {return yPos;}
        int getWidth() {return width;}
        int getHeight() {return height;}

    protected:
        int width;
        int height;
        float xPos;
        float yPos;
        float xVel;
        float yVel;
        int currentSprite;
        int state;
        bool jumpedOnce;
        int angle;

        SDL_Rect colBox;
        SDL_RendererFlip flip;
        SDL_Rect sprites[3];

    private:
};

#endif // PLAYER_H
