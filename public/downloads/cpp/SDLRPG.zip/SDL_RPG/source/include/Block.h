#ifndef BLOCK_H
#define BLOCK_H

#include "API.h"
#include "Texture.h"

extern Texture gBlockTexture;

class Block
{
    public:
        Block();
        Block(int tileType, int x, int y, int w, int h);
        ~Block();
        
        void render();
        SDL_Rect getColBox() {return colBox;}
        
        void setPos(int x, int y) {xPos=x; yPos=y;}
        void setID(int id) {ID=id; setSprite();}
        void setSprite();
        void setColBox();
        
        int getID() {return ID;}
        int getxPos() {return xPos;}
        int getyPos() {return yPos;}
        int getWidth() {return width;}
        int getHeight() {return height;}
        
        SDL_Rect colBox;
    protected:
        
        int xPos;
        int yPos;
        int width;
        int height;
        int ID;
        int currentSprite;
        SDL_Rect sprites[3];
    private:
};

#endif // BLOCK_H
