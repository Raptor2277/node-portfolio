#include <iostream>
#include <string>
#include <ctime>
#include <cstdio>
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_mixer.h>

using namespace std;

//screen constants
const int WINDOW_WIDTH = 580;
const int WINDOW_HEIGHT = 680;

//button constants
const int BUTTON_WIDTH =180;
const int BUTTON_HEIGHT = 180;
const int BUTTON_TOTAL = 9;

const int EMPTY_ID = 0;
const int X_ID = 3;
const int O_ID = 4;

//--------temporary----
int whosTurn = 1;
int turn =1;
int logicBoard[9] = {0};

enum buttonSprite
{
    BUTTON_SPRITE_MOUSE_OUT,
    BUTTON_SPRITE_MOUSE_IN,
    BUTTON_SPRITE_MOUSE_DOWN,
    BUTTON_SPRITE_MOUSE_OUT_X,
    BUTTON_SPRITE_MOUSE_IN_X,
    BUTTON_SPRITE_MOUSE_DOWN_X,
    BUTTON_SPRITE_MOUSE_OUT_O,
    BUTTON_SPRITE_MOUSE_IN_O,
    BUTTON_SPRITE_MOUSE_DOWN_O,
    BUTTON_SPRITE_TOTAL
};

enum MenuButtonSprite
{
    MENU_BUTTON_OUT,
    MENU_BUTTON_IN,
    MENU_BUTTON_DOWN,
    MENU_BUTTON_TOTAL
};

enum IDS
{
    PVP,
    PVE,
    EXIT,
    RESTART,
    MAIN_MENU
};


class Texture
{
    public:

        Texture();

        ~Texture();

        bool loadFromFile (string path);

        void free();

        void render(int x, int y, SDL_Rect* clip = NULL);

        int getWidth() {return width;}
        int getHeight() {return height;}

    private:
        SDL_Texture* texture;

        int width;
        int height;
};

class Button
{
    public:

        Button();

        void setPosition( int x, int y);

        void handleEvent( SDL_Event* e );

        void render();

        void setPiece();

        int getCurrentPiece() {return currentPiece;}

        void setCurrentPice(int id) {currentPiece=id;}

        void setCurrentSprite(int id) {currentSprite=id;}

    protected:
        SDL_Point position;

        int currentSprite;

        int currentPiece;

        bool buttonDown=false;
};

class MenuButton : public Button
{
    public:

        MenuButton();

        void handleEvent( SDL_Event* e, bool &quit, int &mode );

        void render();

        void setSprite(int sp, int x, int y, int w, int h);

        void setID(int id) {ID=id;};

    protected:
        SDL_Rect sprite[3];
        int buttonWidth;
        int buttonHeight;
        int ID;
};

//game funtions
void updateLogicBoard();
void reset();
int menuScreen();
bool checkWinCondition();
void computerTurn();

//sdl stuff
SDL_Window* gWindow = NULL;
SDL_Renderer* gRenderer = NULL;

bool init();
bool loadMedia();
void close();

SDL_Rect spriteClips[BUTTON_SPRITE_TOTAL];
SDL_Rect backGround = {0,0,WINDOW_WIDTH,WINDOW_HEIGHT-100};

Texture gButtonTexture;
Texture gMenuButtonTexture;

Texture gBackGroundTexture;
Texture gMenuBackGroundTexture;

Texture gWinTexture;


Mix_Chunk* gClickChunk = NULL;


Button gButton[BUTTON_TOTAL];

MenuButton pvp;
MenuButton pve;
MenuButton exit_game;
MenuButton restart;
MenuButton mainMenu;
MenuButton lol;

SDL_Rect winButton;

string winner;
bool winnerExists = false;

//main
int main(int argc, char** argv)
{
    if(!init()){
        cout<<"Could not init\n";
    } else if (!loadMedia()){
        cout<<"Could not load media\n";
    } else
    {
        //-----------------IF INIT----------------


        srand(time(NULL));
        bool quit = false;

        SDL_Event e;MenuButton lol;

        int mode = menuScreen();
        cout<<mode;
        if(mode == -1)
            quit=true;
        //-----------------Main LOOP---------------
        while(!quit)
        {
            if(mode == -1)
                break;

            //computer
            if(mode==PVE && whosTurn==1 && !winnerExists)
            {
                computerTurn();
            }


            while(SDL_PollEvent(&e) != 0)
            {
                if(e.type == SDL_QUIT)
                {
                   quit = true;
                }

                if(e.type == SDL_KEYDOWN)
                {
                    switch(e.key.keysym.sym)
                    {
                        case SDLK_r:
                            reset();
                            break;
                    }
                }

                if(!winnerExists)
                {
                    for (int i=0; i<BUTTON_TOTAL; i++)
                    {
                        gButton[i].handleEvent(&e);
                    }
                }

                restart.handleEvent(&e, quit, mode);
                mainMenu.handleEvent(&e, quit, mode);
            }

            //------draw---
            SDL_SetRenderDrawColor(gRenderer,255,255,255,255);
            SDL_RenderClear(gRenderer);

            gBackGroundTexture.render(0,0,&backGround);

            for (int i=0; i<BUTTON_TOTAL; i++)
            {
                gButton[i].render();
            }

            restart.render();
            mainMenu.render();

            if (checkWinCondition())
            {
                if ( winner == "draw")
                {
                    gWinTexture.loadFromFile("data/draw.png");
                    gWinTexture.render(100,100, &winButton );
                    winnerExists=true;
                } else if (winner == "X")
                {
                    if(mode == PVE)
                    {
                        gWinTexture.loadFromFile("data/computer.png");
                        gWinTexture.render(100, 100, &winButton);
                        winnerExists=true;
                    }
                    else
                    {
                        gWinTexture.loadFromFile("data/player1.png");
                        gWinTexture.render(100, 100, &winButton);
                        winnerExists=true;
                    }
                    
                } else if (winner == "O")
                {
                    gWinTexture.loadFromFile("data/player2.png");
                    gWinTexture.render(100, 100, &winButton);
                    winnerExists=true;
                }
            }


            SDL_RenderPresent( gRenderer);
        }
    }

    close();
    return 0;
}

bool loadMedia()
{
    bool success = true;

    gButtonTexture.loadFromFile("data/texture.png");
    gBackGroundTexture.loadFromFile("data/backGround.png");
    gMenuButtonTexture.loadFromFile("data/menu.png");
    gMenuBackGroundTexture.loadFromFile("data/mainMenu.png");
    
    gClickChunk = Mix_LoadWAV("data/mouseover.wav");

    int y=0;
    int x=0;
    for(int i = 0; i<BUTTON_SPRITE_TOTAL; i++)
    {
        if(i%3==0 && i!=0)
        {
            y+=BUTTON_HEIGHT;
            x=0;
        }
        spriteClips[i].x =x;
        spriteClips[i].y =y;
        spriteClips[i].w =BUTTON_WIDTH;
        spriteClips[i].h =BUTTON_HEIGHT;
        x+=BUTTON_WIDTH;
    }

    winButton.x=0;
    winButton.y=0;
    winButton.w=360;
    winButton.h=180;

    gButton[0].setPosition(0, 0);
    gButton[1].setPosition(200, 0);
    gButton[2].setPosition(400, 0);
    gButton[3].setPosition(0, 200);
    gButton[4].setPosition(200, 200);
    gButton[5].setPosition(400, 200);
    gButton[6].setPosition(0, 400);
    gButton[7].setPosition(200, 400);
    gButton[8].setPosition(400, 400);

    //-------------menubuttons------------

    pvp.setPosition(200,350);
    pvp.setID(PVP);
    pvp.setSprite(MENU_BUTTON_OUT, 0,0, 180, 60);
    pvp.setSprite(MENU_BUTTON_IN, 180,0, 180, 60);
    pvp.setSprite(MENU_BUTTON_DOWN, 360, 0, 180, 60);
    pve.setPosition(200,450);
    pve.setID(PVE);
    pve.setSprite(MENU_BUTTON_OUT, 0,60, 180, 60);
    pve.setSprite(MENU_BUTTON_IN, 180,60, 180, 60);
    pve.setSprite(MENU_BUTTON_DOWN, 360, 60, 180, 60);
    exit_game.setPosition(200,550);
    exit_game.setID(EXIT);
    exit_game.setSprite(MENU_BUTTON_OUT, 0,120, 180, 60);
    exit_game.setSprite(MENU_BUTTON_IN, 180,120, 180, 60);
    exit_game.setSprite(MENU_BUTTON_DOWN, 360, 120, 180, 60);

    //----for main loop---------
    restart.setPosition(100,600);
    restart.setID(RESTART);
    restart.setSprite(MENU_BUTTON_OUT, 0,180, 180, 60);
    restart.setSprite(MENU_BUTTON_IN, 180,180, 180, 60);
    restart.setSprite(MENU_BUTTON_DOWN, 360, 180, 180, 60);
    mainMenu.setPosition(300,600);
    mainMenu.setID(MAIN_MENU);
    mainMenu.setSprite(MENU_BUTTON_OUT, 0,240, 180, 60);
    mainMenu.setSprite(MENU_BUTTON_IN, 180,240, 180, 60);
    mainMenu.setSprite(MENU_BUTTON_DOWN, 360, 240, 180, 60);

    lol.setPosition(300,600);
    lol.setID(MAIN_MENU);
    lol.setSprite(MENU_BUTTON_OUT, 0,240, 180, 60);
    lol.setSprite(MENU_BUTTON_IN, 180,240, 180, 60);
    lol.setSprite(MENU_BUTTON_DOWN, 360, 240, 180, 60);

    return success;
}

Texture::Texture()
{
    texture = NULL;
    width = 0;
    height = 0;
}

Texture::~Texture()
{
    free();
}

bool Texture::loadFromFile( string path )
{
    bool success=true;
    free();

    SDL_Texture* newTexture = NULL;
    SDL_Surface* loadedSurface = IMG_Load( path.c_str());
    if(loadedSurface == NULL)
    {
        cout<<IMG_GetError()<<endl;
        success=false;
    }
    else
    {
        //set color key
        SDL_SetColorKey( loadedSurface, SDL_TRUE, SDL_MapRGB( loadedSurface->format, 0, 255,255));
        newTexture = SDL_CreateTextureFromSurface( gRenderer, loadedSurface);
        if(newTexture == NULL)
        {
            cout<<SDL_GetError()<<endl;
            success=false;
        }
        else
        {
            width = loadedSurface->w;
            height = loadedSurface->h;
        }
        SDL_FreeSurface( loadedSurface );
    }

    texture = newTexture;
    return success;
}

void Texture::free()
{
    if (texture != NULL)
    {
        SDL_DestroyTexture( texture );
        texture = NULL;
        width=0;
        height=0;
    }
}

void Texture::render(int x, int y, SDL_Rect* clip)
{
    SDL_Rect renderQuad = {x, y, width, height };

    if(clip != NULL)
    {
        renderQuad.h=clip->h;
        renderQuad.w=clip->w;
    }

    SDL_RenderCopy( gRenderer, texture, clip, &renderQuad);
}

Button::Button()
{
    position.x = 0;
    position.y = 0;

    currentPiece = EMPTY_ID;
    currentSprite = BUTTON_SPRITE_MOUSE_OUT;
}

void Button::setPosition(int x, int y)
{
    position.y = y;
    position.x = x;
}

void Button::render()
{
    gButtonTexture.render(position.x, position.y, &spriteClips[currentSprite]);
}

void Button::handleEvent(SDL_Event* e)
{
    int x, y;
    SDL_GetMouseState( &x, &y);
    bool inside = true;

    if(x < position.x)
        inside=false;
    else if (x > position.x + BUTTON_WIDTH)
        inside=false;
    else if (y > position.y + BUTTON_HEIGHT)
        inside=false;
    else if (y < position.y)
        inside=false;

    if(!inside)
    {
        if(currentPiece == EMPTY_ID)
            currentSprite=BUTTON_SPRITE_MOUSE_OUT;
        else if(currentPiece == X_ID)
            currentSprite=BUTTON_SPRITE_MOUSE_OUT_X;
        else if(currentPiece == O_ID)
            currentSprite=BUTTON_SPRITE_MOUSE_OUT_O;
    }
    else
    {
        switch( e->type )
        {
            case SDL_MOUSEMOTION:
                if(currentPiece == EMPTY_ID)
                    currentSprite=BUTTON_SPRITE_MOUSE_IN;
                else if(currentPiece == X_ID)
                    currentSprite=BUTTON_SPRITE_MOUSE_IN_X;
                else if(currentPiece == O_ID)
                    currentSprite=BUTTON_SPRITE_MOUSE_IN_O;
                    
                break;

            case SDL_MOUSEBUTTONDOWN:

                if(currentPiece == EMPTY_ID)
                    currentSprite=BUTTON_SPRITE_MOUSE_DOWN;
                else if(currentPiece == X_ID)
                    currentSprite=BUTTON_SPRITE_MOUSE_DOWN_X;
                else if(currentPiece == O_ID)
                    currentSprite=BUTTON_SPRITE_MOUSE_DOWN_O;
                Mix_PlayChannel(-1, gClickChunk, 0);
                buttonDown=true;
                break;

            case SDL_MOUSEBUTTONUP:
                if(buttonDown)
                {
                    setPiece();

                    if(currentPiece == EMPTY_ID)
                        currentSprite=BUTTON_SPRITE_MOUSE_IN;
                    else if(currentPiece == X_ID)
                        currentSprite=BUTTON_SPRITE_MOUSE_IN_X;
                    else if(currentPiece == O_ID)
                        currentSprite=BUTTON_SPRITE_MOUSE_IN_O;
                    buttonDown=false;
                break;
                }
        }
    }
}

void Button::setPiece()
{
    if(currentPiece == EMPTY_ID)
    {
        if (whosTurn == 1)
            currentPiece=X_ID;
        else if (whosTurn == 2)
            currentPiece=O_ID;
        turn++;

        if (whosTurn == 1)
            whosTurn=2;
        else if (whosTurn == 2)
            whosTurn=1;
    }
    
    updateLogicBoard();
    
}

//------------------------------MenuButton-------------------

MenuButton::MenuButton()
{
    position.x = 30;
    position.y = 30;

    buttonWidth=180;
    buttonHeight=60;

    ID=0;

    currentSprite= MENU_BUTTON_OUT;
}

void MenuButton::setSprite(int sp, int x, int y, int w, int h)
{
    sprite[sp].y=y;
    sprite[sp].x=x;
    sprite[sp].w=w;
    sprite[sp].h=h;
}
void MenuButton::render()
{
    gMenuButtonTexture.render(position.x, position.y, &sprite[currentSprite]);
}

void MenuButton::handleEvent(SDL_Event* e, bool &quit, int &mode)
{
    int x, y;
    SDL_GetMouseState( &x, &y);
    bool inside = true;

    if(x < position.x)
        inside=false;
    else if (x > position.x + buttonWidth)
        inside=false;
    else if (y > position.y + buttonHeight)
        inside=false;
    else if (y < position.y)
        inside=false;

    if(!inside)
    {
        currentSprite=MENU_BUTTON_OUT;
    }
    else
    {
        switch( e->type )
        {
            case SDL_MOUSEMOTION:
                if(!buttonDown)
                    currentSprite=MENU_BUTTON_IN;
                break;

            case SDL_MOUSEBUTTONDOWN:
                currentSprite=MENU_BUTTON_DOWN;
                buttonDown=true;
                Mix_PlayChannel(-1, gClickChunk, 0);
                break;

            case SDL_MOUSEBUTTONUP:
                if(buttonDown)
                {
                    currentSprite=MENU_BUTTON_IN;
                    switch(ID)
                    {
                        case PVP:
                            mode=PVP;
                            quit=true;
                            break;

                        case PVE:
                            mode=PVE;
                            quit=true;
                            break;

                        case EXIT:
                            mode=-1;
                            quit=true;
                            break;

                        case RESTART:
                            reset();
                            break;

                        case MAIN_MENU:
                            reset();
                            mode=menuScreen();
                            break;
                    }
                    buttonDown=false;
                }
                break;
        }
    }

}

//-----------------game functions--------------------


void reset()
{
    for(int i=0; i<BUTTON_TOTAL; i++)
    {
        gButton[i].setCurrentPice(EMPTY_ID);
        gButton[i].setCurrentSprite(BUTTON_SPRITE_MOUSE_OUT);
    }

    turn=1;
    updateLogicBoard();

    winnerExists=false;
    winner="";
    whosTurn=1;
}

bool init()
{
    //init video
    bool success = true;
    if(SDL_Init( SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0){
        cout<<SDL_GetError()<<endl;
        success = false;
    }

    //createwindow
    gWindow = SDL_CreateWindow( "Title", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WINDOW_WIDTH, WINDOW_HEIGHT, SDL_WINDOW_SHOWN);
    if(gWindow == NULL)
    {
        cout<<SDL_GetError()<<endl;
        success = false;
    }

    //linear texture filtering
    if(!SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1"))
    {
        cout<<"Liner texture filtering not enabled";
    }

    //create the renderer
    gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if(gRenderer==NULL)
    {
        cout<<SDL_GetError()<<endl;
        success = false;
    }
    SDL_SetRenderDrawColor(gRenderer, 255, 255, 255, 255);

    //init PNG loading
    int imgFlags = IMG_INIT_PNG;
    if( !( IMG_Init(imgFlags) & imgFlags) )
    {
        cout<<IMG_GetError()<<endl;
        success=false;
    }
    
    if( Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 2, 2048 ) < 0 )
    {
        Mix_GetError();
        success=false;
    }
    
    return success;
}

void close()
{
    gButtonTexture.free();
    gMenuButtonTexture.free();
    gBackGroundTexture.free();
    gMenuBackGroundTexture.free();
    gWinTexture.free();
    
    Mix_FreeChunk(gClickChunk);

    SDL_DestroyWindow( gWindow);
    gWindow = NULL;

    SDL_DestroyRenderer(gRenderer);
    gRenderer= NULL;

    SDL_Quit();
    IMG_Quit();
    Mix_Quit();
}

int menuScreen()
{
    bool quit= false;
    int mode;
    SDL_Event e;
    SDL_Rect menuBackground = {0,0, 580, 680};
    //-----------------Main LOOP---------------
    while(!quit)
    {
        while(SDL_PollEvent(&e) != 0)
        {
            if(e.type == SDL_QUIT)
            {
               quit = true;
               mode = -1;
            }

            pvp.handleEvent(&e, quit, mode);
            pve.handleEvent(&e, quit, mode);
            exit_game.handleEvent(&e, quit, mode);

        }

        //------draw-------
        SDL_SetRenderDrawColor(gRenderer,255,255,255,255);
        SDL_RenderClear(gRenderer);
        gMenuBackGroundTexture.render(0,0,&menuBackground);

        pvp.render();
        pve.render();
        exit_game.render();

        SDL_RenderPresent( gRenderer);
    }
    return mode;
}

bool checkWinCondition()
{
    bool winnerExists= false;

    if(turn == 10)
    {
        winner="draw";
        winnerExists=true;
    }

    //-----------------------------x-------------------------
    //---------------------across----------------
    for (int i=0; i<9; i+=3)
    {
        if(logicBoard[i] + logicBoard[i+1] + logicBoard[i+2] == 9)
        {
            winner="X";
            winnerExists=true;
        }
    }

    //---down
    for (int i=0; i<3; i++)
    {
        if (logicBoard[i] + logicBoard[i+3] + logicBoard[i+6] == 9)
        {
            winner="X";
            winnerExists=true;
        }
    }

    //diagonal 1
    if (logicBoard[0] + logicBoard[4] + logicBoard[8] == 9)
    {
        winner="X";
        winnerExists=true;
    }

    //diagonal 2
    if (logicBoard[2] + logicBoard[4] + logicBoard[6] == 9)
    {
        winner="X";
        winnerExists=true;
    }

    //---------------------------------O----------------------
    //across
    for (int i=0; i<9; i+=3)
    {
        if(logicBoard[i] + logicBoard[i+1] + logicBoard[i+2] == 12)
        {
            winner="O";
            winnerExists=true;
        }
    }

    //down
    for (int i=0; i<3; i++)
    {
        if (logicBoard[i] + logicBoard[i+3] + logicBoard[i+6] == 12)
        {
            winner="O";
            winnerExists=true;
        }
    }

    //diagonal 1
    if (logicBoard[0] + logicBoard[4] + logicBoard[8] == 12)
    {
        winner="O";
        winnerExists=true;
    }

    //diagonal 2
    if (logicBoard[2] + logicBoard[4] + logicBoard[6] == 12)
    {
        winner="O";
        winnerExists=true;
    }

    return winnerExists;
}

void computerTurn()
{
    //random move
    int availableMoves[9] = {0};
    int counter=0;
    int bestMove;
    int randomNumber;

    for (int i=0; i<9; i++)
    {
        if(logicBoard[i] == 0)
        {
            availableMoves[counter]=i;
            counter++;
        }
    }

    randomNumber=rand()%counter;
    bestMove=availableMoves[randomNumber];

    //counter win
    //across
    for (int i=0; i<9; i+=3)
    {
        if(logicBoard[i] + logicBoard[i+1] + logicBoard[i+2] == 8)
        {
            for (int n=i; n<=i+2; n++)
            {
                if(logicBoard[n] == 0)
                {
                    bestMove=n;
                }
            }
        }
    }

    //down
    for (int i=0; i<3; i++)
    {
        if (logicBoard[i] + logicBoard[i+3] + logicBoard[i+6] == 8)
        {
            for (int n=i; n<=i+6; n+=3)
            {
                if(logicBoard[n] == 0)
                {
                    bestMove=n;
                }
            }
        }
    }

    //diagonal 1
    if (logicBoard[0] + logicBoard[4] + logicBoard[8] == 8)
    {
        for (int n=0; n<=8; n+=4)
            {
                if(logicBoard[n] == 0)
                {
                    bestMove=n;
                }
            }
    }

    //diagonal 2
    if (logicBoard[2] + logicBoard[4] + logicBoard[6] == 8)
    {
        for (int n=2; n<=6; n+=2)
            {
                if(logicBoard[n] == 0)
                {
                    bestMove=n;
                }
            }
    }


    //try to win
    //across
    for (int i=0; i<9; i+=3)
    {
        if(logicBoard[i] + logicBoard[i+1] + logicBoard[i+2] == 6)
        {
            for (int n=i; n<=i+2; n++)
            {
                if(logicBoard[n] == 0)
                {
                    bestMove=n;
                }
            }
        }
    }

    //down
    for (int i=0; i<3; i++)
    {
        if (logicBoard[i] + logicBoard[i+3] + logicBoard[i+6] == 6)
        {
            for (int n=i; n<=i+6; n+=3)
            {
                if(logicBoard[n] == 0)
                {
                    bestMove=n;
                }
            }
        }
    }

    //diagonal 1
    if (logicBoard[0] + logicBoard[4] + logicBoard[8] == 6)
    {
        for (int n=0; n<=8; n+=4)
            {
                if(logicBoard[n] == 0)
                {
                    bestMove=n;
                }
            }
    }

    //diagonal 2
    if (logicBoard[2] + logicBoard[4] + logicBoard[6] == 6)
    {
        for (int n=2; n<=6; n+=2)
            {
                if(logicBoard[n] == 0)
                {
                    bestMove=n;
                }
            }
    }

    //set the piece
    gButton[bestMove].setPiece();
    gButton[bestMove].setCurrentSprite(BUTTON_SPRITE_MOUSE_OUT_X);
}

void updateLogicBoard()
{
    for(int i=0; i<BUTTON_TOTAL; i++)
    {
        logicBoard[i]=gButton[i].getCurrentPiece();
    }
}
