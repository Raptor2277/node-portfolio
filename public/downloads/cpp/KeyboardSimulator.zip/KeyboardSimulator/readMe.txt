[executable]
	./Input

[input file]
	./input.txt

[instructions]
	This application will simulate keyboard keypresses (with a delay).
	Simply put the text in [input.txt] or copy text from a source.
	Using [F2] or [F4] will start the typing process.
	Be careful what window you have focused.