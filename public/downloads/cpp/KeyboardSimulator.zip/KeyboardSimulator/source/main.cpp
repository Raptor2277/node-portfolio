#define WINVER 0x0500
#include <windows.h>
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

enum keys
{
    //keys and modifiers
    enter=13,
    shift=16,
    control=17,
    space=32,

    //numbers
    zero=48,
    one,
    two,
    three,
    four,
    five,
    six,
    seven,
    eight,
    nine,


    //letters
    a=65,
    b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,

    //quotes, underskores, etc
    semicolon=186,
    equals,
    comma,
    dash,
    period,
    forwardSlash,
    tilda,
    bracketOpen=219,
    backwardSlash,
    bracketClose,
    singleQuote,
};

void keyType(char arr, int& key, int& mod);

void pressKey(int input);
void pressKey(int input, int mod);

void readTheFile(string input);

void type(char* arr);

void toClipboard(const string &s);

void reset();

//the input object
INPUT ip;
HANDLE clip;
string clip_text = "";
int afterEnter = period;
bool doAfterEnter = false;

//the fstream object witht the array to hold the data
fstream inputFile;
char arr[1000000];
int index=0;

//delay when between each keypress
int delay=50;

int main()
{
    // This structure will be used to create the keyboard
    // input event.
    ip.type = INPUT_KEYBOARD;
    ip.ki.wScan = 0; // hardware scan code for key
    ip.ki.time = 0;
    ip.ki.dwExtraInfo = 0;

    //lel
    inputFile >> noskipws;
    string prompt="F2: type from input.txt, F4: type from windows clipboard\n\nF8: stop typing, F9 close the console\n\nUse UP and DOWN to change the delay\n\nDelay: ";
    cout<<prompt<<delay<<endl;

    while(!GetAsyncKeyState(VK_F9))
    {
        if(GetAsyncKeyState(VK_F2))
        {
            reset();
            readTheFile("input.txt");
            type(arr);
        }
        else if ( GetAsyncKeyState(VK_F4))
        {
            //get data
            if (OpenClipboard(NULL))
            {
                clip = GetClipboardData(CF_TEXT);
                clip_text = (char*)clip;
                CloseClipboard();
            }

            int TempNumOne=clip_text.size();
            for (int a=0;a<=TempNumOne;a++)
            {
                arr[a]=clip_text[a];
            }

            type(arr);
        }
        else if (GetAsyncKeyState(VK_UP))
        {
            delay++;
            system("CLS");
            cout<<prompt<<delay<<endl;
        }else if (GetAsyncKeyState(VK_DOWN))
        {
            if(delay > 0 )
                delay--;
            system("CLS");
            cout<<prompt<<delay<<endl;
        }
    }

    // Exit normally
    return 0;
}

void pressKey(int input)
{
    ip.ki.wVk = input; // virtual-key code for the key
    ip.ki.dwFlags = 0; // 0 for key press
    SendInput(1, &ip, sizeof(INPUT));

    Sleep(delay);

    // Release the key
    ip.ki.dwFlags = KEYEVENTF_KEYUP; // KEYEVENTF_KEYUP for key release
    SendInput(1, &ip, sizeof(INPUT));
}

void pressKey(int input, int mod)
{
    ip.ki.wVk = input; // virtual-key code for the key
    ip.ki.dwFlags = 0; // 0 for key press
    SendInput(1, &ip, sizeof(INPUT));

    ip.ki.wVk = mod; // virtual-key code for the key
    ip.ki.dwFlags = 0; // 0 for key press
    SendInput(1, &ip, sizeof(INPUT));

    // Release the key
    ip.ki.wVk = input;
    ip.ki.dwFlags = KEYEVENTF_KEYUP; // KEYEVENTF_KEYUP for key release
    SendInput(1, &ip, sizeof(INPUT));

    ip.ki.wVk = mod;
    ip.ki.dwFlags = KEYEVENTF_KEYUP; // KEYEVENTF_KEYUP for key release
    SendInput(1, &ip, sizeof(INPUT));

    Sleep(delay);
}

void type(char* arr)
{
    int key=0;
    int mod=0;
    int length = strlen( arr);

    for (int i=0; i<length; i++)
    {
        bool newLine = false;

        if(GetAsyncKeyState(VK_F8))
        {
            break;
        }

        keyType(arr[i],key,mod);

        if(key == enter)
            newLine=true;

        if(mod != 0)
        {
            //press the mod------------------------------------------
            ip.ki.wVk = mod; // virtual-key code for the key
            ip.ki.dwFlags = 0; // 0 for key press
            SendInput(1, &ip, sizeof(INPUT));
        }

        //keypress------------------------------------------------------
        ip.ki.wVk = key; // virtual-key code for the key
        ip.ki.dwFlags = 0; // 0 for key press
        SendInput(1, &ip, sizeof(INPUT));

        // Release the key
        ip.ki.wVk = key; //<---uneeded but shows how it works
        ip.ki.dwFlags = KEYEVENTF_KEYUP; // KEYEVENTF_KEYUP for key release
        SendInput(1, &ip, sizeof(INPUT));
        //keyrelease----------------------------------------------------

        if(mod != 0)
        {
            ip.ki.wVk = mod;
            ip.ki.dwFlags = KEYEVENTF_KEYUP; // KEYEVENTF_KEYUP for key release
            SendInput(1, &ip, sizeof(INPUT));
        }

        if(doAfterEnter && newLine)
        {
            pressKey(afterEnter);
            newLine=false;
        }

        mod=0;
        Sleep(delay);

    }

}

void reset()
{
    int arrSize = strlen(arr);
    for(int i=0; i<arrSize; i++)
    {
        arr[i] = '\0';
    }
}

void readTheFile(string input)
{
    index=0;
    inputFile.open(input.c_str());
    if (inputFile.is_open())
    {
        while (inputFile>>arr[index])
        {
            index++;
        }
        inputFile.close();
    } else
        cout<<"Could not open file";

}

void keyType(char arr, int& key, int& mod)
{
    switch(arr)
    {
        case 'a'://lowercase letters---------------------------------------
            key=a;
            break;
        case 'b':
            key=b;
            break;
        case 'c':
            key=c;
            break;
        case 'd':
            key=d;
            break;
         case 'e':
            key=e;
            break;
        case 'f':
            key=f;
            break;
        case 'g':
            key=g;
            break;
         case 'h':
            key=h;
            break;
        case 'i':
            key=i;
            break;
        case 'j':
            key=j;
            break;
         case 'k':
            key=k;
            break;
        case 'l':
            key=l;
            break;
        case 'm':
            key=m;
            break;
         case 'n':
            key=n;
            break;
        case 'o':
            key=o;
            break;
        case 'p':
            key=p;
            break;
         case 'q':
            key=q;
            break;
        case 'r':
            key=r;
            break;
        case 's':
            key=s;
            break;
         case 't':
            key=t;
            break;
        case 'u':
            key=u;
            break;
        case 'v':
            key=v;
            break;
        case 'w':
            key=w;
            break;
        case 'x':
            key=x;
            break;
        case 'y':
            key=y;
            break;
        case 'z':
            key=z;
            break;


        case 'A':
            mod=shift;        //UPPERCASE LETTERS---------------------------------------
            key=a;
            break;
        case 'B':
            mod=shift;
            key=b;
            break;
        case 'C':
            mod=shift;
            key=c;
            break;
        case 'D':
            mod=shift;
            key=d;
            break;
        case 'E':
            mod=shift;
            key=e;
            break;
        case 'F':
            mod=shift;
            key=f;
            break;
        case 'G':
            mod=shift;
            key=g;
            break;
        case 'H':
            mod=shift;
            key=h;
            break;
        case 'I':
            mod=shift;
            key=i;
            break;
        case 'J':
            mod=shift;
            key=j;
            break;
        case 'K':
            mod=shift;
            key=k;
            break;
        case 'L':
            mod=shift;
            key=l;
            break;
        case 'M':
            mod=shift;
            key=m;
            break;
        case 'N':
            mod=shift;
            key=n;
            break;
        case 'O':
            mod=shift;
            key=o;
            break;
        case 'P':
            mod=shift;
            key=p;
            break;
        case 'Q':
            mod=shift;
            key=q;
            break;
        case 'R':
            mod=shift;
            key=r;
            break;
        case 'S':
            mod=shift;
            key=s;
            break;
        case 'T':
            mod=shift;
            key=t;
            break;
        case 'U':
            mod=shift;
            key=u;
            break;
        case 'V':
            mod=shift;
            key=v;
            break;
        case 'W':
            mod=shift;
            key=w;
            break;
        case 'X':
            mod=shift;
            key=x;
            break;
        case 'Y':
            mod=shift;
            key=y;
            break;
        case 'Z':
            mod=shift;
            key=z;
            break;

        case '0'://numbers----------------------------
            key=zero;
            break;
        case '1'://numbers----------------------------
            key=one;
            break;
        case '2'://numbers----------------------------
            key=two;
            break;
        case '3'://numbers----------------------------
            key=three;
            break;
        case '4'://numbers----------------------------
            key=four;
            break;
        case '5':
            key=five;
            break;
        case '6':
            key=six;
            break;
        case '7':
            key=seven;
            break;
        case '8':
            key=eight;
            break;
        case '9':
            key=nine;
            break;


        //others------------------------------
        case '\'':
            key=singleQuote;
            break;
        case ';':
            key=semicolon;
            break;
        case ' ':
            key=space;
            break;
        case '\n':
            key=enter;
            break;
        case '.':
            key=period;
            break;
        case ',':
            key=comma;
            break;
        case '=':
            key=equals;
            break;
        case '-':
            key=dash;
            break;
        case '/':
            key=forwardSlash;
            break;
        case '\\':
            key=backwardSlash;
            break;
        case '[':
            key=bracketOpen;
            break;
        case ']':
            key=bracketClose;
            break;

        //others with Shift
        case '_':
            key=dash;
            mod=shift;
            break;
        case '|':
            key=backwardSlash;
            mod=shift;
            break;
        case '!':
            key=one;
            mod=shift;
            break;
        case '&':
            key=seven;
            mod=shift;
            break;
        case '*':
            key=eight;
            mod=shift;
            break;
        case '(':
            key=nine;
            mod=shift;
            break;
        case ')':
            key=zero;
            mod=shift;
            break;
        case ':':
            key=semicolon;
            mod=shift;
            break;
        case '\"':
            key=singleQuote;
            mod=shift;
            break;
        case '<':
            key=comma;
            mod=shift;
            break;
        case '>':
            key=period;
            mod=shift;
            break;
        case '+':
            key=equals;
            mod=shift;
            break;
        case '{':
            key=bracketOpen;
            mod=shift;
            break;
        case '}':
            key=bracketClose;
            mod=shift;
            break;
        case '?':
            key=forwardSlash;
            mod=shift;
            break;
        /*case '':
            key=enter;
            break;*/
    }
}

void toClipboard(const string &s){
	OpenClipboard(0);
	EmptyClipboard();
	HGLOBAL hg=GlobalAlloc(GMEM_MOVEABLE,s.size());
	if (!hg){
		CloseClipboard();
		return;
	}
	memcpy(GlobalLock(hg),s.c_str(),s.size());
	GlobalUnlock(hg);
	SetClipboardData(CF_TEXT,hg);
	CloseClipboard();
	GlobalFree(hg);
}
