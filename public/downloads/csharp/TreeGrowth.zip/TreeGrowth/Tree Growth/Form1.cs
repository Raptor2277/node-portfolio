﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Tree_Growth
{
    public partial class Form1 : Form
    {
        private Random rand;
        private int iterations = 12;
        private int minAngle = 25;
        private int maxAngle = 25;
        private int startingLength = 60;
        private int lengthDecrement = 5;
        private bool parentAsBase = true;

        public Form1()
        {
            InitializeComponent();
            rand = new Random();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Refresh();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.DrawRectangle(Pens.Black, 0, 0, 699, 449);

            int length = startingLength;
            List<Branch> branches = new List<Branch>();
            branches.Add(new Branch(350, 400, 90, length, true, maxAngle, minAngle, lengthDecrement));

            for(int i=0; i<iterations; i++)
            {
                int max = branches.Count;
                for(int n=0; n<max; n++)
                {
                    if(!branches.ElementAt(n).hasBranches)
                    {
                        if (parentAsBase )
                        {
                            branches.Add(branches.ElementAt(n).getBranchLeft(rand, branches.ElementAt(n).angle));
                            branches.Add(branches.ElementAt(n).getBranchRight(rand, branches.ElementAt(n).angle));
                            branches.ElementAt(n).hasBranches = true;
                        }
                        else
                        {      
                            branches.Add(branches.ElementAt(n).getBranchLeft(rand));
                            branches.Add(branches.ElementAt(n).getBranchRight(rand));
                            branches.ElementAt(n).hasBranches = true;
                        }
                    }
                }
            }

            foreach(Branch b in branches)
            {
                b.draw(g);
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //starting length
            if (textBox2.Text != "")
            { 
                string text = textBox2.Text;
                int num;
                Int32.TryParse(text, out num);

                if (text != "" && isNumeric(text) && num > 0 && num < 1000)
                {
                    startingLength = num;
                }
                else
                {
                    startingLength = 60;
                    textBox2.Text = "60";
                }
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //length decrement
            if (textBox1.Text != "")
            {
                string text = textBox1.Text;
                int num; 
                Int32.TryParse(text, out num);

                if (text != "" && isNumeric(text) && num >= 0 && num < 100)
                {
                    lengthDecrement = num;
                }
                else
                {
                    lengthDecrement = 5;
                    textBox1.Text = "5";
                }
            }
        }

        private bool isNumeric(string s)
        {
            for (int i = 0; i < s.Length; i++)
            {
                if (!char.IsNumber(s[i]))
                {
                    return false;
                }

            }
            return true;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            //iterations
            if (textBox4.Text != "")
            {
                string text = textBox4.Text;
                int num;
                Int32.TryParse(text, out num);

                if (text != "" && isNumeric(text) && num > 0 && num < 21)
                {
                    iterations = num;
                }
                else
                {
                    lengthDecrement = 5;
                    textBox4.Text = "5";
                }
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            //min agngle
            if (textBox5.Text != "")
            {
                string text = textBox5.Text;
                int num;
                Int32.TryParse(text, out num);

                if (text != "" && isNumeric(text) && num >= 0 && num < 361)
                {
                    minAngle = num;
                }
                else
                {
                    lengthDecrement = 0;
                    textBox5.Text = "0";
                }
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            //max angle
            if (textBox3.Text != "")
            {
                string text = textBox3.Text;
                int num;
                Int32.TryParse(text, out num);

                if (text != "" && isNumeric(text) && num >= 0 && num < 361)
                {
                    maxAngle = num;
                }
                else
                {
                    lengthDecrement = 90;
                    textBox3.Text = "90";
                }
            }
        }

        private void minus_Click(object sender, EventArgs e)
        {
            switch (((Button)sender).Name)
            {
                case "button2":
                    //
                    break;

            }
        }

        private void minus2_MouseClick(object sender, MouseEventArgs e)
        {
            string name = ((Button)sender).Name;
            if (name.Substring(0, 1).Equals("m"))
            {
                switch (name.Substring(5, 1))
                {
                    case "1":
                        textBox1.Text = (Int32.Parse(textBox1.Text) - 1).ToString();
                        break;
                    case "2":
                        textBox2.Text = (Int32.Parse(textBox2.Text) - 1).ToString();
                        break;
                    case "3":
                        textBox3.Text = (Int32.Parse(textBox3.Text) - 1).ToString();
                        break;
                    case "4":
                        textBox4.Text = (Int32.Parse(textBox4.Text) - 1).ToString();
                        break;
                    case "5":
                        textBox5.Text = (Int32.Parse(textBox5.Text) - 1).ToString();
                        break;
                }
            }
            else
            {
                switch (name.Substring(4, 1))
                {
                    case "1":
                        textBox1.Text = (Int32.Parse(textBox1.Text) + 1).ToString();
                        break;
                    case "2":
                        textBox2.Text = (Int32.Parse(textBox2.Text) + 1).ToString();
                        break;
                    case "3":
                        textBox3.Text = (Int32.Parse(textBox3.Text) + 1).ToString();
                        break;
                    case "4":
                        textBox4.Text = (Int32.Parse(textBox4.Text) + 1).ToString();
                        break;
                    case "5":
                        textBox5.Text = (Int32.Parse(textBox5.Text) + 1).ToString();
                        break;
                }
            }

        }
    }
}
