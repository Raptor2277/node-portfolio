﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Tree_Growth
{
    class Branch
    {
        public int x1, y1, x2, y2;
        public int maxAngle, minAngle;
        public int lengthDecrement;
        public int length;
        public int angle;
        public bool right;
        public bool hasBranches;

        public Branch(int x1, int y1, int angle, int length, bool right, int maxAngle, int minAngle, int lengthDecrement)
        {
            this.x1 = x1;
            this.y1 = y1;
            this.length = length;
            this.maxAngle = maxAngle;
            this.minAngle = minAngle;
            this.lengthDecrement = lengthDecrement;
            this.angle = angle;
            this.right = right;

            //calculating x2, y2, based on angle and length
            double degree = (Math.PI / 180) * angle;
            int ylength = (int)(length * Math.Sin(degree));
            int xlength = (int)(length * Math.Cos(degree));

            this.x2 = x1 + xlength;

            this.y2 = y1 - ylength;
            
            this.hasBranches = false;
        }

        public Branch getBranchLeft(Random rand)
        {
            return new Branch(x2, y2, 180 - rand.Next(minAngle, maxAngle), length - lengthDecrement, false, maxAngle, minAngle, lengthDecrement);
        }

        public Branch getBranchLeft(Random rand, int baseAngle)
        {
            if(right)
                return new Branch(x2, y2, baseAngle + rand.Next(minAngle, maxAngle + 1), length - lengthDecrement, false, maxAngle, minAngle, lengthDecrement);
            else
                return new Branch(x2, y2, baseAngle - rand.Next(minAngle, maxAngle + 1), length - lengthDecrement, false, maxAngle, minAngle, lengthDecrement);
        }

        public Branch getBranchRight(Random rand)
        {
            return new Branch(x2, y2, rand.Next(minAngle, maxAngle +1), length - lengthDecrement, true, maxAngle, minAngle, lengthDecrement);
        }
        public Branch getBranchRight(Random rand, int baseAngle)
        {
            if(right)
                 return new Branch(x2, y2, baseAngle - rand.Next(minAngle, maxAngle + 1), length - lengthDecrement, true, maxAngle, minAngle, lengthDecrement);
            else
                return new Branch(x2, y2, baseAngle + rand.Next(minAngle, maxAngle + 1), length - lengthDecrement, true, maxAngle, minAngle, lengthDecrement);
        }

        public void draw(Graphics g)
        {
            g.DrawLine(Pens.Black, x1, y1, x2, y2);
        }
    }
}
