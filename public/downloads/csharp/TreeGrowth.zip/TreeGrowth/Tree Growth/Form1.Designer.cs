﻿namespace Tree_Growth
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.minus2 = new System.Windows.Forms.Button();
            this.plus2 = new System.Windows.Forms.Button();
            this.minus1 = new System.Windows.Forms.Button();
            this.plus1 = new System.Windows.Forms.Button();
            this.plus4 = new System.Windows.Forms.Button();
            this.minus4 = new System.Windows.Forms.Button();
            this.plus5 = new System.Windows.Forms.Button();
            this.minus5 = new System.Windows.Forms.Button();
            this.plus3 = new System.Windows.Forms.Button();
            this.minus3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(745, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 49);
            this.button1.TabIndex = 0;
            this.button1.Text = "Draw";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 111);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(700, 450);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Starting Length";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Length Decrement";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(297, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Iterations";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(515, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Min Angle";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(511, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Max Angle";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(160, 65);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(48, 26);
            this.textBox1.TabIndex = 7;
            this.textBox1.Text = "5";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(160, 24);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(48, 26);
            this.textBox2.TabIndex = 8;
            this.textBox2.Text = "60";
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(600, 65);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(55, 26);
            this.textBox3.TabIndex = 9;
            this.textBox3.Text = "25";
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(379, 24);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(51, 26);
            this.textBox4.TabIndex = 10;
            this.textBox4.Text = "12";
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(600, 24);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(55, 26);
            this.textBox5.TabIndex = 11;
            this.textBox5.Text = "25";
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // minus2
            // 
            this.minus2.Location = new System.Drawing.Point(214, 26);
            this.minus2.Name = "minus2";
            this.minus2.Size = new System.Drawing.Size(28, 23);
            this.minus2.TabIndex = 12;
            this.minus2.Text = "-";
            this.minus2.UseVisualStyleBackColor = true;
            this.minus2.Click += new System.EventHandler(this.minus_Click);
            this.minus2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.minus2_MouseClick);
            // 
            // plus2
            // 
            this.plus2.Location = new System.Drawing.Point(248, 26);
            this.plus2.Name = "plus2";
            this.plus2.Size = new System.Drawing.Size(28, 23);
            this.plus2.TabIndex = 13;
            this.plus2.Text = "+";
            this.plus2.UseVisualStyleBackColor = true;
            this.plus2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.minus2_MouseClick);
            // 
            // minus1
            // 
            this.minus1.Location = new System.Drawing.Point(214, 67);
            this.minus1.Name = "minus1";
            this.minus1.Size = new System.Drawing.Size(28, 23);
            this.minus1.TabIndex = 14;
            this.minus1.Text = "-";
            this.minus1.UseVisualStyleBackColor = true;
            this.minus1.Click += new System.EventHandler(this.minus_Click);
            this.minus1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.minus2_MouseClick);
            // 
            // plus1
            // 
            this.plus1.Location = new System.Drawing.Point(248, 67);
            this.plus1.Name = "plus1";
            this.plus1.Size = new System.Drawing.Size(28, 23);
            this.plus1.TabIndex = 15;
            this.plus1.Text = "+";
            this.plus1.UseVisualStyleBackColor = true;
            this.plus1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.minus2_MouseClick);
            // 
            // plus4
            // 
            this.plus4.Location = new System.Drawing.Point(470, 26);
            this.plus4.Name = "plus4";
            this.plus4.Size = new System.Drawing.Size(28, 23);
            this.plus4.TabIndex = 17;
            this.plus4.Text = "+";
            this.plus4.UseVisualStyleBackColor = true;
            this.plus4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.minus2_MouseClick);
            // 
            // minus4
            // 
            this.minus4.Location = new System.Drawing.Point(436, 26);
            this.minus4.Name = "minus4";
            this.minus4.Size = new System.Drawing.Size(28, 23);
            this.minus4.TabIndex = 16;
            this.minus4.Text = "-";
            this.minus4.UseVisualStyleBackColor = true;
            this.minus4.Click += new System.EventHandler(this.minus_Click);
            this.minus4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.minus2_MouseClick);
            // 
            // plus5
            // 
            this.plus5.Location = new System.Drawing.Point(695, 26);
            this.plus5.Name = "plus5";
            this.plus5.Size = new System.Drawing.Size(28, 23);
            this.plus5.TabIndex = 19;
            this.plus5.Text = "+";
            this.plus5.UseVisualStyleBackColor = true;
            this.plus5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.minus2_MouseClick);
            // 
            // minus5
            // 
            this.minus5.Location = new System.Drawing.Point(661, 26);
            this.minus5.Name = "minus5";
            this.minus5.Size = new System.Drawing.Size(28, 23);
            this.minus5.TabIndex = 18;
            this.minus5.Text = "-";
            this.minus5.UseVisualStyleBackColor = true;
            this.minus5.Click += new System.EventHandler(this.minus_Click);
            this.minus5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.minus2_MouseClick);
            // 
            // plus3
            // 
            this.plus3.Location = new System.Drawing.Point(695, 67);
            this.plus3.Name = "plus3";
            this.plus3.Size = new System.Drawing.Size(28, 23);
            this.plus3.TabIndex = 21;
            this.plus3.Text = "+";
            this.plus3.UseVisualStyleBackColor = true;
            this.plus3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.minus2_MouseClick);
            // 
            // minus3
            // 
            this.minus3.Location = new System.Drawing.Point(661, 67);
            this.minus3.Name = "minus3";
            this.minus3.Size = new System.Drawing.Size(28, 23);
            this.minus3.TabIndex = 20;
            this.minus3.Text = "-";
            this.minus3.UseVisualStyleBackColor = true;
            this.minus3.Click += new System.EventHandler(this.minus_Click);
            this.minus3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.minus2_MouseClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(844, 570);
            this.Controls.Add(this.plus3);
            this.Controls.Add(this.minus3);
            this.Controls.Add(this.plus5);
            this.Controls.Add(this.minus5);
            this.Controls.Add(this.plus4);
            this.Controls.Add(this.minus4);
            this.Controls.Add(this.plus1);
            this.Controls.Add(this.minus1);
            this.Controls.Add(this.plus2);
            this.Controls.Add(this.minus2);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Tree Growth";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button minus2;
        private System.Windows.Forms.Button plus2;
        private System.Windows.Forms.Button minus1;
        private System.Windows.Forms.Button plus1;
        private System.Windows.Forms.Button plus4;
        private System.Windows.Forms.Button minus4;
        private System.Windows.Forms.Button plus5;
        private System.Windows.Forms.Button minus5;
        private System.Windows.Forms.Button plus3;
        private System.Windows.Forms.Button minus3;
    }
}

