[Requirements]
	OpenGL 2.0 or greater graphics card

[Controls]
	Instructions in the app

[Executable]
	.\SFML_NormalMap_Lighting\SFML_NormalMap_Lighting.exe

[Could Not Compile Shader Error - Unknown Char]
	open .\SFML_NormalMap_Lighting\data\shader.frag with notepad and copy contents
	create a new text document and paste contents
	save it as shader.frag overriding the existing shader with ANSI encoding
	