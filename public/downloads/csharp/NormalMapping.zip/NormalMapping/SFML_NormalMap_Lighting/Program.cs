﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.Graphics;
using SFML.Window;
using SFML.System;

namespace SFML_NormalMap_Lighting
{
    class Program
    {
        public static Shader sh;

        public static Texture bg;
        public static Texture bgMap;
        
        public static float DEFAULT_LIGHT_Z = .3f;

        public static float zFalloff = .9f;
        //Light RGB and intensity (alpha)
        //public static const Vector4f LIGHT_COLOR = new Vector4f(1f, 0.8f, 0.6f, 1f);

        //Ambient RGB and intensity (alpha)
        //public static const Vector4f AMBIENT_COLOR = new Vector4f(0.6f, 0.6f, 1f, 0.2f);

        //Attenuation coefficients for light falloff
        public static  Vector3f FALLOFF = new Vector3f(.4f, 3f, 20f);

        public static int mod = 0;

        public static int texture = 0;

        public static String[] strings; 
        public static String[] strings2;

        public static Texture[] bgs;
        public static Texture[] bgMaps;

        static void Main(string[] args)
        {
            RenderWindow window= new RenderWindow(new VideoMode(1280, 720), "Lighting Testing");
            window.SetFramerateLimit(144);
            window.Closed += window_Closed;
            window.KeyPressed += window_KeyPressed;
            window.MouseWheelMoved += window_MouseWheelMoved;

            strings = new String[] { "bg.png", "floor.png", "grid.png", "wood.jpg" };
            strings2 = new String[] {"bgMap.png", "floor_NRM.jpg", "grid_NRM.jpg", "wood_NRM.jpg"};

            bgs = new Texture[4];
            bgMaps = new Texture[4];

            loadTextures();

            bg = new Texture(new Image("data/" + strings[texture]));
            bgMap = new Texture(new Image("data/" + strings2[texture]));
            sh = new Shader(null, "data/shader.frag");
            sh.SetParameter("text1", bg);
            sh.SetParameter("text2", bgMap);
            sh.SetParameter("lightColor", 1f, .9f, .8f, 1f);
            sh.SetParameter("ambientColor", 0.6f, 0.6f, 1f, 0f);
            sh.SetParameter("falloff", .2f, .2f, zFalloff);
            sh.SetParameter("resolution", 1280, 720);
            sh.SetParameter("mode", mod);

            RenderStates renderStates = new RenderStates(sh);
            
            Font font = new Font("data/comic.ttf");
            Text txt = new Text("Mouse wheel: light height, Mouse Buttons: Light Illuminosity, Left and Right : change back ground, "
                                 + "Up and Down: Change Mode",font, 20);

            while(window.IsOpen)
            {
                window.DispatchEvents();

                if (Mouse.IsButtonPressed(Mouse.Button.Left))
                {
                    zFalloff -= .01f;
                    sh.SetParameter("falloff", .2f, .2f, zFalloff);
                }
                else if(Mouse.IsButtonPressed(Mouse.Button.Right))
                {
                    zFalloff += .01f;
                    sh.SetParameter("falloff", .2f, .2f, zFalloff);
                }

                window.Clear(Color.Blue);

                float mouseX = Mouse.GetPosition(window).X / (float)window.Size.X;
                float mouseY = Mouse.GetPosition(window).Y / (float)window.Size.Y;

                sh.SetParameter("mousePos", mouseX, mouseY, DEFAULT_LIGHT_Z);

                Sprite sp = new Sprite(bgs[texture]);
                sp.Scale = new Vector2f((float)1280 / sp.Texture.Size.X, (float)720 / sp.Texture.Size.Y );

                window.Draw(sp, renderStates);

                window.Draw(txt);

                window.Display();
            }
        }

        private static void loadTextures()
        {
            for(int i = 0; i< 4; i++)
            {
                bgs[i] = new Texture(new Image("data/" + strings[i]));
                bgMaps[i] = new Texture(new Image("data/" + strings2[i]));
            }
        }

        static void window_MouseWheelMoved(object sender, MouseWheelEventArgs e)
        {
           if(e.Delta == 1)
               DEFAULT_LIGHT_Z += .1f;
           else
               DEFAULT_LIGHT_Z -= .1f;
        }

        static void window_KeyPressed(object sender, KeyEventArgs e)
        {
            if (e.Code == Keyboard.Key.Up)
            {
                mod++;
                if (mod > 3)
                    mod = 3;
                sh.SetParameter("mode", mod);
            }

            if (e.Code == Keyboard.Key.Down)
            {
                mod--;
                if (mod < 0)
                    mod = 0;
                sh.SetParameter("mode", mod);
            }

            if(e.Code == Keyboard.Key.Left)
            {
                texture--;
                if(texture < 0)
                    texture = 0;

                sh.SetParameter("text1", bgs[texture]);
                sh.SetParameter("text2", bgMaps[texture]);
            }

            if (e.Code == Keyboard.Key.Right) 
            {
                texture++;
                if(texture > 3)
                    texture = 3;

                sh.SetParameter("text1", bgs[texture]);
                sh.SetParameter("text2", bgMaps[texture]);
            }
                
            
            if(e.Code == Keyboard.Key.Escape)
            {
                Window w = (Window)sender;
                w.Close();
            }
                
           
            System.Console.WriteLine();

        }

        static void window_Closed(object sender, EventArgs e)
        {
            Window w = (Window)sender;
            w.Close();
        }
    }
}
