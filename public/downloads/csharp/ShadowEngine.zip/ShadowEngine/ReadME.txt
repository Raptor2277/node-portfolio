[Requirements]
	OpenGL 2.0 or greater graphics card

[Controls]
	Move Mouse to move light

[Executable]
	.\SFMLCS\SFMLCS.exe

[Could Not Compile Shader Error - Unknown Char]
	open .\SFMLCS\frag.txt with notepad and copy contents
	create a new text document and paste contents
	save it as frag.txt overriding the existing shader with ANSI encoding
	
	repeat above for .\SFMLCS\light.frag