﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SFMLCS
{
    class Polygon
    {

        private Point[] points;

        public Polygon(Point[] points)
        {
            this.points = points;
        }

        public Line[] getLines()
        {
            Line[] lines = new Line[points.GetLength(0)];

            if (points.GetLength(0) > 1)
            {
                for (int i = 0; i < lines.GetLength(0); i++)
                {
                    if (i + 1 < lines.GetLength(0))
                        lines[i] = new Line(points[i].X, points[i].Y, points[i + 1].X, points[i + 1].Y);
                    else
                        lines[i] = new Line(points[i].X, points[i].Y, points[0].X, points[0].Y);
                }
                return lines;
            }
            return lines;
        }

        public static Line[] getLines(Point[] points)
        {
            Line[] lines = new Line[points.GetLength(0)];

            if (points.GetLength(0) > 1)
            {
                for (int i = 0; i < lines.GetLength(0); i++)
                {
                    if (i + 1 < lines.GetLength(0))
                        lines[i] = new Line(points[i].X, points[i].Y, points[i + 1].X, points[i + 1].Y);
                    else
                        lines[i] = new Line(points[i].X, points[i].Y, points[0].X, points[0].Y);
                }
                return lines;
            }
            return lines;
        }

        public static void addLines(Point[] points, List<Line> lines)
        {
            if (points.GetLength(0) > 1)
            {
                for (int i = 0; i < points.GetLength(0); i++)
                {
                    if (i + 1 < points.GetLength(0))
                        lines.Add(new Line(points[i].X, points[i].Y, points[i + 1].X, points[i + 1].Y));
                    else
                        lines.Add(new Line(points[i].X, points[i].Y, points[0].X, points[0].Y));
                }
            }
        }

        public static Point[] getRandomPolygon(int x, int y, int w, int h, Random rand, int size = 4)
        {
            size = 4;

            //create points
            Point[] points = new Point[size];

            int x1 = x + (w / 5);
            int x2 = x + 4*(w / 5);
            int x3 = x + w;

            int y1 = y + (h / 5);
            int y2 = y + 4 * (h / 5);
            int y3 = y + h;

            points[0] = new Point(rand.Next(x1, x2), rand.Next(y, y1));
            points[1] = new Point(rand.Next(x2, x3), rand.Next(y1,y2));
            points[2] = new Point(rand.Next(x1,x2), rand.Next(y2,y3));
            points[3] = new Point(rand.Next(x,x1), rand.Next(y1,y2));

            return points;
        }
    }
}
