﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SFMLCS
{
    class Line : IComparable<Line>
    {
        public float x1, y1, x2, y2;
        public float angleDeg;
        public SFML.Graphics.Color color = SFML.Graphics.Color.White;


        public Line(float x1, float y1, float x2, float y2)
        {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
        }

        public Line(float x1, float y1, float angleDeg )
        {
            this.x1 = x1;
            this.y1 = y1;
            this.angleDeg = angleDeg;
            this.x2 = (float)(x1 + Math.Cos((double)(angleDeg * Math.PI / 180.0)));        //sin(angle) = x / length -> x = sin(angle) * length
            this.y2 = (float)(y1 - Math.Sin((double)(angleDeg * Math.PI / 180.0)));       //cos(angle) = y / length -> x = cos(angle) * length
        }

        public Point[] getPoints()
        {
            return new Point[2] { new Point(x1, y1), new Point(x2, y1) };
        }

        public void draw(SFML.Graphics.RenderWindow window)
        {
            SFML.Graphics.Vertex[] verts= new SFML.Graphics.Vertex[] {new SFML.Graphics.Vertex(new SFML.System.Vector2f(Convert.ToSingle(x1),Convert.ToSingle(y1)),color),  
                                                                        new SFML.Graphics.Vertex(new SFML.System.Vector2f(Convert.ToSingle(x2),Convert.ToSingle(y2)), color)};
            window.Draw(verts,SFML.Graphics.PrimitiveType.Lines);
        }
        
        public void setColor(SFML.Graphics.Color c)
        {
            this.color = c;
        }

        public int CompareTo(Line other)
        {
            if (this.angleDeg > other.angleDeg) return -1;
            else if (this.angleDeg == other.angleDeg) return 0;
            else return 1;
        }
    }
}
