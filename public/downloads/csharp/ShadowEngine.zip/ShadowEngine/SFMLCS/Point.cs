﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SFMLCS
{
    class Point
    {
        public float X, Y;
        public Point(float x, float y) { this.X = x; this.Y = y; }
        public override bool Equals(object obj)
        {
            Point p = obj as Point;
            return p.X == X && p.Y == Y;
        }
    }
}
