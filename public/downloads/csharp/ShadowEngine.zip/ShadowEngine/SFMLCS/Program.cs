﻿using System;
using System.Runtime.InteropServices;
using SFML;
using SFML.Window;
using SFML.Graphics;
using SFML.System;
using System.Collections.Generic;

namespace SFMLCS
{
    class Program
    {
        public static List<Line> lines = new List<Line>();
        public static List<Line> rays = new List<Line>();
        public static Sprite backGround;
        public static LightLayer lightLayer;
        public static SFML.System.Clock clock;

        public static byte darkNess = 0;

        public static int calls = 0;

        static void Main(string[] args)
        {
            ContextSettings settings = new ContextSettings();
            settings.AntialiasingLevel = 4;

            RenderWindow window = new RenderWindow(new VideoMode(960, 540), "C# SFML", Styles.Close, settings);
            window.SetFramerateLimit(9000);
            window.SetVerticalSyncEnabled(false);

            window.Closed += new EventHandler(windowClosed);
            window.MouseMoved += new EventHandler<MouseMoveEventArgs>(mouseMove);

            initLines2();
            backGround = new Sprite(new Texture("b22.jpg"));
            lightLayer = new LightLayer(960, 540);

            lightLayer.ShadowColor = new Color(darkNess, darkNess, darkNess);

            clock = new SFML.System.Clock();

            int frames = 0;


            lightLayer.LightColor = new Color(255, 255, 255);

            //main draw loop
            while (window.IsOpen)
            {
                //events
                window.DispatchEvents();

                //draw
                window.Clear(Color.White);
                window.Draw(backGround);
                lightLayer.draw(window);
                foreach (Line l in lines)
                    l.draw(window);

                /*long timePassed = clock.ElapsedTime.AsMicroseconds();
                if (timePassed > 500000)
                {
                    text.DisplayedString = "FPS: " + (int)( (double)frames / timePassed * 1000000);
                    timePassed = 0;
                    clock.Restart();
                    frames = 0;
                }*/

                window.Display();
                frames++;
            }
        }

        public static void mouseMove(object sender, MouseMoveEventArgs e)
        {
            lightLayer.update(e.X, e.Y, lines);
            calls++;
        }

        public static void windowClosed(object sender, EventArgs e)
        {
            Window window = (Window)sender;
            window.Close();
        }

        public static void initLines()
        {
            lines.Add(new Line(0, 0, 960, 0));
            lines.Add(new Line(0, 0, 0, 540));
            lines.Add(new Line(960, 540, 960, 0));
            lines.Add(new Line(960, 540, 0, 540));

            //polygons
            Polygon.addLines(new Point[] { new Point(150, 50), new Point(250, 150), new Point(150, 150) }, lines);
            Polygon.addLines(new Point[] { new Point(350, 150), new Point(450, 150), new Point(450, 250), new Point(350, 250) }, lines);
            Polygon.addLines(new Point[] { new Point(550, 300), new Point(750, 400), new Point(750, 500), new Point(650, 500) }, lines);

            //generated Polygons
            Random rand = new Random(); //doing this out here because creating random in the fuction will recreate random and give the same numbers
            Polygon.addLines(Polygon.getRandomPolygon(700, 100, 200, 200, rand), lines);
            Polygon.addLines(Polygon.getRandomPolygon(50, 100, 100, 100, rand), lines);
            Polygon.addLines(Polygon.getRandomPolygon(10, 10, 100, 100, rand), lines);

            Polygon.addLines(Polygon.getRandomPolygon(50, 300, 200, 200, rand), lines);
        }

        public static void initLines2()
        {
            lines.Add(new Line(0, 0, 960, 0));
            lines.Add(new Line(0, 0, 0, 540));
            lines.Add(new Line(960, 540, 960, 0));
            lines.Add(new Line(960, 540, 0, 540));

            int x = 10;
            int y = 100;
            for (int i = 0; i < 8; i++)
            {
                Polygon.addLines(new Point[] { new Point(x, y), new Point(x +50, y), new Point(x+50, y+50), new Point(x, y+50) }, lines);
                x += 100;
            }

            /*y = 200;
            x = 100;
            for (int i = 0; i < 8; i++)
            {
                Polygon.addLines(new Point[] { new Point(x, y), new Point(x + 50, y), new Point(x + 50, y + 50), new Point(x, y + 50) }, lines);
                x += 100;
            }

            y = 300;
            x = 10;
            for (int i = 0; i < 8; i++)
            {
                Polygon.addLines(new Point[] { new Point(x, y), new Point(x + 50, y), new Point(x + 50, y + 50), new Point(x, y + 50) }, lines);
                x += 100;
            }*/


            y = 400;
            x = 100;
            for (int i = 0; i < 8; i++)
            {
                Polygon.addLines(new Point[] { new Point(x, y), new Point(x + 50, y), new Point(x + 50, y + 50), new Point(x, y + 50) }, lines);
                x += 100;
            }

           
        }
    }
}
