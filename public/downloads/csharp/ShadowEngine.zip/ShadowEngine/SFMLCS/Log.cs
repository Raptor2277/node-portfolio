﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SFMLCS
{
    class Log
    {
        public static void log(String s)
        {
            System.Console.Out.WriteLineAsync(s);
        }
    }
}
