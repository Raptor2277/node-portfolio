﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SFMLCS
{
    class ParameticLine
    {
        public static Intersection getIntersection(Line Ray, Line line)
        {
            Intersection intersection = null;

            //ray parameterized variables
            float x1 = Ray.x1;
            float dx1 = Ray.x2 - Ray.x1;
            float y1 = Ray.y1;
            float dy1 = Ray.y2 - Ray.y1;

            //line marameterized vairables
            float x2 = line.x1;
            float dx2 = line.x2 - line.x1;
            float y2 = line.y1;
            float dy2 = line.y2 - line.y1;

            //checking if they are parallel
           
            float rMag = (float)Math.Sqrt((double)((dx1 * dx1) + (dy1 * dy1)));
            float lMag = (float)Math.Sqrt((double)((dx2 * dx2) + (dy2 * dy2)));
            if (Math.Abs(dx1 / rMag) == Math.Abs(dx2 / lMag) && Math.Abs(dy1 / rMag) == Math.Abs(dy2 / lMag))
            {
                return intersection;               
            }

            //time factor in line 2
            float t2 = (dx1 * (y2 - y1) - dy1 * (x2 - x1)) / (dy1 * dx2 - dx1 * dy2);

            //time factor in line 1
            float t1;
            if (dx1 != 0) //vertical rays will have a distance in x (dx1) of zero, cannot divide by zero
                t1 = (x2 + dx2 * t2 - x1) / dx1;
            else if (dy1 != 0)         //if it's vertical it surely will not have a distance of zero across the y axis
                t1 = (y2 + dy2 * t2 - y1) / dy1;
            else // if both dy and dx are 0 then that means the points are on top of each other and it's not a line
                return intersection;

            if (t1 < 0) return intersection; // intersects back of its starting point
            if (t2 < 0 || t2 > 1) return intersection; // intresects back of its x1, y1 OR intersects past its x2, y2

            //has to be done in terms of t1 so we know the time of the ray and can compare to find the closest intersection
            intersection = new Intersection(new Point((x1 + dx1 * t1), (y1 + dy1 * t1)), t1);

            //System.Console.Out.WriteLineAsync("( " + x1 + ", " + y1 + ") --  (" + Ray.x2 + ", " + Ray.y2 + ")       ");
            //System.Console.Out.WriteAsync("( " + x2 + ", " + y2 + ") --  (" + line.x2 + ", " + line.y2 + ")");
            //System.Console.Out.WriteLineAsync("x " + intersection.point.X.ToString() + "    y" + intersection.point.X.ToString() + "   t1" + intersection.time.ToString() + "\n");

            return intersection;
        }

        public static List<Point> getUniquePoints(List<Line> lines)
        {
            List<Point> points = new List<Point>();

            foreach(Line l in lines)
            {
                Point p1 = new Point(l.x1, l.y1);
                Point p2 = new Point(l.x2, l.y2);
                if (!points.Contains(p1)) points.Add(p1);
                if (!points.Contains(p2)) points.Add(p2);
            }
            return points;
        }
    }
}
