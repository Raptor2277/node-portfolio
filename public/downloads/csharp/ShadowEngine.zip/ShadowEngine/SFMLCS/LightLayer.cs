﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.Graphics;

namespace SFMLCS
{
    class LightLayer
    {
        private RenderTexture rTexture;
        private Texture lightTexture;
        private Sprite sprite;
        private Light light;
        private RenderStates lightBlend;
        private RenderStates shadowBlend;
        private Color lightColor;
        public Color ShadowColor { get; set; }
        public Light Light
        {
            get { return this.light; }
            private set { this.light = value; }
        }

        public Color LightColor
        {
            get { return this.lightColor; }
            set { this.lightColor = value; light.Color = value; lightBlend.Shader.SetParameter("lightColor", value); }
        }

        public LightLayer(uint width, uint height)
        {
            ShadowColor = new Color(Color.Black);
            lightColor = new Color(Color.White);
            rTexture = new RenderTexture(width, height);
            sprite = new Sprite(rTexture.Texture);
            lightTexture = new Texture(rTexture.Texture);
            shadowBlend = new RenderStates(BlendMode.Multiply);
            lightBlend = new RenderStates(BlendMode.Add);
            lightBlend.Shader = new Shader(null, "light.frag");
            lightBlend.Shader.SetParameter("text2", lightTexture);
            lightBlend.Shader.SetParameter("text", rTexture.Texture);
            lightBlend.Shader.SetParameter("lightColor", lightColor);
            light = new Light(lightColor, this.rTexture.Texture);
        }

        ~LightLayer()
        {
            rTexture.Dispose();
            sprite.Dispose();
        }

        public void draw(RenderWindow window)
        {
            if(light.newData)
                light.calculate();

            rTexture.Clear(ShadowColor);
            light.draw(rTexture, lightTexture);
            rTexture.Display();

            window.Draw(sprite, shadowBlend);
            window.Draw(sprite, lightBlend);
        }

        public void update(int x, int y, List<Line> lines)
        {
            light.update(x, y, lines);
        }
    }
}
