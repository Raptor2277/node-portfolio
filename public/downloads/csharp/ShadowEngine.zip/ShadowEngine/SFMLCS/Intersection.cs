﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SFMLCS
{
    class Intersection
    {
        public Point point;
        public float time;

        public Intersection(Point p, float time)
        {
            this.point = p;
            this.time = time;
        }
    }
}
