﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.Graphics;
using SFML.System;

namespace SFMLCS
{
    class Light
    {
        private List<Vertex> intersections;
        private List<Line> rays;
        private bool drawGuidleLines;
        public bool DrawGuideLines { get; set; }
        public Color color;
        public Color Color 
        {
            get { return this.color; } 
            set { this.color = value; shader.SetParameter("color", value); } 
        }
        private int x, y;
        private List<Line> lines;
        public bool newData;
        private Shader shader;
        private RenderStates renderState;

        public Light(Color color, Texture t)
        {
            this.color = color;
            this.intersections = new List<Vertex>();
            this.rays = new List<Line>();
            this.drawGuidleLines = false;
            this.newData = false;
            shader = new Shader(null, "frag.txt");
            shader.SetParameter("mouse", new Vector2f(.5f, .5f));
            shader.SetParameter("text", t);
            shader.SetParameter("color", color);
            renderState = new RenderStates(shader);
         
        }

        public void draw(SFML.Graphics.RenderWindow texture)
        {
            // need not use
        }

        public void draw(SFML.Graphics.RenderTexture texture, Texture txt)
        {
            texture.Draw(intersections.ToArray(), PrimitiveType.TrianglesFan);
            txt.Update(texture.Texture.CopyToImage());

            texture.Draw(new Sprite(texture.Texture), renderState);

            if (drawGuidleLines)
            {
                foreach (Line r in rays)
                    texture.Draw(new Vertex[] { new Vertex(new Vector2f(r.x1, r.y1), Color.Yellow), new Vertex(new Vector2f(r.x2, r.y2), Color.Black) }, PrimitiveType.Lines);
            }
        }

        public void calculate()
        {
            rays.Clear();

            //getting unique points from world geometry and adding rays towards them
            foreach (Point p in ParameticLine.getUniquePoints(lines))
            {
                Line ray1 = new Line(x, y, p.X, p.Y);
                float dx = p.X - x;
                float dy = -1 * (p.Y - y);
                float degree = (float)(Math.Atan2((double)dy, (double)dx) * 180.0d / Math.PI);
                ray1.angleDeg = degree;
                Line ray2 = new Line(x, y, degree + .01f);
                Line ray3 = new Line(x, y, degree - .01f);

                ray1.setColor(SFML.Graphics.Color.Yellow);
                rays.Add(ray1);

                ray2.setColor(SFML.Graphics.Color.Yellow);
                rays.Add(ray2);

                ray3.setColor(SFML.Graphics.Color.Yellow);
                rays.Add(ray3);

            }

            //sorting the rays in order by angle 
            rays.Sort();

            //clear the intersections
            intersections.Clear();

            //this first point is the middle point  OpenGL needs it 
            intersections.Add(new Vertex(new SFML.System.Vector2f(x, y), Color));

            //adding vertecies to list for OpenGL so it can draw the polygons
            foreach (Line r in rays)
            {
                Intersection closestIntersection = null;
                foreach (Line l in lines)
                {
                    Intersection intersection = ParameticLine.getIntersection(r, l);
                    if (intersection == null) continue;
                    if (closestIntersection == null || intersection.time < closestIntersection.time)
                        closestIntersection = intersection;
                }
                if (closestIntersection != null)
                {
                    intersections.Add(new Vertex(new SFML.System.Vector2f(closestIntersection.point.X, closestIntersection.point.Y), Color));
                    r.x2 = closestIntersection.point.X; // dont really need to update the ray we just want the intersection points
                    r.y2 = closestIntersection.point.Y;
                }
            }

            //in here we will have points like (100, 97.21085) and (100.1314, 97.15707) 
            for (int i = 0; i < intersections.Count; i++)
            {
                if ((int)intersections[i].Position.X == (int)intersections[i + 1 < intersections.Count ? i + 1 : 0].Position.X && (int)intersections[i].Position.Y == (int)intersections[i + 1 < intersections.Count ? i + 1 : 0].Position.Y)
                    intersections.RemoveAt(i);
            }

            //make sure we get no null exception
            if (intersections.Count > 3)
                intersections.Add(intersections[1]);

            this.newData = false;

        }

        public void update(int mouseX, int mouseY, List<Line> objectLines)
        {
            this.x = mouseX;
            this.y = mouseY;
            this.lines = objectLines;
            this.newData = true;
            this.shader.SetParameter("mouse", new Vector2f(mouseX / 960f, 1 - (mouseY / 540f)));
        }
    }
}
