[instructions]
	use [F2] to start and stop the simulation
	use the [Go] button to start the simulation 
		(presing this will delay for 3 seconds then start the simulation)
		(this is to give you time to focus the right window)