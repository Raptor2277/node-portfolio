﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using InputManager;
using Utilities;
using System.Threading;

namespace BetterInputSimulator
{
    public partial class Form1 : Form
    {
        public int delay = 50;
        public bool stop = true;
        public bool sleep = true;
        public BackgroundWorker bg;
        public globalKeyboardHook hook = new globalKeyboardHook();

        public Form1()
        {
            InitializeComponent();
            textBox1.Text = "50";
            textBox2.Enabled = false;
            bg = new BackgroundWorker();
            bg.DoWork += new DoWorkEventHandler(doWork);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            hook.KeyDown += new KeyEventHandler(hookKeyDown);
            hook.HookedKeys.Add(Keys.F2);
        }

        void hookKeyDown(object sender, KeyEventArgs e)
        {
            if (stop)
            {
                sleep = false;
                button1.PerformClick();
            }
            else
                stop = true;
        }

        private void pressKey(Keys key)
        {
            Keyboard.KeyDown(key);
            Keyboard.KeyUp(key);
            Thread.Sleep(delay);
        }
        
        private void pressKeyShift(Keys key)
        {
            Keyboard.KeyDown(Keys.LShiftKey);
            Keyboard.KeyDown(key);
            Keyboard.KeyUp(Keys.LShiftKey);
            Keyboard.KeyUp(key);
            Thread.Sleep(delay);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bg.RunWorkerAsync();
        }

        private void doWork(object o, DoWorkEventArgs e)
        {
            if (sleep)
                Thread.Sleep(3000);
            sleep = false;

            String str = ""; 
            richTextBox1.Invoke((Action)delegate
            {
                 str = richTextBox1.Text;
            });

            
            stop = false;

            for (int i = 0; i < str.Length && !stop; i++)
            {
                //if next character is enter change the delay and type
                if (str.Substring(i + 1, 1).Equals("\n"))
                {
                    int d = delay;
                    delay = 50;
                    type(str.Substring(i, 1));
                    delay = d;
                }
                else // just normal type
                {
                    type(str.Substring(i, 1));
                }

                //the after enter keypress
                if (str.Substring(i, 1).Equals("\n") && checkBox1.Checked)
                {
                    type(textBox2.Text.Substring(0, 1));
                }
            }

            stop = true;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if(textBox1.Text != "\n")
                delay = Int32.Parse(textBox1.Text);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox2.Enabled = true;
            }
            else
            {
                textBox2.Enabled = false;
            }
        }

        private void type(String str)
        {
            switch (str)
            {
                //---------------Letters and digits------------
                case "a":
                    pressKey(Keys.A); break;
                case "b":
                    pressKey(Keys.B); break;
                case "c":
                    pressKey(Keys.C); break;
                case "d":
                    pressKey(Keys.D); break;
                case "e":
                    pressKey(Keys.E); break;
                case "f":
                    pressKey(Keys.F); break;
                case "g":
                    pressKey(Keys.G); break;
                case "h":
                    pressKey(Keys.H); break;
                case "i":
                    pressKey(Keys.I); break;
                case "j":
                    pressKey(Keys.J); break;
                case "k":
                    pressKey(Keys.K); break;
                case "l":
                    pressKey(Keys.L); break;
                case "m":
                    pressKey(Keys.M); break;
                case "n":
                    pressKey(Keys.N); break;
                case "o":
                    pressKey(Keys.O); break;
                case "p":
                    pressKey(Keys.P); break;
                case "q":
                    pressKey(Keys.Q); break;
                case "r":
                    pressKey(Keys.R); break;
                case "s":
                    pressKey(Keys.S); break;
                case "t":
                    pressKey(Keys.T); break;
                case "u":
                    pressKey(Keys.U); break;
                case "v":
                    pressKey(Keys.V); break;
                case "w":
                    pressKey(Keys.W); break;
                case "x":
                    pressKey(Keys.X); break;
                case "y":
                    pressKey(Keys.Y); break;
                case "z":
                    pressKey(Keys.Z); break;
                case "0":
                    pressKey(Keys.D0); break;
                case "1":
                    pressKey(Keys.D1); break;
                case "2":
                    pressKey(Keys.D2); break;
                case "3":
                    pressKey(Keys.D3); break;
                case "4":
                    pressKey(Keys.D4); break;
                case "5":
                    pressKey(Keys.D5); break;
                case "6":
                    pressKey(Keys.D6); break;
                case "7":
                    pressKey(Keys.D7); break;
                case "8":
                    pressKey(Keys.D8); break;
                case "9":
                    pressKey(Keys.D9); break;

                //------------------Misc Keys----------------
                case " ":
                    pressKey(Keys.Space); break;
                case "\n":
                    pressKey(Keys.Enter); break;
                case "[":
                    pressKey(Keys.OemOpenBrackets); break;
                case "]":
                    pressKey(Keys.OemCloseBrackets); break;
                case ";":
                    pressKey(Keys.OemSemicolon); break;
                case "'":
                    pressKey(Keys.OemQuotes); break;
                case ",":
                    pressKey(Keys.Oemcomma); break;
                case ".":
                    pressKey(Keys.OemPeriod); break;
                case "/":
                    pressKey(Keys.OemQuestion); break;
                case "\\":
                    pressKey(Keys.OemPipe); break;
                case "`":
                    pressKey(Keys.Oemtilde); break;
                case "-":
                    pressKey(Keys.OemMinus); break;
                case "=":
                    pressKey(Keys.Oemplus); break;

                    //-------------------shift keys--------------------------
                    //-------------------numbers------------------------------
                case "~":
                    pressKeyShift(Keys.Oemtilde); break;
                case "!":
                    pressKeyShift(Keys.D1); break;
                case "@":
                    pressKeyShift(Keys.D2); break;
                case "#":
                    pressKeyShift(Keys.D3); break;
                case "$":
                    pressKeyShift(Keys.D4); break;
                case "%":
                    pressKeyShift(Keys.D5); break;
                case "^":
                    pressKeyShift(Keys.D6); break;
                case "&":
                    pressKeyShift(Keys.D7); break;
                case "*":
                    pressKeyShift(Keys.D8); break;
                case "(":
                    pressKeyShift(Keys.D9); break;
                case ")":
                    pressKeyShift(Keys.D0); break;
                case "_":
                    pressKeyShift(Keys.OemMinus); break;
                case "+":
                    pressKeyShift(Keys.Oemplus); break;

                    //--------------leters-------------------

                case "A":
                    pressKeyShift(Keys.A); break;
                case "B":
                    pressKeyShift(Keys.B); break;
                case "C":
                    pressKeyShift(Keys.C); break;
                case "D":
                    pressKeyShift(Keys.D); break;
                case "E":
                    pressKeyShift(Keys.E); break;
                case "F":
                    pressKeyShift(Keys.F); break;
                case "G":
                    pressKeyShift(Keys.G); break;
                case "H":
                    pressKeyShift(Keys.H); break;
                case "I":
                    pressKeyShift(Keys.I); break;
                case "J":
                    pressKeyShift(Keys.J); break;
                case "K":
                    pressKeyShift(Keys.K); break;
                case "L":
                    pressKeyShift(Keys.L); break;
                case "M":
                    pressKeyShift(Keys.M); break;
                case "N":
                    pressKeyShift(Keys.N); break;
                case "O":
                    pressKeyShift(Keys.O); break;
                case "P":
                    pressKeyShift(Keys.P); break;
                case "Q":
                    pressKeyShift(Keys.Q); break;
                case "R":
                    pressKeyShift(Keys.R); break;
                case "S":
                    pressKeyShift(Keys.S); break;
                case "T":
                    pressKeyShift(Keys.T); break;
                case "U":
                    pressKeyShift(Keys.U); break;
                case "V":
                    pressKeyShift(Keys.V); break;
                case "W":
                    pressKeyShift(Keys.W); break;
                case "X":
                    pressKeyShift(Keys.X); break;
                case "Y":
                    pressKeyShift(Keys.Y); break;
                case "Z":
                    pressKeyShift(Keys.Z); break;

                    //----------------misk--------------

                case "{":
                    pressKeyShift(Keys.OemOpenBrackets); break;
                case "}":
                    pressKeyShift(Keys.OemCloseBrackets); break;
                case ":":
                    pressKeyShift(Keys.OemSemicolon); break;
                case "\"":
                    pressKeyShift(Keys.OemQuotes); break;
                case "<":
                    pressKeyShift(Keys.Oemcomma); break;
                case ">":
                    pressKeyShift(Keys.OemPeriod); break;
                case "?":
                    pressKeyShift(Keys.OemQuestion); break;
                case "|":
                    pressKeyShift(Keys.OemPipe); break;

                default:
                    break;
            }
        }


    }
}
