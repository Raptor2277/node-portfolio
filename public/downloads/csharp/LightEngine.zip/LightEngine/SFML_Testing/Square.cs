﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.System;
using SFML.Graphics;

namespace SFML_Testing
{
    public class Square
    {
        public float x, y, width, height;

        public Square(float x, float y, float width, float height)
        {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }

        public List<Line> getLines()
        {
            return new List<Line> { new Line(x, y, x + width, y), 
                                    new Line(x + width, y, x + width, y + height), 
                                    new Line(x + width, y + height, x + width/2 , y + height + height/2),
                                    new Line(x + width/2 , y + height + height/2, x, y + height),
                                    new Line(x, y + height, x, y), };
        }

        public void draw(RenderWindow win)
        {
            win.Draw(new Vertex[] { new Vertex(new Vector2f(x,y), Color.Red), 
                                        new Vertex(new Vector2f(x + width, y), Color.Red), 
                                        new Vertex(new Vector2f(x + width, y + height), Color.Red),
                                        new Vertex(new Vector2f(x + width/2 , y + height + height/2), Color.Red),
                                        new Vertex(new Vector2f(x, y + height), Color.Red) }, PrimitiveType.TrianglesFan);
        }

    }
}
