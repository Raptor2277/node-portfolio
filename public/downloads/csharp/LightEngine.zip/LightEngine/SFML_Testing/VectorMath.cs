﻿using SFML.Graphics;
using SFML.System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SFML_Testing
{
    class VectorMath
    {
        public static void log(String x)
        {
            System.Console.WriteLine(x);
        }

        public static float dotProduct(Vector2f vec1, Vector2f vec2)
        {
            return vec1.X * vec2.X + vec1.Y * vec2.Y;
        }

        public static Vector2f multiply(Vector2f vec1, float amount)
        {
            return new Vector2f(vec1.X * amount, vec1.Y * amount);
        }

        public static Vector2f minus(Vector2f vec1, Vector2f vec2)
        {
            return new Vector2f(vec2.X - vec1.X, vec2.Y - vec1.Y);
        }

        public static Vertex[] toVertecies(Vector2f[] vectors, Color color)
        {
            return new Vertex[] {new Vertex(vectors[0],color), new Vertex(vectors[1],color), new Vertex(vectors[2],color), new Vertex(vectors[3],color)};
        }
    }
}
