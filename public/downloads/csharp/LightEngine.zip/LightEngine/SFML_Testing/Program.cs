﻿using SFML;
using SFML.Graphics;
using SFML.System;
using SFML.Window;
using System.Collections.Generic;
using SFML.System;

namespace SFML_Testing
{

    public class Program
    {
        public static Light currentLight;
        public static RenderWindow window;
        public static LightLayer lightLayer;
        public static Color[] colors = { Color.Blue, Color.Cyan, Color.Green, Color.Magenta, Color.Red, Color.White, Color.Yellow };
        public static int currentColor = 6;

        public static void Main()
        {
            window = new RenderWindow(new SFML.Window.VideoMode(960, 540), "Testing Shader", SFML.Window.Styles.Close);
            //window.SetFramerateLimit(144);
            window.Closed += window_Closed;
            window.MouseButtonPressed += window_MouseButtonPressed;
            window.KeyPressed += window_KeyPressed;
            lightLayer = new LightLayer(new Vector2u(window.Size.X, window.Size.Y));
            
            lightLayer.blocks.Add(new Square(300, 300, 100, 100));
            lightLayer.blocks.Add(new Square(500, 300, 100, 100));

            lightLayer.lights.Add(new Light(new Vector2f(100, 100), Color.Yellow));
            currentLight = lightLayer.lights[0];

            Clock clock = new Clock();

            while (window.IsOpen)
            {
                window.DispatchEvents();


                window.Clear(Color.Black);

                currentLight.pos = new Vector2f(Mouse.GetPosition(window).X, Mouse.GetPosition(window).Y);
                keyboardInput(clock);
               
                lightLayer.draw(window);
                foreach (Square b in lightLayer.blocks)
                    b.draw(window);

                window.Display();
            }

        }

        public static void keyboardInput(Clock clock)
        {
            if (clock.ElapsedTime.AsSeconds() > (1.0f / 60.0f))
            {
                if (Keyboard.IsKeyPressed(Keyboard.Key.A))
                {
                    foreach (Square s in lightLayer.blocks)
                        s.x -= 5f;
                }
                if (Keyboard.IsKeyPressed(Keyboard.Key.S))
                {
                    foreach (Square s in lightLayer.blocks)
                        s.y += 5f;
                }
                if (Keyboard.IsKeyPressed(Keyboard.Key.D))
                {
                    foreach (Square s in lightLayer.blocks)
                        s.x += 5f;
                }
                if (Keyboard.IsKeyPressed(Keyboard.Key.W))
                {
                    foreach (Square s in lightLayer.blocks)
                        s.y -= 5f;
                }
                clock.Restart();
            }
        }

        static void window_KeyPressed(object sender, KeyEventArgs e)
        {
            if(e.Code == Keyboard.Key.Right)
                currentColor++;
            if (currentColor > 6)
                currentColor = 0;

            if (e.Code == Keyboard.Key.R)
                lightLayer.lights.Clear();

            currentLight.color = colors[currentColor];
        }

        static void window_MouseButtonPressed(object sender, MouseButtonEventArgs e)
        {
            lightLayer.lights.Add(new Light(new Vector2f(Mouse.GetPosition(window).X, Mouse.GetPosition(window).Y), colors[currentColor]));
            currentLight = lightLayer.lights[lightLayer.lights.Count - 1];
        }

        private static void window_Closed(object sender, System.EventArgs e)
        {
            RenderWindow w = (RenderWindow)sender;
            w.Close();
        }
    }
}