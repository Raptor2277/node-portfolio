﻿using SFML.Graphics;
using SFML.System;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SFML_Testing
{
    public class LightLayer
    {
        public List<Light> lights;
        public List<Square> blocks;
        private RenderTexture renText;
        private RenderTexture lightMap;
        private Shader shader;
        private RenderStates renderState;

        public LightLayer(Vector2u resolution)
        {
            lights = new List<Light>();
            blocks = new List<Square>();
            renText = new RenderTexture(resolution.X, resolution.Y);
            lightMap = new RenderTexture(resolution.X, resolution.Y);

            shader = new Shader(null, "Resources/frag.txt"); //"Resources/frag.txt"
            shader.SetParameter("screenHeight", resolution.Y);
            renderState = new RenderStates(BlendMode.Add, Transform.Identity, renText.Texture, shader);
        }

        public void update()
        {

        }

        public void draw(RenderWindow window)
        {
            lightMap.Clear(new Color(10, 10, 10));
            foreach (Light l in lights)
            {
                renText.Clear(l.color);
                foreach (Square s in blocks)
                {
                    List<Line> sides = s.getLines();
                    foreach (Line line in sides)
                    {
                        Vector2f normal = new Vector2f(line.y2 - line.y1, (line.x2 - line.x1) * -1);
                        Vector2f lightDir = new Vector2f(line.x1 - l.pos.X, line.y1 - l.pos.Y);
                        if (VectorMath.dotProduct(normal, lightDir) > 0)
                        {
                            Vector2f v1 = new Vector2f(line.x1, line.y1);
                            Vector2f v2 = new Vector2f(line.x2, line.y2);
                            Vector2f p1 = VectorMath.multiply(lightDir, 100);
                            Vector2f p2 = VectorMath.multiply(new Vector2f(line.x2 - l.pos.X, line.y2 - l.pos.Y), 100);
                            Vertex[] verts = VectorMath.toVertecies(new Vector2f[] { v1, p1, p2, v2 }, Color.Black);
                            renText.Draw(verts, PrimitiveType.Quads);
                        }
                    }
                }
                renText.Display();
                shader.SetParameter("lightPos", l.pos);
                shader.SetParameter("lightColor", l.color.R / 255.0f, l.color.G / 255.0f, l.color.B / 255.0f);
                lightMap.Draw(new Sprite(renText.Texture), renderState);
            }


            lightMap.Display();
            window.Draw(new Sprite(lightMap.Texture));
        }

        public void add(Light l)
        {
            lights.Add(l);
        }

        public void remove(Light l)
        {
            lights.Remove(l);
        }

        public Stream GenerateStreamFromString(string s)
        {
            MemoryStream stream = new MemoryStream();
            StreamWriter writer = new StreamWriter(stream);
            writer.Write(s);
            writer.Flush();
            stream.Position = 0;
            return stream;
        }
    }
}
