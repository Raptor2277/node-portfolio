﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.Graphics;
using SFML.System;

namespace SFML_Testing
{
    public class Light
    {
        public Vector2f pos;
        public Color color;

        public Light(Vector2f pos, Color color)
        {
            this.pos = pos;
            this.color = color;
        }
    }
}
