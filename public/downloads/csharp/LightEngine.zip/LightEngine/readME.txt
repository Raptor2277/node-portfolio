[Requirements]
	OpenGL 2.0 or greater graphics card

[Controls]
	WASD, move the polygons
	R, remove all lights
	Left and Right arrow keys, change light color
	MouseClick, place down light

[Executable]
	.\SFML_Testing\SFML_Testing.exe

[Could Not Compile Shader Error - Unknown Char]
	open .\SFML_Testing\Resources\frag.txt with notepad and copy contents
	create a new text document and paste contents
	save it as frag.txt overriding the existing shader with ANSI encoding
	