﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Light_Rays
{
    class Intersection
    {
        public Point point;
        public double time;

        public Intersection(Point p, double time)
        {
            this.point = p;
            this.time = time;
        }
    }
}
