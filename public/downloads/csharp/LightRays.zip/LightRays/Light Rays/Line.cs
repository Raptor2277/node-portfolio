﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Light_Rays
{
    class Line : IComparable<Line>
    {
        public int x1, y1, x2, y2;
        public double angleDeg;
        public double length;

        Pen pen = Pens.Black;

        public Line(int x1, int y1, int x2, int y2)
        {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
        }

        public Line(double x1, double y1, double x2, double y2)
        {
            this.x1 = (int)x1;
            this.y1 = (int)y1;
            this.x2 = (int)x2;
            this.y2 = (int)y2;
        }

        public Line(int x1, int y1, double length, double angleDeg)
        {
            this.x1 = x1;
            this.y1 = y1;
            this.angleDeg = angleDeg;
            this.length = length;
            this.x2 = x1 + (int)(Math.Cos(angleDeg * Math.PI / 180.0) * length );        //sin(angle) = x / length -> x = sin(angle) * length
            this.y2 = y1 - (int)(Math.Sin(angleDeg * Math.PI / 180.0) * length );       //cos(angle) = y / length -> x = cos(angle) * length
        }

        public void setPen(Pen p)
        {
            this.pen = p;
        }

        public Point[] getPoints()
        {
            return new Point[2] { new Point(x1, y1), new Point(x2, y1) };
        }

        public void draw(Graphics g)
        {
            g.DrawLine(pen, x1, y1, x2, y2);
        }

        public void newRayPos(int x, int y)
        {
            this.x1 = x;
            this.y1 = y;
            this.x2 = x1 + (int)(Math.Cos(angleDeg * Math.PI / 180.0) * length);        //sin(angle) = x / length -> x = sin(angle) * length
            this.y2 = y1 - (int)(Math.Sin(angleDeg * Math.PI / 180.0) * length);
        }

        public int CompareTo(Line other)
        {
            if (this.angleDeg > other.angleDeg) return 1;
            else if (this.angleDeg == other.angleDeg) return 0;
            else return -1;
        }
    }
}
