﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Light_Rays
{
    public partial class Form1 : Form
    {
        // light bulb // no longer used
        Pointer pointer = new Pointer(Brushes.Red, new Rectangle(0, 0, 10, 10));

        //lines of the polygon and rays fromm the light source
        List<Line> lines = new List<Line>();
        List<Line> rays = new List<Line>();

        public Form1()
        {
            InitializeComponent();

            //box arund screen
            lines.Add(new Line(0, 0, 1000, 0));
            lines.Add(new Line(0, 0, 0, 750));
            lines.Add(new Line(1000, 750, 1000, 0));
            lines.Add(new Line(1000, 750, 0, 750));

            //polygons
            Polygon.addLines(new Point[] { new Point(150,50), new Point(250, 150), new Point(150, 150) }, lines);
            Polygon.addLines(new Point[] { new Point(250, 150), new Point(350, 150), new Point(350, 250), new Point(250, 250) }, lines);
            Polygon.addLines(new Point[] { new Point(450, 350), new Point(650, 450), new Point(650, 550), new Point(550, 550) }, lines);
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            //lines of polygona and around screen
            foreach (Line l in lines)
            {
                l.draw(g);
            }

            List<Point> intersetcions = new List<Point>();
            foreach (Line r in rays)
            {
                Intersection closestIntersection = null;
                foreach (Line l in lines)
                {
                    Intersection intersection = ParameticLine.getIntersection(r, l);
                    if (intersection == null) continue;
                    if (closestIntersection == null || intersection.time < closestIntersection.time)
                        closestIntersection = intersection;
                }
                if (closestIntersection != null)
                { 
                    intersetcions.Add(new Point(closestIntersection.point.X, closestIntersection.point.Y));
                    r.x2 = closestIntersection.point.X;
                    r.y2 = closestIntersection.point.Y;
                }
            }

            if(rays.Count() > 0)
                g.FillPolygon(Brushes.Yellow, intersetcions.ToArray());

            foreach (Line r in rays)
            {
                g.FillEllipse(Brushes.Red, r.x2-4, r.y2-4, 8, 8);
                r.draw(g);
            }
            
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
           pointer.bounds.X = e.X - (pointer.bounds.Width /2);
           pointer.bounds.Y = e.Y - (pointer.bounds.Height /2);

            //---------experimental
            rays.Clear();

            foreach (Point p in ParameticLine.getUniquePoints(lines))
            {
                Line ray1 = new Line(e.X, e.Y, p.X, p.Y);
                int dx = p.X - e.X;
                int dy = -1 * (p.Y - e.Y);
                double degree = (Math.Atan2(dy, dx)) / Math.PI * 180.0;
                ray1.angleDeg = degree;
                Line ray2 = new Line(e.X, e.Y, 100000.0, degree + .001);
                Line ray3 = new Line(e.X, e.Y, 100000.0, degree - .001);

                ray1.setPen(Pens.Orange);
                rays.Add(ray1);

                ray2.setPen(Pens.Orange);
                rays.Add(ray2);

                ray3.setPen(Pens.Orange);
                rays.Add(ray3);
            }

            /*double x = 0;
            while (x<360)
            {
                double degree = x * Math.PI / 180;
                rays.Add(new Line(e.X, e.Y, 1000, x));
                x+=1;
            }*/

            rays.Sort();

            //-- experimental
            pictureBox1.Refresh();
        }
    }
}
