﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Light_Rays
{
    class Pointer
    {
        public Brush brush;
        public Rectangle bounds;

        public Pointer(Brush b, Rectangle rect)
        {
            this.brush = b;
            this.bounds = rect;
        }

        public void draw(Graphics g)
        {
            g.FillEllipse(brush, bounds);
        }
    }
}
