﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Light_Rays
{
    class Polygon
    {

        private Point[] points;

        public Polygon(Point[] points)
        {
            this.points = points;
        }

        public Line[] getLines()
        {
            Line[] lines = new Line[points.GetLength(0)];

            if (points.GetLength(0) > 1)
            { 
                for (int i = 0; i < lines.GetLength(0); i++)
                {
                    if (i + 1 < lines.GetLength(0))
                        lines[i] = new Line(points[i].X, points[i].Y, points[i + 1].X, points[i + 1].Y);
                    else
                        lines[i] = new Line(points[i].X, points[i].Y, points[0].X, points[0].Y);
                }
                return lines;
            }
            return lines;
        }

        public static Line[] getLines(Point[] points)
        {
            Line[] lines = new Line[points.GetLength(0)];

            if (points.GetLength(0) > 1)
            {
                for (int i = 0; i < lines.GetLength(0); i++)
                {
                    if (i + 1 < lines.GetLength(0))
                        lines[i] = new Line(points[i].X, points[i].Y, points[i + 1].X, points[i + 1].Y);
                    else
                        lines[i] = new Line(points[i].X, points[i].Y, points[0].X, points[0].Y);
                }
                return lines;
            }
            return lines;
        }

        public static void addLines(Point[] points, List <Line> lines)
        {
            if (points.GetLength(0) > 1)
            {
                for (int i = 0; i < points.GetLength(0); i++)
                {
                    if (i + 1 < points.GetLength(0))
                        lines.Add(new Line(points[i].X, points[i].Y, points[i + 1].X, points[i + 1].Y));
                    else
                        lines.Add(new Line(points[i].X, points[i].Y, points[0].X, points[0].Y));
                }
            }
        }
    }
}
